
<?php
$expired=  ComasUserManager::isExpired();
$infos=new  ComasInformer();
 $filter=new AdminFormProcess();
if(!$expired){
$reports=new ComasReports();
$reportprint=new ComasReports();
$purch=$reports->purchaseHistory(0,3,0,0,false,false);
$report=$reportprint->purchaseHistory(0, "", "", "", false,true);
$_SESSION['report']=$report;
$fileInclude.="<div class='content_box' >".$filter->comasDateFilter(true);
if($purch!=""){
$fileInclude.="<span style='float:right;'> <a href='../reports/reports.php?report=2' data-ajax='false'>PDF</a></span>";
$fileInclude.="<div id='updates'>".$purch."</div></div></div>";
}else{
 $fileInclude.="".$infos->noRecordsFoundText("eng")."</div></div>";     
}
}else{
 $fileInclude.="<div>".$infos->accountExpireText("eng")."</div></div>";   
}
?>


<?php
/**
 * This class is used to handle  request and redirect it to the specific processor
 * it is designed to make sure each request easy and effiency handled
 * @author Raphael Martin <rafakingazi@gmail.com>
 */


class ComasRequestHandler{
    private $requestMethod; //post/get /put or delete requests
    private $HttpDataFormat; //json or xml data format.
    private $userToken; //token given by user for authetication purpose.
    private $data;
    private $dataType;
    private $requestKeys; //keys used to determine the given request;
    
    /**
     * Constructor of ComasRequestHandler which is used to initialize request accept
     *  data type when request come from restservice app
     */
    function ComasRequestHandler() {
        $this->requestKeys=array();
        $this->data='';
         if(isset($_SERVER['HTTP_ACCEPT'])){
        $this->HttpDataFormat=(strpos($_SERVER['HTTP_ACCEPT'], 'json'))?'json':'xml';
        }else{
        $this->HttpDataFormat='json';
        }
        $this->requestMethod='get';
    }

    /**
     * This method is used to set given http data sent by user browser or from restfull webservice client
     * @param type $data
     */
    public function setData($data){
        $this->data=$data;

    }
    
    /**
     * This method is used to set http method used to send data for example get,post
     * @param type $method
     */
    public function setMethod($method){
       $this->requestMethod=$method;
    }
    
    /**
     * This method is usefull for restfull webservice to sent client requestkey for given app
     * @param type $requestkey
     */
    public function setRequestKey($requestkey){
        $this->requestKeys=$requestkey;
    }
    
    /**
     *This method is used to set type of data sent by user  for example xml or json
     *  
     * @param type $dataType
     */
   public function setDataType($dataType){
   $this->dataType=$dataType;
   }
   
   /**
    * THis method is used to get that data type used by user
    * @return type
    */
   public function getDataType(){
   return $this->dataType;
   }
   
   /**
    * This method is used to get data from given user request
    * @return type
    */
    public function getData(){
        return $this->data;
    }
    
    /**
     * This method is used to get the method used by user the send given request
     * @return type
     */
    public function getMethod(){
        return $this->requestMethod;
    }

    /**
     * This is used to user requestkey or app key
     * @return type
     */
    public function getRequestKey(){
        return $this->requestKeys;
    }
}
?>
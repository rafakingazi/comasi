<?php
$fileInclude.='<div class="flexslider">
<div class="sliderleft"></div>
<div class="sliderbody">

                    <ul class="slides">
                        <li>
                      
                        
                            <div class="flex-caption"  >
                                
                                <span class="home-slideshow-text">
                                The easy way to organise and control your business, 
                                We bring all your business at one spot.
                                
                             </span><form action="index.php?page=58" >
          <input type="submit" value="Join Today" /></form>
                            </div>
                              <div class="slideshow-image">
                                <a href="">
                                    <img src="comas_plugin/slider/img/7.jpg" alt="" /></a></div>
                            
                        </li>
                        <li>
                            <div class="flex-caption">
                               
                                <span class="home-slideshow-text">Now stocking can be done at anytime, With our uptodate stock history in your hand </span><form action="index.php?page=58" >
          <input type="submit" value="Join Today" /></form>
                            </div>
                            <div class="slideshow-image">
                                <a href="">
                                    <img src="comas_plugin/slider/img/8.jpg" alt="" /></a></div>
                        </li><li>
                            <div class="flex-caption">
                            
                                <span class="home-slideshow-text">See all your business transaction by a click, make easy of controling any loss as it appear. </span><form action="index.php?page=58" >
          <input type="submit" value="Join Today" /></form>
                            </div>
                            <div class="slideshow-image">
                                <a href="">
                                    <img src="comas_plugin/slider/img/7.jpg" alt="" /></a></div>
                        </li>
                        <li>
                            <div class="flex-caption">
                               
                                <span class="home-slideshow-text">Few Time for stocking as we have done all calculation for you, You just need to confirm our reports and your actual stock </span><form action="index.php?page=58" >
          <input type="submit" value="Join Today" /></form>
                            </div>
                            <div class="slideshow-image">
                                <a href="">
                                   <img src="comas_plugin/slider/img/9.jpg" alt="" /></a></div>
                        </li>
                        <li>
                            <div class="flex-caption">
                                
                                <span class="home-slideshow-text">Wherever You go your shops is with you. </span><form action="index.php?page=58" >
          <input type="submit" value="Join Today" /></form>
                            </div>
                            <div class="slideshow-image">
                                <a href="">
                                    <img src="comas_plugin/slider/img/7.jpg" alt="" /></a></div>
                        </li>
                    </ul>
                    
                    </div>
                    <div class="sliderright">
                 
                    </div>
                </div><hr>
                <script type="text/javascript" >
        //<![CDATA[

        jQuery(function () {

            jQuery(".flexslider").flexslider({
                animation: "fade",
                slideshow: true,
                slideshowSpeed: 4000,
                animationDuration: 900,
                directionNav: true,
                controlNav: true,
                nextText: "",
                prevText: "",
                animationLoop: true
            });

            var width = (39 * jQuery(".flex-control-nav li").length);
            var left_pos = ((951 - width) / 2) - 40;
            var right_pos = ((951 - width) / 2) - 34;
            jQuery(".flex-direction-nav li .prev").css("left", left_pos);
            jQuery(".flex-direction-nav li .next").css("right", right_pos);

            if (jQuery.browser.msie && jQuery.browser.version == 6) {
                DD_belatedPNG.fix(".slides img, #navigation li.first a");
            }
        });
        //]]>	
</script>';

?>

<?php
class ComasGeneratePage{
    
    /**
     * This method is used to generate page content for each given block
     * @param type $page_id
     * @param type $location
     * @param type $viewer
     * @return string
     */
    function MyPageContent($page_url,$page_id,$location,$viewer,$is_mobi){
        $database=new ComasDatabase();
        $database1=new ComasDatabase();
        
       $usersystem='0';
       //we need to select page only belong to user business
        if(isset($_SESSION['biz_type'])){
        $usersystem= $_SESSION['biz_type'];
        }
        $pageBlock="";
       $cleanid=  ComasDatabase::escapeString($page_id);
       $pageviewer=  ComasDatabase::countrows("comas_pages", "=", "page_viewer", $viewer."' and (pagesystem='".$usersystem."' or pagesystem='0') and page_id='".$cleanid);
    
       if($pageviewer==1){
       $status=$database->selectField("comas_blocks", array('*'), "=", "page_id",$cleanid."' and block_location='".$location."' and block_parent='0", "block_id", "asc","","");
      if($status){
          while($block=$database->getResultSet()){
          //create the block to hold given content
          $pageBlock.="<div class='".$block['block_class_attr']."' id='".$block['block_id_attr']."' ".$block['b_extra']." >";
          
          //if($block['block_type']=='normal'){
            $available=$database1->selectField("comas_pagecontent",array('*'), "=", "block_id", $block['block_id'], "","", "", "");
            if($available){
                while($content=$database1->getResultSet()){
                   if($content['content_title']!=""){ 
                 $pageBlock.=" <h2>".$content['content_title']."</h2>";
                   }
                    $pageBlock.= "".$content['content_body']."";
                 
                }
            }
            
          //}else{
            $pageBlock.=$this->mainFormGenerator($page_url, $block['block_id'],$is_mobi); 
          //call child blocks for this block
            $pageBlock.=$this->mainReportGenerator($block['block_id']);
           $pageBlock.=$this->blockChildren($block['block_id'], $page_url,$is_mobi);
           
           //include external files
           $pageBlock.=$this->fileIncludes($block['block_id'],$is_mobi);
          
          $pageBlock.="</div>";
      }
      }
     //page viewer ends 
    }
      return $pageBlock;
    }
  
    
    function mainFormGenerator($page_url,$block_id,$is_mobi){
        $database2=new ComasDatabase();
        $database3=new ComasDatabase();
        $trans=new AdminFormProcess();
        $trans1=new AdminFormProcess();
        $title="";
        $label="";
        $pageBlock="";
        $breakline="";
      //select a form element from the database
              $availables=$database2->selectField("comas_form",array('*'), "=", "block_id", $block_id."' and form_parent='0", "","", "", "");
              
            if($availables){
                while($form=$database2->getResultSet()){
             $elements=$database3->selectField("comas_form_elements",array('*'), "=", "form_id", $form['form_id'], "element_order","asc", "", "");
              
                 if($elements){
             $title=$trans->comasTranslator("comas_form", $form['form_id'], "eng");
            if($title==""){
              $title=$form['form_title'];
                }
                     $pageBlock.="<h2>".$title."</h2>
                        
                         <form name='".$form['form_name_attr']."' action='".$page_url."' 
                             method='".$form['form_method_attr']."' id='comas_morerows' >";
                                   if(!$is_mobi){
                                $pageBlock.="<table id='form_table' ><tr><td>";
                                 $breakline="<br/>";
                                   }
                                $pageBlock.="<div class='formAlign_hori' >";
                      
                     while($element=$database3->getResultSet()){
                         //check form alignment
                         $label=$trans1->comasTranslator("comas_form_elements", $element['element_id'], "eng");
            if($label==""){
              $label=$element['element_title'];
                }
                         if($form['form_alignment']=='vertical'){
                            $align="<div >";
                         }else{
                           $align="<div class='formAlign_hori' >";  
                         }
                        if($element['element_tag']=='select'){
                          $pageBlock.=$align."<label for='".$element['element_id_attr']."'>".$label."</label>".$breakline."<select name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."'>".$this->customOptions($element['element_type_attr'],$element['element_id'])."</select></div>";
                          
                        }else if($element['element_tag']=='textarea'){
                          $pageBlock.=$align."<label for='".$element['element_id_attr']."' >".$label."</label>".$breakline."<textarea name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."' >".$element['element_type_attr']."</textarea></div>";  
                        }else{
                          
                            $pageBlock.=$align."<label for='".$element['element_id_attr']."'>".$label."</label>".$breakline."<input type='".$element['element_type_attr']."' name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."' value='".$element['element_value']."'  ".$element['element_status']." />";
                            $pageBlock.="<div id='popups'></div></div>";
                            
                        }
                     }
                     $pageBlock.="</div>";
                    
                     $pageBlock.="<input type='hidden' id='inputfield' name='fieldname' />";
                     if(!$is_mobi){
                     $pageBlock.="</td></tr></table><table>";
                     }
                     $pageBlock.=$this->formChildren($form['form_id'],$is_mobi);
                     if(!$is_mobi){
                     $pageBlock.="</table>";
                     }
                     $pageBlock.="</form>";
                     
                 }
            }
            
              
            return $pageBlock;
          }  
    }
   
    
    function formChildren($parent_id,$is_mobi){
      $database2=new ComasDatabase();
        $database3=new ComasDatabase();
        $pageBlock="";
        $breakline="";
        
      //select a form element from the database
              $availables=$database2->selectField("comas_form",array('*'), "=", "form_parent", $parent_id, "","", "", "");
              
            if($availables){
                while($form=$database2->getResultSet()){
             $elements=$database3->selectField("comas_form_elements",array('*'), "=", "form_id", $form['form_id'], "","", "", "");
              
                 if($elements){
                     if(!$is_mobi){
                     $pageBlock.="<tr><td>";
                     $breakline="<br/>";
                    
                     }
                     $pageBlock.="<div style='' class='myforms comas_childform'> ";
                      
                     while($element=$database3->getResultSet()){
                         //check form alignment
                         if($form['form_alignment']=='vertical'){
                            $align="<div >";
                         }else{
                           $align="<div class='formAlign_hori' >";  
                         }
                        if($element['element_tag']=='select'){
                          $pageBlock.=$align."<label for='".$element['element_id_attr']."'>".$element['element_title']."</label>".$breakline."<select name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."'  min='0' max='100'>".$this->customOptions($element['element_type_attr'],$element['element_id'])."</select></div>";
                          
                        }else if($element['element_tag']=='textarea'){
                          $pageBlock.=$align."<label for='".$element['element_id_attr']."' >".$element['element_title']."</label>".$breakline."<textarea name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."'  min='0' max='100' >".$element['element_type_attr']."</textarea></div>";  
                        }else{
                          if($is_mobi && ($element['element_type_attr']=='button')){
                              
                          }else{
                            $pageBlock.=$align."<label for='".$element['element_id_attr']."'>".$element['element_title']."</label>".$breakline."<input type='".$element['element_type_attr']."' name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."' value='".$element['element_value']."' ".$element['element_status']."  min='0' max='100' /></div>";
                          }
                            
                        }
                     }
                     
                     $pageBlock.="</div>";
                     if(!$is_mobi){
                     $pageBlock.="</td></tr>";
                     }
                     
                 }
            }
          } 
          return $pageBlock;
    }
    
    
    function fileIncludes($blockId,$is_mobi){
       $database=new ComasDatabase();
       $fileInclude="";
      $status=$database->selectField("comas_includes", array('*'), "=", "block_id",$blockId, "", "","","");
      if($status){
          while($files=$database->getResultSet()){
        $fileInclude.="<div class='comas_block'>"; 
        switch (strtolower($files['file_type'])){
            case 'php':
                //include php files
                $filename=$files['file_name'];
                $file_dir=$files['file_dir'];
                $path=COMASPATH_BASE."/".$file_dir."/".$filename;
                if(is_file($path)){
                 
                 include $path;
                 }else{
                $fileInclude.="not set";
                 }
                 break;
            case 'inc':
                //include inc files
                break;
            case 'js':
                //include js files
                break;
            case 'css':
                //include css files
                break;
            case 'html':
                //include html files
                break;
           case 'image':
               //include image files
               break;
           
        }
          }
      }
      $fileInclude.="";
     return $fileInclude;
    }
    
    /**
     * This method is used to generate the child block of the given page
     * @param type $blockId
     * @param type $page_url
     * @return string
     */
    function blockChildren($blockId,$page_url,$is_mobi){
       
        $database=new ComasDatabase();
        $database1=new ComasDatabase();
        $database2=new ComasDatabase();
        $database3=new ComasDatabase();
        $pageBlock="";
        $align="";
      $status=$database->selectField("comas_blocks", array('*'), "=", "block_parent",$blockId, "block_order", "asc","","");
      if($status){
          while($block=$database->getResultSet()){
          //create the block to hold given content
          $pageBlock.="<div class='".$block['block_class_attr']."' id='".$block['block_id_attr']."' ".$block['b_extra']." >";
       
          //if($block['block_type']=='normal'){
            $available=$database1->selectField("comas_pagecontent",array('*'), "=", "block_id", $block['block_id'], "","", "", "");
            if($available){
                while($content=$database1->getResultSet()){
                    if($content['content_title']!=""){
                 $pageBlock.="<h2>".$content['content_title']."</h2>";
                    }
                 $pageBlock.="".$content['content_body']."";
                 
                }
            }
     $availables=$database2->selectField("comas_form",array('*'), "=", "block_id", $block['block_id'], "","", "", "");
              
            if($availables){
                while($form=$database2->getResultSet()){
             $elements=$database3->selectField("comas_form_elements",array('*'), "=", "form_id", $form['form_id'], "","", "", "");
              
                 if($elements){
                     $pageBlock.="<h2>".$form['form_title']."</h2>
                         <div><form name='".$form['form_name_attr']."' action='".$page_url."' 
                             method='".$form['form_method_attr']."' >
                                 ";
                      
                     while($element=$database3->getResultSet()){
                         //check form alignment
                         if($form['form_alignment']=='vertical'){
                            $align="<div >";
                         }else{
                           $align="<div style='float:left' >";  
                         }
                        if($element['element_tag']=='select'){
                          $pageBlock.=$align."<label for=''>".$element['element_title']."</label><br><select name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."' min='0' max='100' >".$this->customOptions($element['element_type_attr'],$element['element_id'])."</select></div>";
                          
                        }else if($element['element_tag']=='textarea'){
                          $pageBlock.=$align."<label for='' >".$element['element_title']."</label><br><textarea name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."'  min='0' max='100' >".$element['element_type_attr']."</textarea></div>";  
                        }else{
                          
                            $pageBlock.=$align."<label for=''>".$element['element_title']."</label><br><input type='".$element['element_type_attr']."' name='".$element['element_name_attr']."' class='".$element['element_class_attr']."' 
                              id='".$element['element_id_attr']."' value='".$element['element_value']."' ".$element['element_status']."  min='0' max='100' /></div>";
                        
                            
                        }
                     }
                     $pageBlock.="</form></div>";
                     
                 }
                 
                //}
            }
          }
          $pageBlock.=$this->fileIncludes($block['block_id'],$is_mobi);
          $pageBlock.=$this->blockChildren($block['block_id'], $page_url,$is_mobi);
          $pageBlock.="</div>";
      }
      }
     //page viewer ends 
    
      return $pageBlock;
    }
    
    
    /**
     * This method is used to generate customoptions for select box
     * You can add your options in here
     * @param type $type
     * @param type $elementId
     * @return type
     */
    function customOptions($type,$elementId){
        $options="";
       $bizselector=new AdminFormProcess();
          if($type=='custom'){
              //prepare custom options here
              switch($elementId){
                case "16":
                    $options=$bizselector->itemOptionList();
                   break;
               
              }
          }else{
          $options=$type;    
          }
       
       return $options;
    }
    //block forms
    function blockForm($page_id){
         $database=new ComasDatabase();
        $database1=new ComasDatabase();
        $pageBlock="";
       $cleanid=  ComasDatabase::escapeString($page_id);
       $status=$database->selectField("comas_blocks", array('*'), "=", "page_id",$cleanid, "", "","","");
      if($status){
          while($block=$database->getResultSet()){
          //create the block to hold given content
          $pageBlock.="<div class='comas_block ".$block['block_class_attr']."' id='".$block['block_id_attr']."'>";
       
          if($block['block_type']=='normal'){
            $available=$database1->selectField("comas_pagecontent",array('*'), "=", "block_id", $block['block_id'], "","", "", "");
            if($available){
                while($content=$database1->getResultSet()){
                 $pageBlock.="<h2>".$content['content_title']."</h2>
                     <p>".$content['content_body']."</p>";
                 
                }
            }
          }
          $pageBlock.="</div>";
      }
      
      
      }
      
      return $pageBlock;  
    }
  
    function mainReportGenerator($block_id){
      $database=new ComasDatabase();
        $database1=new ComasDatabase();
        $database2=new ComasDatabase();
        $requiredcols=array();
        $colnamesholder="";
        $coldataholder="";
        $fullreport="";
        $colnames=array();
        $colspecial=array();
        $tablenames="";
        
        //correcting report informs
       $available=$database->selectField("comas_reports", array("*"), "=", "block_id", $block_id."' and report_parent='0", "", "", "", "");
       if($available){
           $reports=$database->getResultSet();
           $tablenames=$reports['tablename'];
             $istable=$database1->selectField("comas_reportcols",array("*"), "=", "report_id", $reports['report_id'], "", "", "", "");
           if($istable){
               while($cols=$database1->getResultSet()){
                   if($cols['col_special']=="none"){
                       //for this time only simple reporting
                   $colnamesholder.="<td>".$cols['col_name']."</td>";
                   $requiredcols[]=$cols['col_tablecol'];
                   $colnames[]=$cols['col_name'];
                   $colspecial[]=$cols['col_special'];
                   }
             
               }
               //end correcting report informs
              
               //starting building normal report
               if(!empty($requiredcols)){
               $states=$database2->selectField($tablenames, $requiredcols,"", "","","","","","");
               if($states){
                   $lens=count($requiredcols);
                   $i=0;
                   while($myreport=$database2->getResultSet()){
                       if($i<$lens){
                     $coldataholder.="<td>".$myreport[$i]."</td>"; 
                       }
                     $i++;
                   }
                   $fullreport.="<table><tr>".$colnamesholder."</tr><tr>".$coldataholder."</tr></table>";
               }
                
               }
               //end making normal report
           }  
           
       }
       
     return $fullreport;
    }
}

?>

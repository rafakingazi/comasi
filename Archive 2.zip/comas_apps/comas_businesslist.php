<?php
$business=new ComasUserManager();

if($business->hasBusiness()){
$bizselector=new ComasUserManager();
$reports=new ComasReports();
$summary=$bizselector->changeUserBusiness();
$history1=$reports->bizSummary();
$history2=$reports->bizDetails();

$expired=  ComasUserManager::isExpired();
$infos=new  ComasInformer();

if($summary!=""):
$fileInclude.="<div class='content_box' > <span>Swap To Business</span>".$summary." </div><br/><br/><br/><hr/>";
endif;
if(!$expired){
if($history1!=""):
$fileInclude.=$history1;
endif;

if($history2!=""):
//$fileInclude.=$history2;
endif;
}else{
 $fileInclude.="<div>".$infos->accountExpireText("eng")."</div></div>";   
}
$fileInclude.="</div></div>";
}else{
include 'comas_newbusiness.php'; 
}
?>

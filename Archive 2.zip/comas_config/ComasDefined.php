<?php
//no direct access
defined(COMAS_EXEC);
$parts = explode(DS, COMASPATH_BASE);
date_default_timezone_set ("Africa/Nairobi");
//Defines.
define('COMASPATH_ROOT',implode(DS, $parts));

define('COMASPATH_SITE',			COMASPATH_ROOT);
define('COMASPATH_CONFIGURATION',	COMASPATH_ROOT);
define('COMASPATH_ADMINISTRATOR',	COMASPATH_ROOT . '/admincomas');
define('COMASPATH_CLIENTS',	COMASPATH_ROOT . '/mycomas');
define('COMASPATH_CORE_LIB',		COMASPATH_ROOT . '/comas_core_lib');
define('COMASPATH_PLUGINS',			COMASPATH_ROOT . '/plugins'  );
define('COMASPATH_INSTALLATION',	COMASPATH_ROOT . '/installation');
define('COMASPATH_THEMES',			COMASPATH_BASE . '/comas_ui/templates');
define('COMASPATH_CACHE',			COMASPATH_BASE . '/cache');
define('COMASPATH_MANIFESTS',		COMASPATH_ADMINISTRATOR . '/manifests');

include COMASPATH_ROOT."/comas_config/comas_config.inc";
require_once COMASPATH_ROOT.'/comas_core_lib/comas_controller/ComasDataResponder.php';
require_once COMASPATH_ROOT.'/comas_apps_class/servervalidater.php';
require_once COMASPATH_ROOT.'/comas_apps_class/mail.php';

//try to create array of data from the informer database;

function getInfoData(){
    
    //
    $mydata="";
$database=new ComasDatabase();
$states=$database->selectField("comas_informer", array("info_id,info"),"", "","","","","","");
if($states){
    $mydata=array();
  while($rec=$database->getResultSet()){
   $mydata[$rec['info_id']]=$rec['info'];  
   $mydata[$rec['info_id']]=(comasTranslators("comas_informer",$rec['info_id'],"eng")!="")?comasTranslators("comas_informer",$rec['info_id'],"eng"):$rec['info'];
  }  
}else{
  $mydata=array(1=>"20",2=>"21");  
}
return $mydata;
}
 function comasTranslators($tablename,$sourceid,$lang){
     $langs="";
     if(isset($_SESSION['clang'])){
       $langs=$_SESSION['clang'];
     }else{
      $langs=$lang;  
     }
     $transla=new ComasDatabase();
     $content="";
     $trans=$transla->selectField("comas_translator", array('trans_content'), "=","source_tablename", $tablename."' and content_id='".$sourceid."' and lang='".$langs, "", "", "", "");    
       if($trans){
         $mylang=$transla->getResultSet();
         $content=$mylang['trans_content'];
       }else{
         $content="";  
       }
   return $content;
 }
$infoz=getInfoData();
?>

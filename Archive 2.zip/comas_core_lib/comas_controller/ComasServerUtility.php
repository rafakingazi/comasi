<?php
require_once 'ComasRequestHander.php';

/**
 * This class is used to receive request from either browser or rest service app and redirect 
 * the given request to specific direction
 */
class ComasServerUtility{

    /**
     * This method is used to handle the request like get,post put and delete
     * It return object of  ComasRequestHandler as the handle of diven request
     * @return \ComasRequestHandler
     */
    public static function processRequest(){
       $request_method=  strtolower($_SERVER['REQUEST_METHOD']);
       $return_obj=new ComasRequestHandler();
       $data=array();

       switch($request_method){
           case 'get':

               $data=$_GET;

               break;
           case 'post':

               $data=$_POST;

               break;
           case 'put':
               break;
           case 'delete':
               break;
       }
       $return_obj->setMethod($request_method);
       $return_obj->setRequestKey($data);
       if(isset($data)){

          $return_obj->setData($data);
       }
       return $return_obj;
    }

    /**
     * This method is used to send feedback for given request to the required controller or view
     * for further packing of the request
     * @param type $status
     * @param type $body
     * @param type $content_type
     * @return string
     */
    public static function sendResponse($status=200,$body='',$content_type='text/xml'){
    
     switch($status){
     case 200:
       if($body!=''){
       $message= $body;
       }else{
       $message="";
       }
       break;
       case 401;
           $message="You must be authorized";
           break;
        case 404:
          $message='The requested URL ' . $_SERVER['REQUEST_URI'] . ' was not found.';
          break;
        case 500:
            $message='The server encountered an error processing your request';
            break;
        case 501:
            $message='The requested method is not implemented';
            break;

     }
return $message;

    }

    /**
     * This method is used to prepare the status of given request using http status code
     * each with the required message
     * @param type $status
     * @return type
     */
    public static function getStatusCodeMessage($status){
        $codes=Array(100 => 'Continue',
        101 => 'Switching Protocols',
        200 => 'OK',
        201 => 'Created',
        202 => 'Accepted',
        203 => 'Non-Authoritative Information',
        204 => 'No Content',
        205 => 'Reset Content',
        206 => 'Partial Content',
        300 => 'Multiple Choices',
        301 => 'Moved Permanently',
        302 => 'Found',
        303 => 'See Other',
         304 => 'Not Modified',
         305 => 'Use Proxy',
          306 => '(Unused)',
          307 => 'Temporary Redirect',
          400 => 'Bad Request',
        401 => 'Unauthorized',
        402 => 'Payment Required',
        403 => 'Forbidden',
          404 => 'Not Found',
         405 => 'Method Not Allowed',
          406 => 'Not Acceptable',
         407 => 'Proxy Authentication Required',
          408 => 'Request Timeout',
             409 => 'Conflict',
            410 => 'Gone',
           411 => 'Length Required',
            412 => 'Precondition Failed',
             413 => 'Request Entity Too Large',
              414 => 'Request-URI Too Long',
              415 => 'Unsupported Media Type',
            416 => 'Requested Range Not Satisfiable',
             417 => 'Expectation Failed',
         500 => 'Internal Server Error',
            501 => 'Not Implemented',
           502 => 'Bad Gateway',
        503 => 'Service Unavailable',
           504 => 'Gateway Timeout',
        505 => 'HTTP Version Not Supported');
        return (isset($codes[$status]))?$codes[$status]:'';
    }


}

?>

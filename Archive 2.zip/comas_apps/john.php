<?php

$fileInclude.="welcome home";
?>

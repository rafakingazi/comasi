<?php
$report=new ComasReports();
$fileInclude.="<div class='content_box' >".$report->billHistory()."</div><br/></div>";
?>

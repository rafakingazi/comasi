<?php
$expired=  ComasUserManager::isExpired();
$infos=new  ComasInformer();
$filter=new AdminFormProcess();
if(!$expired){
$reports=new ComasReports();
$sales=$reports->salesHistory();
$_SESSION['report']=$sales;
$fileInclude.="<div class='content_box' >".$filter->comasDateFilter(true);
if($sales!=""){
$fileInclude.="<span style='float:right;'> <a href='../reports/reports.php?report=3' data-ajax='false'>PDF</a></span>";
$fileInclude.=$sales."</div></div>";
}else{
$fileInclude.="".$infos->noRecordsFoundText("eng")."</div></div>";     
}
}else{
 $fileInclude.="<div>".$infos->accountExpireText("eng")."</div></div>";   
}
?>


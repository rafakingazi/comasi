<?php
$url="../index.php";
if(!$is_mobi){

 $url="../index.php";
}
$bizselector=new ComasUserManager();
$fileInclude.=$bizselector->comasLogout($url);

?>

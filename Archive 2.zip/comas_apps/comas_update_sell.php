<?php
$bizselector=new AdminFormProcess();
$fileInclude.="<div class='content_box' >".$bizselector->selectPrice()."".$bizselector->updateSellingPrice()."</div><br></div>";
?>

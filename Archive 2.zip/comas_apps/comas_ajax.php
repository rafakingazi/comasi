<?php

class ComasAjax{
    
 static  function stockList(){
     $data=new ComasDataResponder();
     $source=$data->comasRequestProcessor();
      $userid=$_SESSION['comas_knownas'];
      $bizid=$_SESSION['biz_id'];
      $request=isset($_REQUEST['request'])?strtolower(trim($_REQUEST['request'])):"";
      
      if(isset($request)):
       
        switch($request){
          case "stocklist":
          
      $stock=new ComasJsons();
      return $stock->stockItemList($userid, $bizid);
      break;
         case "unitlist":
            
             $units=new ComasJsons();
      return $units->itemUnit();
             break;
         case "expense":
               $exp=new ComasJsons();
    return $exp->expenseslist($bizid);
             break;
         }
      endif;
  } 
  
  
}
?>

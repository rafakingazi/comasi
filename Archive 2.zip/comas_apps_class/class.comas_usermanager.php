<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class ComasUserManager extends ComasDataResponder{
     private $databaseObj="";
    private $httpResource="";  
    function ComasUserManager(){
     
    $this->databaseObj=new ComasDatabase();
    $this->httpResource=$this->comasRequestProcessor();
    
    }
    
    function userProcessor($url){
        $userdata=$this->httpResource;
        $this->comasUserRegistration($userdata,$url);
        $this->comasUserLogin($userdata, $url,false);
        $this->userMails();
        $this->resetPass();
        $this-> passwordResetor($url);
    }
    
    /**
     *This function is used to register new user to system 
     * @param type $register
     */
    
    private function comasUserRegistration($register,$url){
     if(isset($register['save_register'])){
        
         $register_table=new ComasDatabase();
         $checkuser=new ComasDatabase();
         $lang="default";
         $mytime=@date("YdmHis");
         $token= md5(microtime(true)).sha1($mytime);
         $fullname=  ComasDatabase::escapeString(trim($register['firstname']));
         $lastname=ComasDatabase::escapeString(trim($register['lastname']));
         $phone=ComasDatabase::escapeString(trim($register['phone']));
         $email=ComasDatabase::escapeString(trim($register['email']));
         $pass1=ComasDatabase::escapeString(trim($register['pass1']));
         $pass2=ComasDatabase::escapeString(trim($register['pass2']));
         //$country=ComasDatabase::escapeString(trim($register['country']));
         //$city=ComasDatabase::escapeString(trim($register['city']));
         
         if(isset($_SESSION['clang'])){
         $lang=$_SESSION['clang'];    
         }
         
         $status="0";
         $dates=@date("Y-m-d H:i:s");
         
      
           
         if($pass1==$pass2){
            $counts=$checkuser->countrows("comas_user_main_account","=", "user_email",$email."' or user_phone_no='".$phone);
            if($counts<1){
           $data_insert=array("",$fullname,$lastname,$email,$phone,md5($pass2),"admin","all",$token,$status,$lang,$dates); 
           $status=$register_table->insertField("comas_user_main_account",$data_insert);
           if($status){
             $userdata=array("submit_login"=>"yes","username"=>$email,"password"=>$pass1);
            $this->comasUserLogin($userdata, $url,true);  
           }
           
            }else{
                //user already exist
            }
           
         
         }else{
              echo "<script> alert('Error Happenn') </script>";
             //you must agree to terms and condition
         }
         
     }   
    }
  
    /**
     *This function is used to process user login from comas system 
     * @param type $login
     * @param type $url
     */
  private function comasUserLogin($login,$url,$isnew){
      if(isset($login['submit_login'])){
          $this->activateLogin($login);
        $today=@date("Y-m-d");
         $mydate=@strtotime("+31 day", @strtotime($today));
         $expire=@date("Y-m-d",$mydate);
         $status=0;
          $login_table=new ComasDatabase();
          $package=new ComasDatabase();
          $username=  ComasDatabase::escapeString(trim($login['username']));
          $pass=  md5(ComasDatabase::escapeString(trim($login['password'])));
          if(isset($login['remeber'])){
          $remeber= ComasDatabase::escapeString(trim($login['remember']));
          }else{
              //normal login
          }
          $states=$login_table->selectField("comas_user_main_account",array("user_id,status,activate_token,user_password,user_email,user_fullname,user_type,user_previlege,lang"), "=","user_email",$username."' and user_password='".$pass ,"", "", "", "");
         if($states){
             $user=$login_table->getResultSet();
             $status=$user['status'];
             if($status==0){
                //make default package that means a demo package
                 if($isnew){
                 $data_to_insert=array($user['user_id'],"1",$today,$expire);
             $package->insertField("comas_demo",$data_to_insert); 
                 }
            /*
              $_SESSION['comas_pass']=$user['user_password'];
             $_SESSION['comas_username']=$user['user_email'];
             $_SESSION['comas_user']=$user['user_fullname'];
             $_SESSION['comas_usertype']=$user['user_type'];
             $_SESSION['comas_knownas']=$user['user_id'];
             $_SESSION['comas_previlege']=$user['user_previlege'];
             $_SESSION['clang']=$user['lang'];*/
                 $urls="<a href='http://localhost/~raphaelmartin/NetBeansProjects/mycomas/cuser/index.php?page=login&tk=".$user['activate_token']."' >Click to activate</a>";
                 $statuss=$this->sendverifymail($urls, $user['user_fullname'], $user['user_email'],"service","verify");
                 if($statuss){
                 if(!self::isMob()){
             echo "<meta http-equiv=Refresh content=0;url=index.php?page=sendverify>";
             header("Location:index.php?page=sendverify");   
                 }else{
                 echo "<meta http-equiv=Refresh content=0;url=mobi.php?page=sendverify>";
             header("Location:mobi.php?page=sendverify");     
                 }
                 
                 }else{
                     
                 }
                 
             }else if($status==1){
             $_SESSION['comas_pass']=$user['user_password'];
             $_SESSION['comas_username']=$user['user_email'];
             $_SESSION['comas_user']=$user['user_fullname'];
             $_SESSION['comas_usertype']=$user['user_type'];
             $_SESSION['comas_knownas']=$user['user_id'];
             $_SESSION['comas_previlege']=$user['user_previlege'];
             $_SESSION['clang']=$user['lang'];
            
              
             echo "<meta http-equiv=Refresh content=0;url=".$url.">";
             header("Location:".$url);
             }else{
              echo "invalid account";
             }
             
         } 
          
          
      }
     
     
  }
  
  function activateLogin($logininfo){
      $datas=$_GET;
      $activated=false;
      $login_table=new ComasDatabase();
      $update_table=new ComasDatabase();
    if(isset($datas['page'],$datas['tk'])){
     $token=  ComasDatabase::escapeString($datas['tk']); 
     $username=  ComasDatabase::escapeString($logininfo['username']);
     $pass=  ComasDatabase::escapeString(md5($logininfo['password']));
       $states=$login_table->selectField("comas_user_main_account",array("user_id"), "=","user_email",$username."' and user_password='".$pass."' and activate_token='".$token ,"", "", "", "");
         if($states){
         $user=$login_table->getResultSet();
         $toupdate=array("status"=>1);
         $success=$update_table->updateField("comas_user_main_account",$toupdate,"user_id",$user['user_id']);
        if($success){
            //this is the best success;
            $activated=true;
        }
         }
    }
    return $activated;
  }
  
  function resetPass(){
    $userm=$this->httpResource;
    $database=new ComasDatabase();
    $database1=new ComasDatabase();
    $database2=new ComasDatabase();
    $database3=new ComasDatabase();
    $url="index.php?page=resetlik";
    if(isset($userm['resetpass'])){
     $emails=  ComasDatabase::escapeString(trim($userm['reset_email']));
     if($emails!=""){
     $count=$database->countrows("comas_user_main_account","=","user_email",$emails);
     if($count>0){
         
         $now=@time();
         $sec=@date("s");
         $tomm=  strtotime("+1 day", $now);
      $status=$database2->selectField("comas_user_main_account",array("user_id,user_fullname,lastname"),"=","user_email",$emails,"","","", "");
      if($status){
         
        $user=$database2->getResultSet();
        $username=$user['user_fullname'];
        $userid=$user['user_id'];
        $database3->deleteField("comas_resetpass","userid", $userid);
        $token=$tomm.$sec."_".$now;
        $myid=0;
        $id=  ComasTransaction::getLastId("comas_resetpass","reset_id","reset_id");
        if($id==0){
         $myid=467896;   
        }else{
          $myid=$id+1+$sec;
        }
        $link="<a href='http://localhost/~raphaelmartin/NetBeansProjects/mycomas/cuser/index.php?page=resetor&f=".$myid."&t=".$token."' >Reset Your Password</a>";
        $datas=array($myid,$userid,$now,$tomm,$token);
        $status=$database1->insertField("comas_resetpass", $datas);
        if($status){
          $this->sendverifymail($link, $username, $emails,"service","resetpass"); 
          echo "<meta http-equiv=Refresh content=0;url=".$url.">";
             header("Location:".$url);  
        }
      }
      //send reset link to user emails   
     }else{
         //email not available
     }
    }
    }
  }
  
  function userMails(){
   $userm=$this->httpResource;
   if(isset($userm['send_mail'])){
       $mailer=new MailProcessor("service");
     $names=$userm['username'];
     $email=$userm['usermail'];
     $sms=$userm['sms'];
     $message="User Fullname: ".$names."<br/>Email ".$email."</br>".$sms;
     $mailer->sendMails("User FeedBack", "Support", $message,$email,$names);
   }
   
  }
  
  function showRegistedUser(){
     $database=new ComasDatabase();
     $database1=new ComasDatabase();
     $count=0;
     $showuser="";
     $status=$database->selectField("comas_user_main_account",array("user_id,user_fullname,lastname,user_email,user_phone_no,user_regDate"),"=","user_previlege","all","", "","","");
    if($status){
     $showuser.="<table class='comasadmin_table'><caption>Registered Users</caption><tr><td>Sno</td><td>Names</td><td>Email</td><td>Phone number</td><td>Business</td></td><td>Join Date</td><td>Time Remain</td></tr>" ;  
     $i=1;
     while($rec=$database->getResultSet()){
         $name=$rec['user_fullname']." ".$rec['lastname'];
       $count=$database1->countrows("comas_user_business", "=","biz_owner_id", $rec['user_id']);
     $showuser.="<tr><td>".$i."</td><td>".$name."</td><td>".$rec['user_email']."</td><td>".$rec['user_phone_no']."</td><td>".$count."</td><td>".$rec['user_regDate']."</td><td></td></tr>";
     $i++;
     } 
     $showuser.="</table>";
    }
    return $showuser;
  }
  
  /**
   * 
   * @return string
   */
   public function comasUserEditProfile(){
        $database=new ComasDatabase();
        $username=$_SESSION['comas_knownas'];
        $userdata=$this->httpResource;
             $useredit="";
        if(isset($userdata['change_user'])){
            
            $names=  ComasDatabase::escapeString($userdata['editfullname']);
            $phone=  ComasDatabase::escapeString($userdata['phone']);
            $gender=  ComasDatabase::escapeString($userdata['lastname']);
            
            $state=$database->updateField("comas_user_main_account", array("user_fullname"=>$names,"user_phone_no"=>$phone,"lastname"=>$gender), "user_id", $username);
            if($state){
           $_SESSION['comas_user']=$names;
           echo "<meta http-equiv=Refresh content=0;url=index.php?page=23&sub=24>";
            }
        }
   
        $available=$database->selectField("comas_user_main_account", array("*"), "=", "user_id",$username, "", "", "", "");
        if($available){
            $userinfo=$database->getResultSet();
         $useredit.="<form action='' method='post' data-ajax='false' ><table class='comas_useredit formAlign_hori' ><caption>Edit Personal Info<caption><tr><td>
             <label for=''>Full Name</label><br><input type='text' name='editfullname' value='".$userinfo['user_fullname']."' />
              </td></tr>
              <tr><td><label>Lastname</label><br><input type='text' value='".$userinfo['lastname']."' name='lastname'/></td></tr>
               <tr><td><label>Email</label><br><input type='text' value='".$userinfo['user_email']."' disabled /></td></tr>
             <tr><td><label for=''>Phone Number</label><br><input type='text' name='phone' value='".$userinfo['user_phone_no']."' /></td></tr>
                <tr><td><input type='submit' name='change_user' value='Save' /></td></tr></table></form>";
         
        }
        return $useredit;
      }
 
 function passwordResetor($url){
     
    $user=$this->httpResource;
    $database1=new ComasDatabase();
    $database2=new ComasDatabase();
    $database3=new ComasDatabase();
    if(isset($user['submit_preset'])){
    $tokens=$this->validateToken();
        if(is_array($tokens)){
         $userid=$tokens[0];
         $tokid=$tokens[1];
        $pass1=  ComasDatabase::escapeString($user['pass1']);
        $pass2= ComasDatabase::escapeString($user['pass2']);
        if($pass1==$pass2){
         $status= $database1->selectField("comas_user_main_account",array("user_email,user_password"),"=","user_id",$userid,"","","","");
         if($status){
            
             $user=$database1->getResultSet();
             $email=$user['user_email'];
           $database3->deleteField("comas_resetpass","reset_id", $tokid);
            $passupdate=array("user_password"=>md5($pass1));
            $states=$database2->updateField("comas_user_main_account", $passupdate,"user_id", $userid);
            if($states){
                 echo "<script> alert('hellow freid') </script>";
             
            $userdata=array("submit_login"=>"yes","username"=>$email,"password"=>$pass1);
            $this->comasUserLogin($userdata, $url,false); 
            }else{
              echo "<script> alert('hellow freidns') </script>";   
            }
         }
        
        }else{
          //password didnt match
        }
       
        } else{
        echo "<script> alert('Link Expired or Used') </script>";    
        }   
        
   
    }
 }
 
 /**
  * This method is used to validate reset password token and return the user id from the given table
  * @return array
  */
 function validateToken(){
     
    $puser=$_GET;
    $useid=0;
    $database=new ComasDatabase();
        if(isset($puser['t'],$puser['f'])){
        $token= ComasDatabase::escapeString($puser['t']);
        $id= ComasDatabase::escapeString($puser['f']);
        $today=@time();
       $status=$database->selectField("comas_resetpass",array("userid,reset_id"),"=","reset_id",$id."' and expire_date>'".$today."' and token='".$token,"","","",""); 
       if($status){
         $userid=$database->getResultSet();
        
         $useid=array($userid['userid'],$userid['reset_id']);
       }
        } 
        return $useid;
 }
 function comasChangePassword(){
    $database=new ComasDatabase();
        $username=$_SESSION['comas_knownas'];
        $userdata=$this->httpResource;
             $useredit="";
        if(isset($userdata['change_user_pass'])){
           
            $names=  ComasDatabase::escapeString($userdata['user_email']);
            $phone=  ComasDatabase::escapeString(md5(trim($userdata['user_pass'])));
            $state=$database->updateField("comas_user_main_account", array("user_email"=>$names,"user_password"=>$phone), "user_id", $username);
            if($state){
          
            }
        }
        
   
        $available=$database->selectField("comas_user_main_account", array("*"), "=", "user_id",$username, "", "", "", "");
        if($available){
            $userinfo=$database->getResultSet();
         $useredit.="<form action='' method='post' ><table class='comas_useredit' >
             <td>Change Password</td>
             <tr><td>
             <label for=''>User Name</label><br><input type='text' name='user_email' value='".$userinfo['user_email']."' />
              </td></tr><tr><td><label for=''>Password</label><br><input type='password' name='user_pass'  /></td></tr>
                  <tr><td><input type='submit' name='change_user_pass' value='Save' /></td></tr></form></table>";
         
        }
        return $useredit; 
 }
   /**
    * This method is used to set the user for given business type
    */
static function userPageAccess(){
   // $userbiz1=new ComasDatabase();
    //unset all user previlege
   
    
    $database=new ComasDatabase();
    $user_access=$_SESSION['comas_previlege'];
    $user_id=$_SESSION['comas_knownas'];
    $isbiz=false;
    $userbiz=array();
    if($user_access=="all"){
      //user can access all business //select default bizness id
        $_SESSION['comas_cansee']=$user_access;
        if(isset($_SESSION['biz_id'])){
            
            $bizid=$_SESSION['biz_id'];
            if($bizid>0){
     $isbiz= $database->selectField("comas_user_business", array("biz_type_id","biz_name","user_bizid,currency"), "=","biz_owner_id",$user_id."' and user_bizid='".$bizid, "user_bizid", "asc", "","1"); 
            }else{
          $isbiz= $database->selectField("comas_user_business", array("biz_type_id","biz_name","user_bizid,currency"), "=","biz_owner_id",$user_id, "user_bizid", "asc", "","1");      
              
            }
     
        }else{
            
       $isbiz= $database->selectField("comas_user_business", array("biz_type_id","biz_name","user_bizid,currency"), "=","biz_owner_id",$user_id, "user_bizid", "asc", "","1");      
        }
     if($isbiz){
         $mybiz=$database->getResultSet();
       $_SESSION['biz_id']=$mybiz['user_bizid']; //identity of given business
       $_SESSION['biz_type']=$mybiz['biz_type_id']; //identity of business type
       $_SESSION['biz_name']=$mybiz['biz_name'];
       $_SESSION['currency']=$mybiz['currency'];
      
     }else{
        
       //$_SESSION['biz_id']="0"; //identity of given business
       //$_SESSION['biz_type']="0"; //identity of business type
       //$_SESSION['biz_name']="0";  
     }
    }else{
       
      //user can access some bizness only
       $user_biz=@explode(",", $user_access);
       if(is_array($user_biz)){
           
           $count=count($user_biz);
        
           for($i=0; $i<$count; $i++){
             $userbiz[]=$user_biz[$i]; 
           
           }
             
       }
        $_SESSION['comas_cansee']=$userbiz;
     $isbiz= $database->selectField("comas_user_business", array("biz_type_id","biz_name","user_bizid,currency"), "=","user_bizid",$userbiz[0], "", "", "","1"); 
     if($isbiz){
       
         $mybiz=$database->getResultSet();
       $_SESSION['biz_id']=$mybiz['user_bizid'];
       $_SESSION['biz_type']=$mybiz['biz_type_id'];
       $_SESSION['biz_name']=$mybiz['biz_name'];
        $_SESSION['currency']=$mybiz['currency'];
     }else{
      // $_SESSION['biz_id']="0"; //identity of given business
      // $_SESSION['biz_type']="0"; //identity of business type
       //$_SESSION['biz_name']="0";    
     }
      $_SESSION['comas_cansee']=$userbiz;
    }
    
  
}


/**
 * 
 * This method is used to check if account of the customer has been expired
 * @return boolean
 */
static function isExpired(){
   $isexpired=true;
    $database=new ComasDatabase();
   $database1=new ComasDatabase();
   $checkdemo=new ComasDatabase();
   $dates=@date("Y-m-d");
   $userid= $_SESSION['comas_knownas'];
   $demo=$checkdemo->selectField("comas_demo", array("expire_date"), "=","user_id", $userid."' and expire_date >='".$dates, "", "", "", "");
   if(!$demo){
       
      //demo expired 
      //check if user is the owner
   $found=$database->selectField("comas_feepayment", array("bill_expire_date,bill_package"), "=","user_id", $userid."' and bill_expire_date >='".$dates, "bill_id", "desc", "", "1");
   if($found){
      $bills=$database->getResultSet();
      if($dates!=$bills['bill_expire_date']){
          //account expired
          $_SESSION['bizpack']=$bills['bill_package'];
          $isexpired=false;
      }else{
          $_SESSION['bizpack']="0"; 
      }
   }else{
       //may be is not the owner... use business id
       $bizid=$_SESSION['biz_id'];
      $isbiz= $database1->selectField("comas_user_business", array("biz_owner_id"), "=","user_bizid", $bizid, "user_bizid", "desc", "", "1");
      if($isbiz){
          $owner=$database1->getResultSet();
        $found=$database->selectField("comas_feepayment", array("bill_expire_date,bill_package"), "=","user_id", $owner['biz_owner_id']."' and bill_expire_date>='".$dates, "bill_id", "desc", "", "1");
   if($found){
      $bills=$database->getResultSet();
      if($dates!=$bills['bill_expire_date']){
         
          $_SESSION['bizpack']=$bills['bill_package'];
          $isexpired=false;
      }else{
        $_SESSION['bizpack']="0";   
      }
      
      }else{
       $_SESSION['bizpack']="0";   
      }
      
      }else{
          $_SESSION['bizpack']="0"; 
      }
      
   }
   }else{
       $_SESSION['bizpack']="1";
       $isexpired=false;
   }
  return $isexpired;
}


/**
 * This method is used to check if user has any business in the system
 * @return boolean
 */
function hasBusiness(){
    $hasBusiness=false;
     $database=new ComasDatabase();
   $database1=new ComasDatabase();
   if(isset($_SESSION['comas_knownas'])){
   $userid= $_SESSION['comas_knownas'];
    $founds=$database1->selectField("comas_user_business", array("biz_owner_id"), "=","biz_owner_id", $userid, "user_bizid", "desc", "", "");
    if($founds){
        $hasBusiness=true;
    }else{
        if(isset($_SESSION['biz_id'])){
      $bizid=$_SESSION['biz_id'];
     $isbiz= $database->selectField("comas_user_business", array("biz_owner_id"), "=","user_bizid", $bizid, "user_bizid", "desc", "", "1"); 
     if($isbiz){
      $hasBusiness=true;   
     }
        }
    }
    
   }
  return $hasBusiness;
}

/**
 * This method is used to display the name of given buisness
 * @return String business name
 */
function displayBusinessName(){
    $mybiz="";
    $biz=new AdminFormProcess();
     $biz->selectBusiness();
    if($this->hasBusiness()){
       /*$database1=new ComasDatabase();
      $userid= $_SESSION['comas_knownas'];
      $bizid=$_SESSION['biz_id'];
    $founds=$database1->selectField("comas_user_business", array("*"), "=","user_bizid", $userid."' and biz_type_id='".$bizid, "user_bizid", "desc", "", ""); 
    if($founds){
        $bizname=$database1->getResultSet();
        if(isset($_SESSION['biz_name'])){
        $mybiz=$_SESSION['biz_name'];
        }
    }*/
     if(isset($_SESSION['biz_name'])){
         
        $mybiz=$_SESSION['biz_name'];
        }
    
    }
  return $mybiz;
}

/**
 * This method help users to change their current business on the dashboard
 * @return string
 */
function changeUserBusiness(){
    $mybiz="";
    $selects="";
    
    
    if($this->hasBusiness()){
      $database1=new ComasDatabase();
      $userid= $_SESSION['comas_knownas'];
      $bizid=$_SESSION['biz_type'];
      $userprev=$_SESSION['comas_previlege'];
      $cansee= $_SESSION['comas_cansee'];
      $userbiz="";
      $founds=false;
      if($userprev=='all'){
    $founds=$database1->selectField("comas_user_business", array("*"), "=","biz_owner_id", $userid."' and biz_type_id='".$bizid, "user_bizid", "desc", "", ""); 
      }else{
       if(is_array($cansee)){
          
          $count=count($cansee);
          $last=$count-1;
           for($i=0; $i<$count; $i++){
               if($last==$i){
               $userbiz.="user_bizid='".$cansee[$i]."'";    
               }else{
                $userbiz.="user_bizid='".$cansee[$i]."'  or  ";   
               }
           }
        $founds=$database1->selectField("comas_user_business", array("*"), "=","biz_type_id",$bizid."' and (".$userbiz.") and date_created like '%", "user_bizid", "desc", "", "");    
       }   
      }
    if($founds){
       while($bizname=$database1->getResultSet()){
        $mybiz.="<option value='".$bizname['user_bizid']."'>".$bizname['biz_name']."</option>";
       }
    }
   
    $selects.="<form action='' method='post' data-ajax='false'>
        <select name='selectbiz'>".$mybiz."</select>
            <input type='submit' value='select' name='select_biz' /></form>";
      
    }
   return $selects;
}
  /**
   * This method is used to check if given user has logged in
   * @param type $url
   */
static function comasIsLoggedIn($url){
    if(!isset($_SESSION['comas_user'],$_SESSION['comas_knownas'],$_SESSION['comas_previlege'])){
      echo "<meta http-equiv=Refresh content=0;url=".$url.">";
      $lang="";
      $haslang=false;
      if(isset($_SESSION['clang'])){
        $haslang=true;
       $lang= $_SESSION['clang'];
      }
      
      $status=session_destroy();
      if($status && $haslang){
          session_start();
        $_SESSION['clang']=$lang;   
      }
      exit();
    }
    }
 
    /**
     * This method is used to clear all session variable and logout the client
     * @param type $url
     */
    function comasLogout($url){
        $lang=$_SESSION['clang'];
        $status=session_destroy();
       if($status){
          session_start();
        $_SESSION['clang']=$lang;
       }
     
        echo "<meta http-equiv=Refresh content=0;url=".$url.">";  
    }
    
 static function canAddBussiness(){
     $canadd=false;
      $counts=new ComasDatabase();
        $package=$_SESSION['bizpack'];
         $userid= $_SESSION['comas_knownas'];
        $count=$counts->countrows("comas_user_business","=", "biz_owner_id", $userid);
       switch($package){
         case 0:
             $canadd=false;
             break;
         case 1:
             if($count<1){
              $canadd=true; 
             }
             break;
         case 2:
             if($count<1){
              $canadd=true; 
             }
             break;
         case 3:
               if($count<3){
              $canadd=true; 
             }
             break;
         case 4:
              $canadd=true;
             break;
         default:
             break;
       }
     return $canadd;
 }
 
 static function mobileAgent(){
     $parten="/(android|avantgo|blackbery|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|table t|
         up\.link|webos|wos)/i";
     $subject=$_SERVER["HTTP_USER_AGENT"];
    if(preg_match($parten, $subject)){
        header("Location:mobi.php");
    }
 }
 
 static function isMob(){
     $parten="/(android|avantgo|blackbery|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|table t|
         up\.link|webos|wos)/i";
     $subject=$_SERVER["HTTP_USER_AGENT"];
    if(preg_match($parten, $subject)){
      return true;
    }
 }
 
 function changeLanguage(){
    return "
         <form action='' method='post' id='mynewlang' data-ajax='false'>
         <select name='sel_lang' class='changelang'>
         <option value='default' >Language</option>
         <option value='swahili' >Kiswahili</option>
         <option value='eng'  >English</option>
         </select>
         </form>
         ";
  
 }
 
function userTanzaniaRegions(){
     return "<option>Arusha</option>
<option>Dar es Salaam</option>
<option>Dodoma</option>
<option>Iringa</option>
<option>Kagera</option>
<option>Kigoma</option>
<option>Kilimanjaro</option>
<option>Lindi</option>
<option>Manyara</option>
<option>Mara</option>
<option>Mbeya</option>
<option>Morogoro</option>
<option>Mtwara</option>
<option>Mwanza</option>
<option>Pwani</option>
<option>Rukwa</option>
<option>Ruvuma</option>
<option>Shinyanga</option>
<option>Singida</option>
<option>Tabora</option>
<option>Tanga</option>
<option>Pemba North</option>
<option>Pemba South</option>
<option>Zanzibar Central/South</option>
<option>Zanzibar North</option>
<option>Zanzibar West</option>";
 }
 
 /**
  * This is used to send the confirmation email to user account after registration
  * @param type $link
  * @param type $username
  * @param type $email
  * @return boolean
  */
 
function sendverifymail($link,$username,$email,$sendertype,$emailtype){
   $mail=new MailProcessor($sendertype);
   $sent=false;
   $message='';
   $database=new ComasDatabase();
   $states=$database->selectField("comas_emails",array("email_subject,email_body,email_head,email_footer,email_sign,email_greating"), "=","etype",$emailtype,"","","", "1");
   if($states){
    $sms=$database->getResultSet();
    $subj=$sms['email_subject'];
    $head=$sms['email_head'];
    $body=$sms['email_body'];
    $footer=$sms['email_footer'];
    $greating=$sms['email_greating'];
    $esign=$sms['email_sign'];
    $message.=$greating." ".$username."<br/>".$head."<br/>";
    $message.=$body."<br/>".$link."<br/>".$footer."<br/>".$esign;
    $status=$mail->autoMail($username, $email, $subj, $message);
    if($status){
     $sent=true;   
    }
   }
   return $sent;
 }
 
}
?>

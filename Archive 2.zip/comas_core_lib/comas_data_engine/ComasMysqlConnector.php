<?php
/**
*This template is used to configure database connection.
*@auther raphael martin <rafakingazi@gmail.com>
*/
class ComasMysqlConnector {
   private static $user_loan;
   private static $server_loan;
   private static $code_loan;
   private static $loan_name;
   private static $user_loan1;
   private static $server_loan1;
   private static $code_loan1;
   private static $loan_name1;
   private static $connected;
   var $error="Sorry! Unable to reach given server try again later";

/**
 * This method is used to set given mysql server username password and servername
 * @param type $usename
 * @param type $password
 * @param type $servername
 */
   public static function setServer($usename,$password,$servername){
       self::$user_loan=$usename;
       self::$server_loan=$servername;
       self::$code_loan=$password;

   }
   
   /**
    * This method is used to set database name
    * @param type $databasename
    */
    public static function setApplicant($databasename){

       self::$loan_name1=$databasename;
   }
   
   /**
    * This method is used connect to the given database
    * @return type
    */
   private static function connect(){

       self::$connected= @mysql_connect(self::$server_loan, self::$user_loan, self::$code_loan);

       if(self::$connected){
        return self::$connected;
       }else{
           echo "error no connection";
       }
   }
   
   /**
    * This method help on connecting given database
    * @return type
    */
    public static function connectApl(){
       $connection=self::connect();


       if($connection){

           $database1=@ mysql_select_db(self::$loan_name1,$connection);
           if($database1){
       return self::$connected;
           }else{
              echo "Error data base not found";
           }
       }else{
           echo "error no connection";
       }
   }


}




?>

<?php

require_once(COMASPATH_ROOT."/comas_apps_class/class.menutree.php");
require_once(COMASPATH_ROOT."/comas_apps_class/class.biz_form_processor.php");
require_once(COMASPATH_ROOT."/comas_apps_class/class.comas_usermanager.php");
class PageCreator{
static function head(){
	$header='<a href="#" style="text-decoration:none">COMASI</a>';
	return $header;
}

static function styles($dir_init){
	$styles='
	<!-- 1140px Grid styles for IE -->
	<!--[if lte IE 9]><link rel="stylesheet" href="'.$dir_init.'comas_ui/templates/css/ie.css" type="text/css" media="screen" /><![endif]-->
	<link rel="stylesheet" href="'.$dir_init.'comas_ui/templates/css/1140.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="'.$dir_init.'comas_ui/templates/css/styles.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="'.$dir_init.'comas_ui/templates/js/jstree/!style.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="'.$dir_init.'comas_ui/comas_megamenu/css/dcmegamenu.css" type="text/css"  />
        <link rel="stylesheet" href="'.$dir_init.'comas_plugin/slider/script/flexslider.css" type="text/css"  />
        <link rel="stylesheet" href="'.$dir_init.'comas_plugin/datepicker/jsDatePick_ltr.min.css" />
          ';
	return $styles;
}

static function scripts($dir_init){
	$scripts='
            <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jquery-1.8.3.js"></script>
             
	<script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/css3-mediaqueries.js"></script>
        <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/addnum.js"></script>
        <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jstree/jquery.cookie.js"></script>
            <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jstree/jquery.hotkeys.js"></script>
            <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/dropmenu/liveMenu.min.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jstree/jquery.jstree.js"></script>
          <script type="text/javascript" src="'.$dir_init.'comas_plugin/datepicker/jsDatePick.jquery.min.1.3.js"></script>
            <script type="text/javascript" src="'.$dir_init.'comas_ui/comas_js/comas_ajax.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_plugin/slider/script/jquery.flexslider.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_plugin/ckeditor/ckeditor.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_plugin/ckeditor/ckeditor.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jstree_builder.js"></script>
          
        ';
            
	return $scripts; 
}
static function deskstyles($dir_init){
$styles='
    <link rel="shortcut icon" href="'.$dir_init.'comas_ui/comas_img/favicon.ico" />
    <link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/jquery.mobile-1.2.0.min.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/jquery.mobile.structure-1.2.0.min.css" type="text/css" media="screen" />
            <link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/jquery.mobile.theme-1.2.0.css" type="text/css" media="screen" />
	 <link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/tableone.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/comasitheme1.1.min.css" type="text/css" media="screen" />
          ';
	return $styles;    
}
static function mobistyles($dir_init){
$styles='
    <link rel="shortcut icon" href="'.$dir_init.'comas_ui/comas_img/favicon.ico" />
    <link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/jquery.mobile-1.2.0.min.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/jquery.mobile.structure-1.2.0.min.css" type="text/css" media="screen" />
            <link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/jquery.mobile.theme-1.2.0.css" type="text/css" media="screen" />
	 <link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/tableone.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="'.$dir_init.'comas_ui/mobileui/script/customtheme-1.0.min.css" type="text/css" media="screen" />
          ';
	return $styles;    
}
static function mobiscript($dir_init){
  $scripts='
          <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jquery-1.8.3.js"></script>
          <script type="text/javascript" src="'.$dir_init.'comas_ui/mobileui/script/jquery.mobile-1.2.0.min.js"></script>
         <script type="text/javascript" src="'.$dir_init.'comas_ui/comas_js/ajaxmobipagi.js"></script>
          <script type="text/javascript" src="'.$dir_init.'comas_ui/comas_js/ajaxmobile.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/mobileinit.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/addnum.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_ui/comas_js/googleanalytic.js"></script>
        ';
            
	return $scripts;  
}

static function login($page_obj,$url){
    
      global $userpage;
      $infor=new ComasInformer();
    
   $userpage=$page_obj;
   $login="";
    $page_content=isset($userpage['page'])?$userpage['page']:'index';
    $token=isset($userpage['tk'])?$userpage['tk']:'';
    $urls="index.php";
    if($token!="" && $page_content!="index"){
      $urls.="?page=".$page_content."&tk=".$token;  
    }
    if($page_content=='login'||$page_content=='index'){
	$login='<div style="">
            <h1>COMASI '.$infor->getInfo(23,"Log In").'.</h1>
            <form action="'.$urls.'" method="post" data-ajax="false"> <span>'.$infor->getInfo(20,"Username").'</span>
          <input type="text" name="username" min="0" max="100" placeholder="'.$infor->getInfo(21,"Password1").'"/>
          <br />
          <lable for="passwords"><span>'.$infor->getInfo(21,"Password1").'</span></label>
          <input type="password" name="password" id="passwords" min="0" max="100" placeholder="'.$infor->getInfo(21,"Password1").'"/><br/>
          <!--
           <fieldset data-role="controlgroup">
	   <legend></legend>
	   <input type="checkbox" name="checkbox-agree" id="checkbox-agree" class="custom" data-theme="b" />
	   <label for="checkbox-agree">'.$infor->getInfo(22,"keep me logged in").'!</label>
    </fieldset>-->
          <input type="submit" name="submit_login" value="'.$infor->getInfo(23,"Login").'" min="0" max="100" data-theme="a" /><br/>

          <span class="small_p" >&nbsp; <a href="'.$url.'?page=sendreset">'.$infor->getInfo(22,"Forget Your Password").'</a></span></form></div><div style=""><form action="'.$url.'?page=signup" method="post" data-ajax="false" >
          <input type="submit" value="'.$infor->getInfo(24,"Sign Up Free for 30 days").'" min="0" max="100" data-theme="a" /></form></div>';
    }else{
      $login=  self::publicMainContent($page_obj,false);  
    }
		  return $login;
}

static function passResetor($page_obj,$url){
  global $userpage;
   $infor=new ComasInformer();
   $userpage=$page_obj;
   $login="";
    $page_content=isset($userpage['page'])?$userpage['page']:'resetor';
    if($page_content=='resetor'){
        $urls=$url."?page=resetor&f=".$userpage['f']."&t=".$userpage['t'];
	$login='<div style="">
            <h1>'.$infor->getInfo(28, "COMASI Reset Your Password").'.</h1>
            <form action="'.$urls.'" method="post" data-ajax="false"> 
                <span>'.$infor->getInfo(33, "new Password").'</span>
          <input type="password" name="pass1" min="0" max="100" placeholder="'.$infor->getInfo(33, "new Password").'"/>
          <br />
          <lable for="password"><span>'.$infor->getInfo(32, "Confirm Your Password").'</span></label>
          <input type="password" name="pass2" id="passwords" min="0" max="100" placeholder="'.$infor->getInfo(32, "Confirm Your Password").'"/><br/>
          
          <input type="submit" name="submit_preset" value="'.$infor->getInfo(34, "Reset Password").'" min="0" max="100" data-theme="a" /><br/>
           </form></div>';
    }else{
      $login=  self::publicMainContent($page_obj,false);  
    }
		  return $login;   
}
static function register($page_obj,$url){
     $infor=new ComasInformer();
    global $userpage;
   $userpage=$page_obj;
   $reg='';
    $page_content=isset($userpage['page'])?$userpage['page']:'register';
    if($page_content=='signup'){
     $reg.='   <h1>'.$infor->getInfo(25, "Create a new COMASI Account").'</h1>
     <form action="'.$_SERVER['PHP_SELF'].'" method="post" data-ajax="false">
    <label for="firstname">'.$infor->getInfo(26, "Firstname").':</label>
    <input type="text" id="firstname" name="firstname" placeholder="'.$infor->getInfo(26, "Firstname").'" />
     <label for="lastname">'.$infor->getInfo(27, "Lastname").':</label>
    <input type="text" id="lastname" name="lastname" placeholder="'.$infor->getInfo(27, "Lastname").'" />
    <label for="email">'.$infor->getInfo(31, "Email").':</label>
    <input type="email" id="email" name="email" placeholder="'.$infor->getInfo(31, "Email").'" />
     <label for="phone">'.$infor->getInfo(30, "Mobile phone").':</label>
    <input type="number" id="phone" name="phone" placeholder="'.$infor->getInfo(30, "Mobile phone").'"/>
    <label for="password" >'.$infor->getInfo(33, "Create a Password").':</label>
    <input type="password" name="pass1" id="password" placeholder="'.$infor->getInfo(33, "new password").'" />
  
    <label for="confirm" >'.$infor->getInfo(32, "Confirm Your Password").':</label>
    <input type="password" name="pass2" id="confirm"  placeholder="'.$infor->getInfo(32, "Confirm Your Passowrd").'"/>
    <p> '.$infor->getInfo(35, "By signing up you agree to ").' <a href="">'.$infor->getInfo(46, "Term Of Use").'</a>.</p>
<input type="submit" name="save_register" value="'.$infor->getInfo(24, "Sign Up Free for 30 days").'" data-theme="a"/>

';   
    
    }
    return $reg;
}

static function resetpass($page_obj,$url){
    $infor=new ComasInformer();
    global $userpage;
   $userpage=$page_obj;
   $res='';
    $page_content=isset($userpage['page'])?$userpage['page']:'reset';
    if($page_content=='sendreset'){
        $urls=$url."?page=".$page_content;
      $res=' <h1>'.$infor->getInfo(28, "COAMSI Reset Your Password").'</h1><form action="'.$urls.'" method="post" data-ajax="false" >
    <label for="youremail">'.$infor->getInfo(31, "Email").':</label>
    <input type="email" id="youremail" name="reset_email" value="" placeholder="'.$infor->getInfo(29, "Email Address").'" />
<input type="submit" name="resetpass" value="'.$infor->getInfo(34, "Reset Password").'" data-theme="a"/></form>
<p><a href="'.$url.'">'.$infor->getInfo(23, "Log In").'</a> / <a href="'.$url.'?page=signup">'.$infor->getInfo(24, "Sign Up for 30 days").'</a></p>';  
    } 
    return $res;
}
static function waitVerify($page_obj,$url){
    $infor=new ComasInformer();
  global $userpage;
   $userpage=$page_obj;
   $veri='';
    $page_content=isset($userpage['page'])?$userpage['page']:'verify';
    if($page_content=='sendverify'){
      $veri='  <h1>'.$infor->getInfo(146, "Welcome To COMASI").'</h1>
   <p>'.$infor->getInfo(145, "Successfully registered check your email/phone for activation code").'</p>
   <a href="'.$url.'" data-role="button" data-theme="a">'.$infor->getInfo(147, "Ok").'</a>';  
    }  
    return $veri;
}
static function resetLink($page_obj,$url){
     $infor=new ComasInformer();
  global $userpage;
   $userpage=$page_obj;
   $veri='';
    $page_content=isset($userpage['page'])?$userpage['page']:'reset';
    if($page_content=='resetlik'){
      $veri='   <h1>'.$infor->getInfo(148, "Comasi Service center").'</h1>
          '.$infor->getInfo(149, "<h2>We just emailed you</h2>");  
    }
    return $veri;
}

static function cUser($page_obj,$url){
     global $userpage;
   $userpage=$page_obj;
   $form='';
    $page_content=isset($userpage['page'])?$userpage['page']:'index';
    switch($page_content){
        case 'login':
           $form= self::login($page_obj,$url);
            break;
        case 'signup':
           $form= self::register($page_obj,$url);
            break;
        case 'sendverify':
            $form=self::waitVerify($page_obj,$url);
            break;
        case 'sendreset':
            $form=self::resetpass($page_obj,$url);
            break;
        case 'resetlik':
           $form= self::resetLink($page_obj,$url);
            break;
         case 'resetor':
           $form= self::passResetor($page_obj, $url);
            break;
        default :
            $form= self::login($page_obj,$url);
            break;
      
    }
    return $form;
}
static function menu(){
	$menu='
            <li><a href="#">Setting</a></li>';
			  return $menu;
}

static function leftsidebar(){
    $menupages=new ComasMenu("index.php?");
    $pagelist=$menupages->adminPageMenuTree('comas','');
    $privatepage="";
    $publicpage="";
    $menuowner=$menupages->getMenuOwner();
	$register='<li><a href="#">DashBoard</a></li><li><a href="index.php?page=newpage">Page</a></li>';
        $i=0;
    foreach($pagelist as $value) {
          if($menuowner[$i]=='private'){
            $privatepage.=$value;  
          }else{
           $publicpage.=$value;   
          }  
         
         $i++;
  }
       
       if($privatepage!=''){
           
       $register.="<li><a href='#'>Private Page</a><ul>";
          $register.=$privatepage."</ul></li>";
       }
       if($publicpage!=''){
          $register.="<li><a href='#'>Public page</a><ul>";
          $register.=$publicpage."</ul></li>";
       }
          $register.=' <li><a href="#">Theme</a></li>
           <li><a href="#">Plugins</a></li>
		   <li><a href="#">Billing</a></li>
                  <li><a href="index.php?page=newsystem" title="system like business in this sense">Add System</a></li>
                <li><a href="index.php?page=setsystem" title="system like business in this sense">Set System</a></li>
           ';
		  
		  return $register;

}

static function pagecontents($page_obj){
    $forms="";
    $adminform=new AdminForms();
     global $userpage;
   $userpage=$page_obj;
  
   $page_content=isset($userpage['page'])?$userpage['page']:'index';
   if(preg_match("/[a-zA-Z]/",   $page_content)){
    switch(strtolower($page_content)){
        
    case 'newpage':
        $forms=$adminform->newPageForm('index.php?page='.$page_content);
        break;
    case 'addblock':
        $forms=$adminform->newBlockForm('index.php?page='.$page_content)."<input type='text' />";;
        break;
    case 'blockcontent':
        $forms=$adminform->blockContentForm('index.php?page='.$page_content)."<input type='text' />";;
        break;
    case 'createform':
        $forms=$adminform->formcreator('index.php?page='.$page_content)."<input type='text' />";
        break;
    case 'newsystem':
        $forms=$adminform->addSystem('index.php?page='.$page_content);
        break;
     case 'setsystem':
        $forms=$adminform->comasPageSystem('index.php?page='.$page_content);
        break;
    }
   }else{
       $subpage=isset($userpage['sub'])?$userpage['sub']:'0';
       $nodepage=isset($userpage['node'.$subpage])?$userpage['node'.$subpage]:'0';
       $nodes=isset($userpage['node'.$nodepage])?$userpage['node'.$nodepage]:'0';
     
         
       $forms="";
       if($subpage=='0'){
           
    $pages='index.php?page='.$page_content;
    $forms.=$adminform->manageBlocks( $userpage,$page_content, $pages);
       }
      
       if($nodepage=='0'&& $subpage!='0'){
           //comes sub pages
             $pages='index.php?page='.$page_content."&sub=".$subpage;
      $forms=$adminform->manageBlocks( $userpage,$subpage, $pages);
       }
       
       if($nodes=='0' && $nodepage!='0'){
           //comes nodes pages
            $pages='index.php?page='.$page_content."&sub=".$subpage."&node".$subpage."=".$nodepage;
         $forms=$adminform->manageBlocks( $userpage,$nodepage, $pages);   
      
      
       }
       if($nodes>0){
           $pages='index.php?page='.$page_content."&sub=".$subpage."&node".$subpage."=".$nodepage."&node".$nodepage."=".$nodes; 
           //comes end nodes
         $forms=$adminform->manageBlocks( $userpage,$nodes, $pages);
       }
       
       
      
   }
    
    return $forms;

}

/**
 * default main menu for public page
 */
static function publicMenu(){
    
   return   self::mainMenu('public','normal'); 
}

/**
 * default main menu for private page
 * //this menu for private is left on user choice
 */

static function privateMenu(){
   $menupages=new ComasMenu("index.php?");
   
    $pagelist=$menupages->adminPageMenuTree('private','quickpages');
	$register='';
       
    foreach($pagelist as $value) {
            
         $register.=$value;
  }
       
      return $register;
}

static function privateUsername(){
    $username="";
    
    if(isset($_SESSION['comas_user'])){
        $username.=" Hi,".$_SESSION['comas_user'];
    }
    return $username;
}

/**
 * Main page 
 */

static function mainMenu($viewer){
     $menupages=new ComasMenu("index.php?");
    
    $pagelist=$menupages->adminPageMenuTree($viewer,'normal');
	$register='';
       
    foreach($pagelist as $value) {
            
         $register.=$value;
  }
       
      return $register;
}

/**
 * This method is used to print content to main part of the website
 * @param type $page_obj
 * @return type
 */
static function publicMainContent($page_obj,$hasmenu){
  
 return self::publicPageBuilder($page_obj, 'middle','public',$hasmenu);
}
/**
 * This method is used to print content to the leftside bar of the website
 * @param type $page_obj
 * @return type
 */
static function publicLeftSideBar($page_obj,$hasmenu){
    
    return self::publicPageBuilder($page_obj, 'leftside','public',$hasmenu); 
}

/**
 * This method is used to print content to reghtside bar of the website
 * @param type $page_obj
 * @return type
 */
static function publicRightSideBar($page_obj,$hasmenu){
    return self::publicPageBuilder($page_obj, 'rightside','public',$hasmenu);  
}


/**
 * This method is used to print content to main part of the website
 * @param type $page_obj
 * @return type
 */
static function privateMainContent($page_obj,$hasmenu){

 return self::publicPageBuilder($page_obj, 'middle','private',$hasmenu);
}


/**
 * This method is used to print content to the leftside bar of the website
 * @param type $page_obj
 * @return type
 */
static function privateLeftSideBar($page_obj,$hasmenu){
    $content="";
   
         if($hasmenu){
       $content.=self::mainMenu("private");    
       }
       $content.=self::publicPageBuilder($page_obj, 'leftside','private',$hasmenu);
    return $content;
}

/**
 * This method is used to print content to reghtside bar of the website
 * @param type $page_obj
 * @return type
 */
static function privateRightSideBar($page_obj,$hasmenu){
    return self::publicPageBuilder($page_obj, 'rightside','private',$hasmenu);  
}

static function privateBusinessName(){
    $busname=new ComasUserManager();
   return  $busname->displayBusinessName();
}
/**
 * This method is used to prepare content for either public pages or private pages
 * @param type $page_obj
 * @param type $pageside
 * @return type
 */
static function publicPageBuilder($page_obj,$pageside,$viewer,$hasmenu){
     $pager=new ComasGeneratePage();
  $userpage=$page_obj;
  
   $page_content=isset($userpage['page'])?$userpage['page']:'index';
    $subpage=isset($userpage['sub'])?$userpage['sub']:'0';
       $nodepage=isset($userpage['node'.$subpage])?$userpage['node'.$subpage]:'0';
       $nodes=isset($userpage['node'.$nodepage])?$userpage['node'.$nodepage]:'0';
   
   $forms="";
    if($page_content=='index'){
        
        $database=new ComasDatabase();
       $mydefault=$database->selectField("comas_pages", array("page_id"), "=", "page_name", "Home' or page_name='DashBoard' and page_viewer='".$viewer, "", "","", "");
       if($mydefault){
           $defaultpage=$database->getResultSet();
           $page_content=$defaultpage['page_id'];
       }
    }
       if( $subpage==0){
         
    $pages='index.php?page='.$page_content;
    $forms.= $pager->MyPageContent($pages,$page_content,$pageside,$viewer,true);
       }
      
       if($nodepage=='0'&& $subpage!='0'){
           //comes sub pages
      
             $pages='index.php?page='.$page_content."&sub=".$subpage;
      $forms=$pager->MyPageContent($pages,$subpage,$pageside,$viewer,true);
       }
       
       if($nodes=='0' && $nodepage!='0'){
           //comes nodes pages
            $pages='index.php?page='.$page_content."&sub=".$subpage."&node".$subpage."=".$nodepage;
         
         $forms=$pager->MyPageContent($pages,$nodepage,$pageside,$viewer,true);  
      
      
       }
       
       if($nodes>0){
           
        
           $pages='index.php?page='.$page_content."&sub=".$subpage."&node".$subpage."=".$nodepage."&node".$nodepage."=".$nodes; 
           //comes end nodes
         $forms=$pager->MyPageContent($pages,$nodes,$pageside,$viewer,true);
       }
       
       
      

    
    return $forms; 
}



static function footer_leftsidebar($dir_init){
    $infor=new ComasInformer();
	$menu='<div class="formAlign_hori" > <p>MY COMASI</p>
        <ul >
        <li><a href="'.$dir_init.'index.php" title="comasi login" data-ajax="false">'.$infor->getInfo(23, "Log In").'</a></li>
        <li><a href="'.$dir_init.'index.php?page=signup" title="comasi login" data-ajax="false">'.$infor->getInfo(24, "Sign Up Free for 30 days").'.</a></li>
        <li><a href="'.$dir_init.'index.php?page=11" title="comasi features" data-ajax="false">'.$infor->getInfo(37, "Features").'</a></li>
        
        
        
			</ul></div>';
			return $menu;
}

static function footer_maincontent($dir_init){
    $infor=new ComasInformer();
	$menu='<div class="formAlign_hori" > <p>'.$infor->getInfo(40, "Who Are We?").'</p>
			 <ul >
        <li><a href="'.$dir_init.'index.php?page=41" title="Learn more about us" data-ajax="false">'.$infor->getInfo(41, "About Us").'</a></li>
        <li><a href="'.$dir_init.'index.php?page=42" title="comasi contact us" data-ajax="false">'.$infor->getInfo(42, "Our Contact").'</a></li>
        <li><a href="'.$dir_init.'index.php?page=48" title="comasi FAQ page" data-ajax="false">'.$infor->getInfo(39, "FAQ").'</a></li>
			</ul></div>';
			return $menu;
}

static function footer_middlesidebar($dir_init){
    $infor=new ComasInformer();
	$menu='<div class="formAlign_hori" > <p>'.$infor->getInfo(43, "Security & Privacy Policy").'</p>
			 <ul >
       
        <li><a href="'.$dir_init.'index.php?page=44" title="comasi privacy policy" data-ajax="false">'.$infor->getInfo(45, "Privacy Policy").'</a></li>
        <li><a href="'.$dir_init.'index.php?page=49" title="comasi term of use" data-ajax="false">'.$infor->getInfo(46, "Terms Of Use").'</a></li>

			</ul></div>';
			return $menu;
}
static function maincontent($page){
	$forms=pagecontents($page);
   return $forms;
}
static function footer_rightsidebar($dir_init){
    $infor=new ComasInformer();
	$menu='<div class="formAlign_hori" > <p> '.$infor->getInfo(47, "Follow Us On").'</p>
	<ul style="list-style:none;">
        <li><a href="http://www.facebook.com/comasitz" target="_blank"><img src="comas_ui/comas_img/facebook3.png" /></a></li>
        <!--<li>Twitter</li>
        <li>Google</li>-->
        
       </ul>
        <iframe src="https://www.facebook.com/plugins/like.php?href=http://facebook.com/comasitz"
        scrolling="no" frameborder="0"
        style="border:none; width:200px; height:80px"></iframe></div>';
		return $menu;
}

static function footer_endnote($dir_init){
     $infor=new ComasInformer();
    $lang=new ComasUserManager();
	$menu=$lang->changeLanguage().'<span>COMASI&copy;2013&nbsp;&nbsp;<a href="'.$dir_init.'index.php?page=49" data-ajax="false">'.$infor->getInfo(46, "Term Of Use").'  '.$infor->getInfo(49, "Apply").'</a>.&nbsp;'.$infor->getInfo(50, "All Right Reselved").'</span>
            ';
	return $menu;
}


}
?>


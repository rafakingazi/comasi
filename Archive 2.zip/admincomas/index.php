<?php
session_start();
define("COMAS_EXEC",1);
define('DS', DIRECTORY_SEPARATOR);
//$page=!empty($_GET['page'])?$_GET['page']:'index';
 if (!defined('_JDEFINES')) {
	define('COMASPATH_BASE', dirname(dirname(realpath(__FILE__))));
	 require_once COMASPATH_BASE."/comas_config/ComasDefined.php";
         require_once COMASPATH_BASE."/comas_apps_class/class.pagecreator_helper.php";
         require_once COMASPATH_BASE."/comas_apps/admin_form_creator.php";
          require_once COMASPATH_BASE."/comas_apps/page_creator.php";
}
   $pages=$_GET;
  
include COMASPATH_BASE.'/comas_core_lib/comas_controller/ComasTemplate.php';
$myTemp=new ComasTemplate();

$myTemp->set("title", "My Comas");
$myTemp->set("page_header", PageCreator::head());
$myTemp->set("stylesheet", PageCreator::styles('../'));
$myTemp->set("script",PageCreator::scripts('../'));
$myTemp->set("menu", PageCreator::menu());
$myTemp->set("headercenter","");
$myTemp->set("leftsidebar",PageCreator::leftsidebar());
$myTemp->set("slogan","An Accountant You Can Trust");
$myTemp->set("loginwindow",PageCreator::login());
$myTemp->set("maincontent", PageCreator::pagecontents($pages));
$myTemp->set("footerleftsidebar",PageCreator::footer_leftsidebar('../'));
$myTemp->set("footermaincontent",PageCreator::footer_maincontent('../'));
$myTemp->set("footermiddlesidebar",PageCreator::footer_middlesidebar('../'));
$myTemp->set("footerrightsidebar",PageCreator::footer_rightsidebar('../'));
$myTemp->set("footerendnote",PageCreator::footer_endnote('../'));

$myTemp->display(COMASPATH_BASE."/comas_ui/templates/admintemplates.php");
?>

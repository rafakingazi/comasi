<?php
class ComasCalculator{
    private  $bizid;
    function ComasCalculator($bizid){
        $this->bizid=$bizid;
        //create purchase view
        $purchase="create or replace view purchases as select comas_biz_stock.item_id,comas_biz_stock.item_name";
        $purchase.=",comas_biz_stock.item_unit,comas_biz_stock.quantity,comas_biz_purchase.purchase_id";
        $purchase.=",comas_biz_purchase.cost_per_unit,comas_biz_purchase.price_per_unit,comas_biz_purchase.total_unit";
        $purchase.=",comas_biz_purchase.total_cost,comas_biz_purchase.total_price,comas_biz_purchase.purchase_date,comas_biz_purchase.user_id,comas_biz_purchase.user_bizid,comas_biz_purchase.account_type";
        $purchase.=" from comas_biz_stock inner join comas_biz_purchase on comas_biz_purchase.item_id=comas_biz_stock.item_id";
        @mysql_query($purchase);
        //create sales view
        $sales="create or replace view sales as select comas_biz_stock.item_id,comas_biz_stock.item_name";
        $sales.=",comas_biz_stock.item_unit,comas_biz_stock.quantity,comas_biz_sales.sales_id";
        $sales.=",comas_biz_sales.total_unit_sold,comas_biz_sales.total_amount_received,comas_biz_sales.payment_method";
        $sales.=",comas_biz_sales.account_type,comas_biz_sales.sales_date,comas_biz_sales.user_id,comas_biz_sales.user_bizid";
        $sales.=" from comas_biz_stock inner join comas_biz_sales on comas_biz_sales.item_id=comas_biz_stock.item_id";
        @mysql_query($sales) or die(mysql_error());
        
        //create view expenses
        
    }
    
    /**
     * This method is used to calculate total cost of purchased products by schedule
     * @param type $schedule
     * @param type $byproduct
     * @return array
     */
    function calPurchase($fildata,$byproduct){
        $results="";
       
        $today=@date("Y-m-d");
        if(isset($fildata)){
            
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
           //daily calcultor
      $results=$this->calPurchases($today,$fildata,$byproduct);
            break;
       case 'weekly':
           //weekly calculator
           
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates)." 01:01:01";
       $results=$this->calPurchases($mydates,$fildata, $byproduct);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
      $results=$this->calPurchases($mydates,$fildata, $byproduct);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->calPurchases($mydates,$fildata, $byproduct);
           break;
       case 'all':
           $results=$this->calPurchases("all",$fildata, $byproduct);
           break;
     } 
      //make sure we return an array
     if(!is_array($results)){
        $results=array(0,0,0,0,0); 
     }
     return $results;
    }
    
    private function calPurchases($mydates,$fildata,$byproduct){
          $results="";
        $myproduct=array();
        $collect="";
        $sumunit=0;
        $database=new ComasDatabase();
        $database1=new ComasDatabase();
        $status=false;
        $sumpurchase=0;
       $hasfilter=$this->filterHelper($mydates, $fildata);
     
        if(!($byproduct && $hasfilter[3])){
            if($hasfilter[2]){
             $status= $database->selectField("comas_biz_purchase", array("*"), ">=","purchase_date",$mydates."' and user_bizid='".$this->bizid, "", "", "", "");
           
            }else if($hasfilter[1]){
           $status= $database->selectField("comas_biz_purchase", array("*"), ">=","purchase_date", $fildata[1]."' and purchase_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
           
            }else if($hasfilter[0]){
            $status= $database->selectField("comas_biz_purchase", array("*"), ">=","purchase_date", $mydates."' and user_bizid='".$this->bizid, "", "", "", "");
            
            }
       if($status){
             $i=0;
          while($purchase=$database->getResultSet()){
             $sumpurchase=$sumpurchase+$purchase['total_cost']; 
            ++$i;  
          }
          $results=array($i,$sumpurchase);
       }
        }else{
         $available=$database1->selectField("comas_biz_stock", array("*"), "","" ,"", "", "", "", "");
           
         if($available){
            
             while($product=$database1->getResultSet()){
              if($hasfilter[2]){
             $status= $database->selectField("comas_biz_purchase", array("*"), "=","item_id",$product['item_id']."' and purchase_date >= '".$mydates."' and user_bizid='".$this->bizid, "", "", "", "");
           
            }else if($hasfilter[1]){
           $status= $database->selectField("comas_biz_purchase", array("*"), ">=","item_id",$product['item_id']."' and purchase_date >= '".$fildata[1]."' and purchase_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
           
            }else if($hasfilter[0]){
            $status= $database->selectField("comas_biz_purchase", array("*"), ">=","item_id", $product['item_id']."' and purchase_date >= '".$mydates."' and user_bizid='".$this->bizid, "", "", "", "");
            
            }
              
              if($status){
                  $j=0;
                  $sums=0;
                  $dates="";
                while($prod=$database->getResultSet()){
                  $sums=$sums+$prod['total_cost'];
                  $sumunit=$sumunit+$prod['total_unit'];
                  $dates=$prod['purchase_date'];
                  ++$j;
                }
                $collect=array($j,$sums,$sumunit,$product['item_name'],$dates);
                $myproduct[]=$collect;
              }
             }
             $results=$myproduct;
         }      
        } 
       return $results;
    }
    
    
    function manageSchedule($fildata){
     $results="";
       
        $today=@date("Y-m-d");
        if(isset($fildata)){
            
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
           //daily calcultor
      $results=$today;
            break;
       case 'weekly':
           //weekly calculator
           
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates)." 01:01:01";
       $results=$mydates;
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$mydates;
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$mydates;
           break;
       case 'all':
            $results="all";
           break;
     } 
      //make sure we return an array
     
     return $results;   
    }
    /**
     * $hasfilter=$this->filterHelper($mydates, $fildata);
     
        if(!($byproduct && $hasfilter[3])){
            if($hasfilter[2]){
                
            }else if($hasfilter[1]){
                
            }else if($hasfilter[0]){
                
            }
     * @param type $mydates
     * @param type $fildata
     * @return type
     */
    function filterHelper($mydates,$fildata){
         $from="";
        $to="";
        $itemid="0";
        $hassched=false;
        $hasdate=false;
        $hasboth=false;
        $haspro=false;
        if($mydates==""){
           
        $mydates=$this->manageSchedule($fildata);
        }
        if(isset($fildata[1],$fildata[2])){
            if($fildata[1]!="" && $fildata[2]!=""  ){
                
                $hasdate=true;
               
          $from=$fildata[1];
          $to=$fildata[2];
            }
        }
        if(isset($fildata[3])){
            if($fildata[3]!="" && $fildata[3]!="none"){
                $haspro=true;
             $itemid=$fildata[3];   
            }
        }
        if($mydates!="all"){
           $hassched=true; 
           if(isset($fildata[1],$fildata[2])){
            if($fildata[1]!="" && $fildata[2]!=""){
                $hasboth=true;
          $from=$fildata[1];
          $to=$fildata[2];
            }
        }
        }else{
            // mydates==all
            $mydates="0000-00-00";
        }
        return array($hassched,$hasdate,$hasboth,$haspro,$mydates);
    }
    /**
     * This method is used to calculates all sales of given product and project its results
     * @param type $schedule
     * @param type $byproduct
     * @return array;
     */
    function calSales($fildata,$byproduct){
         $results="";
        
        $today=@date("Y-m-d");
       if(isset($fildata)){
            
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
      
     switch($myschedule){
       case 'daily':
           //daily calcultor
     $results=$this->calSale($today,$fildata,$byproduct);
            break;
       case 'weekly':
           //weekly calculator
           
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates)." 01:01:01";
       $results=$this->calSale($mydates,$fildata,$byproduct);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
     $results=$this->calSale($mydates,$fildata,$byproduct);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->calSale($mydates,$fildata,$byproduct);
           break;
       case "all":
            $results=$this->calSale("all",$fildata,$byproduct);
           break;
     }  
      //make sure we return an array
     if(!is_array($results)){
       $results=array(0,0,0,0,0); 
     }
     return $results;
    }
   
    private function calSale($mydates,$fildata,$byproduct){
         $results="";
        $myproduct=array();
        $collect="";
        $sumunit=0;
        $database=new ComasDatabase();
        $database1=new ComasDatabase();
        $sumsales=0;
        $status=false;
          $hasfilter=$this->filterHelper($mydates, $fildata);
    if(!($byproduct && $hasfilter[3])){
            if($hasfilter[2]){
             $status= $database->selectField("comas_biz_sales", array("*"), ">=","sales_date", $mydates."' and user_bizid='".$this->bizid, "", "", "", "");
              
            }else if($hasfilter[1]){
             $status= $database->selectField("comas_biz_sales", array("*"), ">=","sales_date", $fildata[1]."'  and sales_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
              
            }else if($hasfilter[0]){
             $status= $database->selectField("comas_biz_sales", array("*"), ">=","sales_date", $mydates."' and user_bizid='".$this->bizid, "", "", "", "");
              
            }   
       if($status){
             $i=0;
          while($sales=$database->getResultSet()){
             
             $sumsales=$sumsales+$sales['total_amount_received']+$sales['loan_discount_amount']; 
          
            ++$i;  
          }
          $results=array($i,$sumsales);
       }
        }else{
         $available=$database1->selectField("comas_biz_stock", array("*"), "","" ,"", "", "", "", "");
           
         if($available){
            
             while($product=$database1->getResultSet()){
              if($hasfilter[2]){
            $status= $database->selectField("comas_biz_sales", array("*"), "=","item_id",$product['item_id']."' and sales_date >= '".$mydates."' and user_bizid='".$this->bizid, "", "", "", "");
              
            }else if($hasfilter[1]){
             $status= $database->selectField("comas_biz_sales", array("*"), "=","item_id",$product['item_id']."' and sales_date >= '".$fildata[1]."' and sales_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
               
            }else if($hasfilter[0]){
             $status= $database->selectField("comas_biz_sales", array("*"), "=","item_id",$product['item_id']."' and sales_date >= '".$mydates."' and user_bizid='".$this->bizid, "", "", "", "");
               
            } 
              $status= $database->selectField("comas_biz_sales", array("*"), "=","item_id",$product['item_id']."' and sales_date >= '".$mydates."' and user_bizid='".$this->bizid, "", "", "", "");
              if($status){
                  $j=0;
                  $sums=0;
                  $sumunit=0;
                while($prod=$database->getResultSet()){
                  $sums=$sums+$prod['total_amount_received']+$prod['loan_discount_amount'];
                  $sumunit=$sumunit+$prod['total_unit_sold'];
                  $dates=$prod['sales_date'];
                  ++$j;
                }
                $collect=array($j,$sums,$sumunit,$product['item_name'],$dates);
                $myproduct[]=$collect;
              }
             }
             $results=$myproduct;
         }      
        }
      return $results;
    }
  /**
   * This method is used to calculate all expenses cost at specified time of given business
   * @param type $schedule
   * @param type $byproduct
   * @return array
   */
    function calExpenses($fildata,$byproduct){
      $results="";
        $today=@date("Y-m-d");
        if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
           //daily calcultor
          $results=$this->calExpense($today,$fildata, $byproduct);
            break;
       case 'weekly':
           //weekly calculator
           
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates)." 01:01:01";
       $results=$this->calExpense($mydates,$fildata, $byproduct);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
      $results=$this->calExpense($mydates,$fildata, $byproduct);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->calExpense($mydates,$fildata,$byproduct);
           break;
       case 'all':
           $results=$this->calExpense("all",$fildata,$byproduct);
           break;
     } 
     //make sure we return an array
     if(!is_array($results)){
        $results=array(0,0,0,0,0); 
     }
     return $results;   
    }
    
    private function calExpense($mydates,$fildata,$byproduct){
         $results="";
        $myproduct=array();
        $collect="";
        $database=new ComasDatabase();
        $database1=new ComasDatabase();
        $sumexpes=0;
        $status=false;
       $hasfilter=$this->filterHelper($mydates, $fildata);
     
        if(!($byproduct && $hasfilter[3])){
            if($hasfilter[2]){
             $status= $database->selectField("comas_biz_expenses", array("*"), ">=","expenses_date", $mydates."' and user_bizid='".$this->bizid, "", "", "", "");
           
            }else if($hasfilter[1]){
             $status= $database->selectField("comas_biz_expenses", array("*"), ">=","expenses_date", $fildata[1]." 01:01:01"."' and expenses_date<='".$fildata[2]." 01:01:01"."' and user_bizid='".$this->bizid, "", "", "", "");
           
            }else if($hasfilter[0]){
            $status= $database->selectField("comas_biz_expenses", array("*"), ">=","expenses_date", $mydates."' and user_bizid='".$this->bizid, "", "", "", "");
            
            }
       if($status){
             $i=0;
           while($expenses=$database->getResultSet()){
             $sumexpes=$sumexpes+$expenses['cost_per_unit']; 
            ++$i;  
          }
          $results=array($i,$sumexpes);
       }
        }else{
          $available=$database1->selectField("comas_biz_expenses", array("distinct expenses"), "","" ,"", "", "", "", "");
           
         if($available){
            
             while($product=$database1->getResultSet()){
             if($hasfilter[2]){
             $status= $database->selectField("comas_biz_expenses", array("*"), "=","expenses",$product['expenses']."' and expenses_date >= '".$mydates."' and user_bizid='".$this->bizid, "", "", "", "");
             
            }else if($hasfilter[1]){
             $status= $database->selectField("comas_biz_expenses", array("*"), "=","expenses",$product['expenses']."' and expenses_date >= '".$fildata[1]."' and expenses_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
             
            }else if($hasfilter[0]){
            $status= $database->selectField("comas_biz_expenses", array("*"), "=","expenses",$product['expenses']."' and expenses_date >= '".$mydates."' and user_bizid='".$this->bizid, "", "", "", "");
              }    
              if($status){
                  $j=0;
                  $sums=0;
                while($prod=$database->getResultSet()){
                  $sums=$sums+$prod['cost_per_unit'];
                   $dates=$prod['expenses_date'];
                  ++$j;
                }
                $collect=array($j,$sums,$j,$product['expenses'],$dates);
                $myproduct[]=$collect;
              }
             }
             $results=$myproduct;
         }   
        } 
        return $results;
    }
   /**
    * This method is used to calculate total drawing from given business on given time interval
    * @param type $schedule
    * @return array
    */ 
    function calDrawing($fildata){
        $results="";
        if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
        $today=@date("Y-m-d");
       
     switch($myschedule){
       case 'daily':
       $results=$this->calDrawns($today,$fildata);
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
         $results=$this->calDrawns($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
         $results=$this->calDrawns($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calDrawns($mydates,$fildata);
           break;
       case 'all':
           $results=$this->calDrawns("all",$fildata);
           break;
     }
       //make sure we return an array
     if(!is_array($results)){
       $results=array(0,0,0,0,0); 
     }
     return $results;
    }
    
    private function calDrawns($mydates,$fildata){
        $results="";
        $database=new ComasDatabase();
        $sumexpes=0;
        $status=false;
        $hasfilter=$this->filterHelper($mydates, $fildata);
     
       
            if($hasfilter[2]){
       $status= $database->selectField("comas_biz_draw_account", array("*"), ">=","draw_date", $mydates."' and user_bizid='".$this->bizid, "", "", "", "");
               
            }else if($hasfilter[1]){
          $status= $database->selectField("comas_biz_draw_account", array("*"), ">=","draw_date", $fildata[1]."' and draw_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
            
            }else if($hasfilter[0]){
          $status= $database->selectField("comas_biz_draw_account", array("*"), ">=","draw_date", $mydates."' and user_bizid='".$this->bizid, "", "", "", "");
            
            }
       if($status){
             $i=0;
           while($expenses=$database->getResultSet()){
             $sumexpes=$sumexpes+$expenses['amount_drawn']; 
            ++$i;  
          }
          $results=array($i,$sumexpes);
       }
       return $results;
    }
    
    function calCashDebtors($fildata){
     
      $results="";
      if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
        $today=@date("Y-m-d");
        
     switch($myschedule){
       case 'daily':
           $results=$this->calDebtors($today,$fildata);
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
         $results=$this->calDebtors($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calDebtors($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calDebtors($mydates,$fildata);
           break;
       case 'all':
           $results=$this->calDebtors("all",$fildata);
           break;
     }
     if(!is_array($results)){
        $results=array(0,0,0,0); 
     }
     return $results;
    }
    
    
 private function calDebtors($dates,$fildata){
      $database=new ComasDatabase();
      $sumdebts=0;
      $sumpayeed=0;
      $results="";
      $status=false;
      $hasfilter=$this->filterHelper($dates, $fildata);
     
            if($hasfilter[2]){
         $status= $database->selectField("comas_biz_debtors_acc", array("*"), ">=","debtor_acc_date",$dates."' and user_bizid='".$this->bizid, "", "", "", "");
          
            }else if($hasfilter[1]){
          $status= $database->selectField("comas_biz_debtors_acc", array("*"), ">=","debtor_acc_date",$fildata[1]."' and debtor_acc_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
         
            }else if($hasfilter[0]){
           $status= $database->selectField("comas_biz_debtors_acc", array("*"), ">=","debtor_acc_date",$dates."' and user_bizid='".$this->bizid, "", "", "", "");
        
            }
      if($status){
           $i=0;
        while($prod=$database->getResultSet()){
            if($prod['account_type']==1){
           $sumdebts+=$prod['given_amount'];
           
            }
            
            if($prod['account_type']==0){
           $sumpayeed+=$prod['return_amount'];
           
            }
           $i++;
        } 
        $balance=$sumdebts-$sumpayeed;
        $results=array($i,$balance,$sumdebts,$sumpayeed);
       }  
     return $results;
 } 
 
    function calCashCredits($fildata){
     
      $results="";
      if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
        $today=@date("Y-m-d");
      
     switch($myschedule){
       case 'daily':
           $results=$this->calCreditors($today,$fildata);
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calCreditors($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calCreditors($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calCreditors($mydates,$fildata);
           break;
       case 'all':
           $results=$this->calCreditors("all",$fildata);
           break;
     }
     if(!is_array($results)){
        $results=array(0,0,0,0); 
     }
     return $results;
    }
  private function calCreditors($dates,$fildata){
      $database=new ComasDatabase();
      $sumdebts=0;
      $sumpayeed=0;
      $results="";
      $status=false;
        $hasfilter=$this->filterHelper($dates, $fildata);
     
            if($hasfilter[2]){
            $status= $database->selectField("comas_biz_creditors_acc", array("*"), ">=","creditor_acc_date",$dates."' and user_bizid='".$this->bizid, "", "", "", "");
          
            }else if($hasfilter[1]){
            $status= $database->selectField("comas_biz_creditors_acc", array("*"), ">=","creditor_acc_date",$fildata[1]."' and creditor_acc_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
          
            }else if($hasfilter[0]){
            $status= $database->selectField("comas_biz_creditors_acc", array("*"), ">=","creditor_acc_date",$dates."' and user_bizid='".$this->bizid, "", "", "", "");
          
            }
          
   if($status){
           $i=0;
        while($prod=$database->getResultSet()){
            if($prod['account_side']==0){
           $sumdebts+=$prod['received_amount'];
           
            }
            
            if($prod['account_side']==1){
           $sumpayeed+=$prod['return_amount'];
           
            }
           $i++;
        } 
        $balance=$sumdebts-$sumpayeed;
        $results=array($i,$balance,$sumdebts,$sumpayeed);
       }  
     return $results;
 } 
 
   function calReceivable($fildata){ 
       $results="";
       if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
        $today=@date("Y-m-d");
        
     switch($myschedule){
       case 'daily':
         $results=$this->calReceivables($today,$fildata); 
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calReceivables($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->calReceivables($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calReceivables($mydates,$fildata);
           break;
       case 'all':
        $results=$this->calReceivables("all",$fildata);
           break;
     }
     if(!is_array($results)){
        $results=array(0,0,0,0); 
     }
     return $results;
    }
    
   private function calReceivables($dates,$fildata){
        $database=new ComasDatabase();
      $sumdebts=0;
      $sumpayeed=0;
      $results="";
      $status=false;
      $hasfilter=$this->filterHelper($dates, $fildata);
     
            if($hasfilter[2]){
           $status= $database->selectField("comas_biz_receivable", array("*"), ">=","payable_date", $dates."'  and user_bizid='".$this->bizid, "", "", "", "");
            
            }else if($hasfilter[1]){
          $status= $database->selectField("comas_biz_receivable", array("*"), ">=","payable_date", $fildata[1]."' and payable_date<='".$fildata[2]."'  and user_bizid='".$this->bizid, "", "", "", "");
             
            }else if($hasfilter[0]){
           $status= $database->selectField("comas_biz_receivable", array("*"), ">=","payable_date", $dates."'  and user_bizid='".$this->bizid, "", "", "", "");
            
            }
       if($status){
           $i=0;
        while($prod=$database->getResultSet()){
            if($prod['account_type']==1){
           $sumdebts+=$prod['payable_amount'];
           
            }
            
            if($prod['account_type']==0){
           $sumpayeed+=$prod['payable_amount'];
           
            }
           $i++;
        } 
        $balance=$sumdebts-$sumpayeed;
        $results=array($i,$balance,$sumdebts,$sumpayeed);
       } 
       return $results;
    }
    
    function calDisAllowed($fildata){   
        $today=@date("Y-m-d");
        $results="";
       if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
         $results=$this->calDisAllows($today,$fildata); 
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calDisAllows($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->calDisAllows($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calDisAllows($mydates,$fildata);
           break;
       case 'all':
           $results=$this->calDisAllows("all",$fildata);
           break;
     }
     if(!is_array($results)){
        $results=array(0,0,0,0); 
     }
     return $results;
    }
    
   private function calDisAllows($dates,$fildata){
        $database=new ComasDatabase();
      $sumdebts=0;
      $sumpayeed=0;
      $results="";
      $status=false;
      $hasfilter=$this->filterHelper($dates, $fildata);
    
            if($hasfilter[2]){
            $status= $database->selectField("comas_biz_disallowed", array("*"), ">=","discount_date", $dates."'  and user_bizid='".$this->bizid, "", "", "", "");
          
            }else if($hasfilter[1]){
             $status= $database->selectField("comas_biz_disallowed", array("*"), ">=","discount_date", $fildata[1]."' and discount_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
         
            }else if($hasfilter[0]){
           $status= $database->selectField("comas_biz_disallowed", array("*"), ">=","discount_date", $dates."'  and user_bizid='".$this->bizid, "", "", "", "");
           
            }
        if($status){
           $i=0;
        while($prod=$database->getResultSet()){
            if($prod['account_type']==1){
           $sumdebts+=$prod['discount_amount'];
           
            }
            
            if($prod['account_type']==0){
           $sumpayeed+=$prod['discount_amount'];
           
            }
           $i++;
        } 
        $balance=$sumdebts-$sumpayeed;
        $results=array($i,$balance,$sumdebts,$sumpayeed);
       } 
       return $results;
    }
    
    function calPayable($fildata){   
        $today=@date("Y-m-d");
        $results="";
        if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
         $results=$this->calPayables($today); 
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calPayables($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->calPayables($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calPayables($mydates,$fildata);
           break;
       case 'all':
           $results=$this->calPayables("all",$fildata);
           break;
     }
     if(!is_array($results)){
        $results=array(0,0,0,0); 
     }
     return $results;
    }
    private function calPayables($dates,$fildata){
        $database=new ComasDatabase();
      $sumdebts=0;
      $sumpayeed=0;
      $results="";
      $status=false;
      $hasfilter=$this->filterHelper($dates, $fildata);
     
            if($hasfilter[2]){
        $status= $database->selectField("comas_biz_payable", array("*"), ">=","receivable_date", $dates."'  and user_bizid='".$this->bizid, "", "", "", "");
               
            }else if($hasfilter[1]){
        $status= $database->selectField("comas_biz_payable", array("*"), ">=","receivable_date", $fildata[1]."' and receivable_date<='".$fildata[2]."' and user_bizid='".$this->bizid, "", "", "", "");
               
            }else if($hasfilter[0]){
         $status= $database->selectField("comas_biz_payable", array("*"), ">=","receivable_date", $dates."'  and user_bizid='".$this->bizid, "", "", "", "");
              
            }
       if($status){
           $i=0;
        while($prod=$database->getResultSet()){
            if($prod['account_type']==0){
           $sumdebts+=$prod['receivable_amount'];
           
            }
            
            if($prod['account_type']==1){
           $sumpayeed+=$prod['receivable_amount'];
           
            }
           $i++;
        } 
        $balance=$sumdebts-$sumpayeed;
        $results=array($i,$balance,$sumdebts,$sumpayeed);
       } 
       return $results;
    }
    
    function caliPayable($fildata){ 
        $results="";
        $today=@date("Y-m-d");
        if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
         $results=$this->caliPayables($today,$fildata); 
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->caliPayables($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->caliPayables($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->caliPayables($mydates,$fildata);
           break;
       case 'all':
           $results=$this->caliPayables("all",$fildata);
           break;
     }
     if(!is_array($results)){
        $results=array(0,0,0,0); 
     }
     return $results;
    }
    private function caliPayables($dates,$fildata){
        $database=new ComasDatabase();
      $sumdebts=0;
      $sumpayeed=0;
      $results="";
      $status=false;
      $hasfilter=$this->filterHelper($dates, $fildata);
     
            if($hasfilter[2]){
            $status= $database->selectField("comas_biz_ipayable", array("*"), ">=","interest_date", $dates."'  and user_bizid='".$this->bizid, "", "", "", "");
            
            }else if($hasfilter[1]){
           $status= $database->selectField("comas_biz_ipayable", array("*"), ">=","interest_date", $fildata[1]."' and interest_date<='".$fildata[2]."'  and user_bizid='".$this->bizid, "", "", "", "");
             
            }else if($hasfilter[0]){
            $status= $database->selectField("comas_biz_ipayable", array("*"), ">=","interest_date", $dates."'  and user_bizid='".$this->bizid, "", "", "", "");
            
            }
      if($status){
           $i=0;
        while($prod=$database->getResultSet()){
            if($prod['account_type']==0){
           $sumdebts+=$prod['interest_amount'];
           
            }
            
            if($prod['account_type']==1){
           $sumpayeed+=$prod['interest_amount'];
           
            }
           $i++;
        } 
        $balance=$sumdebts-$sumpayeed;
        $results=array($i,$balance,$sumdebts,$sumpayeed);
       } 
       return $results;
    }
    
    function calStocks($fildata,$byproduct){
       $database=new ComasDatabase();
        $today=@date("Y-m-d");
        if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
          
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $status= $database->selectField("", array("*"), "between", $today."' and '".$mydates, "", "", "", "", "");
       if($status){
           
       }
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $status= $database->selectField("", array("*"), "between", $today."' and '".$mydates, "", "", "", "", "");
       if($status){
           
       }
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $status= $database->selectField("", array("*"), "between", $today."' and '".$mydates, "", "", "", "", "");
       if($status){
           
       }
           break;
     }     
    }
    
    
    function calProfite($fildata){
      $database=new ComasDatabase();
        $today=@date("Y-m-d");
        if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
          
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
           break;
     }
    }
     
   function investedCapital(){
        $results="";
        $cash_bal=new ComasDatabase();
       
        
         $status= $cash_bal->selectField("comas_biz_capital", array("*"), "=","user_bizid",$this->bizid, "", "", "", "");
       if($status){
         $sumdebit=0;
        while($cash=$cash_bal->getResultSet()){
            
         $sumdebit+=$cash['capital_amount'];
      
        } 
        
        $results=array($sumdebit);
       }else{
        $results=array(0);   
       }
     return $results;
   } 
   
   function calAssets($fildata){
      $today=@date("Y-m-d");
      $results="";
        if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
        $results= $this->calAsset($today,$fildata); 
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->calAsset($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calAsset($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calAsset($mydates,$fildata);
           break;
       case 'all':
        $results=$this->calAsset("all",$fildata);
           break;
     }
     return $results;
   }
   function calAsset($dates,$fildata){
       $results="";
        $cash_bal=new ComasDatabase();
       $status=false;
      $hasfilter=$this->filterHelper($dates, $fildata);
    
            if($hasfilter[2]){
            $status= $cash_bal->selectField("comas_biz_asset", array("*"), "=","user_bizid",$this->bizid."' and asset_addedDate>='".$dates, "", "", "", "");
       
            }else if($hasfilter[1]){
            $status= $cash_bal->selectField("comas_biz_asset", array("*"), "=","user_bizid",$this->bizid."' and asset_addedDate>='".$fildata[1]."' and asset_addedDate<='".$fildata[2], "", "", "", "");
             }else if($hasfilter[0]){
           $status= $cash_bal->selectField("comas_biz_asset", array("*"), "=","user_bizid",$this->bizid."' and asset_addedDate>='".$dates, "", "", "", "");
        
            }
        
        if($status){
         $sumdebit=0;
         $sumcredit=0;
        while($cash=$cash_bal->getResultSet()){
            if($cash['account_type']==1){
         $sumdebit+=$cash['asset_cost'];
            }
              if($cash['account_type']==0){
         $sumcredit+=$cash['asset_cost'];
            }
        } 
        $balances=$sumdebit-$sumcredit;
        $results=array($balances,$sumdebit,$sumcredit);
       }else{
         $results=array(0,0,0);   
       }
     return $results;   
   }
   
   function calCashBalances($fildata){
    $today=@date("Y-m-d");
      $results="";
      $result="";
        if(isset($fildata)){
        $myschedule=  strtolower($fildata[0]);
        }else{
            $myschedule="monthly";
        }
     switch($myschedule){
       case 'daily':
        $results= $this->calCashBalance($today,$fildata); 
            break;
       case 'weekly':
           $dates=@strtotime("-7 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
       $results=$this->calCashBalance($mydates,$fildata);
           break;
       case 'monthly':
           $dates=@strtotime("-30 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calCashBalance($mydates,$fildata);
           break;
       case 'yearly':
           $dates=@strtotime("-365 day", @strtotime($today));
	$mydates=@date("Y-m-d",$dates);
        $results=$this->calCashBalance($mydates,$fildata);
           break;
       case 'all':
        $results=$this->calCashBalance("all",$fildata);
           break;
     }
     return $results;   
   }
   function calCashBalance($dates,$fildata){
       $results="";
       $result="";
       $issets=false;
    
        $cash_bal=new ComasDatabase();
        $cash_capital=new ComasDatabase();
       $status=false;
       $state=false;
      $hasfilter=$this->filterHelper($dates, $fildata);
    
            if($hasfilter[2]){
           $status= $cash_bal->selectField("comas_biz_cash", array("*"), "=","user_bizid",$this->bizid, "", "", "", "");
             }else if($hasfilter[1]){
           $status= $cash_bal->selectField("comas_biz_cash", array("*"), "=","user_bizid",$this->bizid."' and cash_date>='".$fildata[1]."' and cash_date<='".$fildata[2], "", "", "", "");
           $state= $cash_capital->selectField("comas_biz_cash", array("*"), "=","user_bizid",$this->bizid."' and cash_date <='".$fildata[1], "", "", "", "");
           
             }else if($hasfilter[0]){
           $status= $cash_bal->selectField("comas_biz_cash", array("*"), "=","user_bizid",$this->bizid, "", "", "", "");
              }
 if($state){
        $sumdebit=0;
         $sumcredit=0;
         $issets=true;
        while($cash=$cash_capital->getResultSet()){
            if($cash['account_type']==1){
         $sumdebit+=$cash['cash_amount'];
            }
              if($cash['account_type']==0){
         $sumcredit+=$cash['cash_amount'];
            }
        } 
        $balances=$sumdebit-$sumcredit;
        $result=array($balances,$sumdebit,$sumcredit);   
       }else{
        $result=array(0,0,0);   
       }
       
       if($status){
         $sumdebit=0;
         $sumcredit=0;
        while($cash=$cash_bal->getResultSet()){
            if($cash['account_type']==1){
         $sumdebit+=$cash['cash_amount'];
            }
              if($cash['account_type']==0){
         $sumcredit+=$cash['cash_amount'];
            }
        } 
        $balances=$sumdebit-$sumcredit+$result[0];
        
        $results=array($balances,$sumdebit,$sumcredit);
       }else{
         $results=array($result[0],0,0);   
       }
       
      
     return array($issets,$results,$result);   
   }
  
   function getAvailableCash(){
     return $this->calCashBalance("all",""); 
   }
    
    
    
}
?>

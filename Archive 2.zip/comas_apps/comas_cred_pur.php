<?php
$bizselector=new AdminFormProcess();
$fileInclude.="<div class='content_box' >".$bizselector->selectCreditor()."</div><br/></div>";
?>

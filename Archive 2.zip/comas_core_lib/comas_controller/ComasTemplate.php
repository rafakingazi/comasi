<?php
require_once 'ComasDataResponder.php';
/**
 * This class used to manage the template of comas system
 */
class ComasTemplate{
    private $template_var=array();
    
 
    /**
     * This method is used to set the set/value pair for given template
     * @param type $key
     * @param type $value
     */
    public function set($key,$value){
        $this->template_var[$key]=$value;
    
    }
    
    /**
     * This method is used to display given content to the browser
     * @param type $filename
     */
 public function display($filename){
   if(file_exists($filename)){
      $output=  file_get_contents($filename);
      foreach ($this->template_var as $key => $value) {
        $output=  preg_replace('/{{'.$key.'}}/', $value, $output); 
          
      }
      echo $output;
   }else{
       
   echo "<html>
   <header><title>Page Not Found 404</title></header>
   <body>
   <h1>Page Not Found</h1></body></html>";
   }
    
 }

}

?>

<?php
  include COMASPATH_BASE.'/comas_apps_class/class.comas_transaction.php';

class ComasFormProcessor extends ComasDataResponder{
     private $databaseObj="";
    private $httpResource="";  
    function ComasFormProcessor(){
     
    $this->databaseObj=new ComasDatabase();
    $this->httpResource=$this->comasRequestProcessor();
    
    }
   
    function processForm(){
        
        $bizdata=$this->httpResource;
        $this->purchaseProcess($bizdata);
        $this->incomeProcess($bizdata);
        $this->stockProcess($bizdata);
        $this->expensesProcess($bizdata);
        $this->drawingProcessor($bizdata);
        $this->assetProcessor($bizdata);
        $this->newDebtorProcessor($bizdata);
        $this->capitalProcess($bizdata);
        $this-> sellOnCreditProcess($bizdata);
        $this->cashDebtProcess($bizdata);
        $this->debtorRuturnProcess($bizdata);
        $this->creditsRuturnProcess($bizdata);
        $this->newCreditorProcessor($bizdata);
        $this->purchaseOnCreditProcess($bizdata);
        $this->LoanProcess($bizdata);
        $this->billProcess($bizdata);
        $this->newlang();
    }
    
    function newlang(){
        $lang=$this->httpResource;
        if(isset($lang['sel_lang'])){
            
            $trans=new AdminFormProcess();
         $_SESSION['clang']=ComasDatabase::escapeString(trim($lang['sel_lang']));
         if(isset($_SESSION['comas_knownas'])){
           $users=new ComasDatabase();
        $users->updateField("comas_user_main_account",array("lang"=>$_SESSION['clang']),"user_id", $_SESSION['comas_knownas']);
         }
         $trans->comasTranslator("translator","none", $_SESSION['clang']);
        }
            }
     function filterByDate(){
         $dates=$this->httpResource;
        if(isset($dates['filterdate'])){
            $dateformat=new ServerValidator();
          $terms= ComasDatabase::escapeString(trim($dates['interms']));
          $datefrom= ComasDatabase::escapeString(trim($dates['filterfrom'])); 
          $dateto= ComasDatabase::escapeString(trim($dates['filterto']));
          $item=0;
          if(isset($_SESSION['raw_from'],$_SESSION['raw_to'])){
              if($datefrom!=$_SESSION['raw_from'] || $dateto!=$_SESSION['raw_to']){
                  $terms="all";
              }
          }
          if(!($terms=="weekly" || $terms=="monthly" || $terms=="yearly")){
              $terms="all";
          }
          if($datefrom!="" && $dateto!=""){
           $_SESSION['fil_from']=$dateformat->mysqlDate($datefrom);
          $_SESSION['fil_to']=$dateformat->mysqlDate($dateto);
          }else{
           $_SESSION['fil_from']="";
          $_SESSION['fil_to']="";    
          }
          $_SESSION['fil_terms']=$terms;
          $_SESSION['raw_from']=$datefrom;
          $_SESSION['raw_to']=$dateto;
          if(isset($dates['itemid'])){
            $item= ComasDatabase::escapeString(trim($dates['itemid'])); 
          }
         
          $_SESSION['fil_item']=$item;
        
          return array($_SESSION['fil_terms'],$_SESSION['fil_from'],$_SESSION['fil_to'],$_SESSION['fil_item']);
        }
    }
    private function billProcess($bill){
      if(isset($bill['send_bill'])){
          $phone=$bill['phone'];
          $codes=$bill['billcode'];
          $package=$bill['billpackage'];
       $processor=new ComasTransaction();
       $processor->billProcessor($phone,$codes,$package);
      }
      
   }
   
   private function capitalProcess($capital){
       if(isset($capital['send_capital'])){
           $processor=new ComasTransaction();
          $amount=$capital['amount'];
          $desc=$capital['description'];
          $i=0;
          if(isset($amount)){
          foreach($amount as $caps){
              $processor->comasCapital($caps, $desc[$i]);
           $i++;   
          }    
          }
       }
       
   }
   private  function purchaseProcess($purchase){
        if(isset($purchase['send_purchase'])){
             $processor=new ComasTransaction();
           //receive all required data and send it to database 
            $item=$purchase['item'];
             $unit=$purchase['unit'];
            $quantity=$purchase['quantity'];
            $buying=$purchase['buyingprice'];
            $selling=$purchase['selling'];
            $receipt=$purchase['receipt'];
            $dates=@date("Y-m-d H:i:s");
           $i=0;
           if(isset($item)){
        foreach($item as $purchased){
           $processor->comasPurchase($purchased, $quantity[$i], $buying[$i], $selling[$i], $receipt[$i],$unit[$i],"falses",$dates); 
            $i++;
        }
           }
          
        }
    }
   
    private function incomeProcess($income){
        if(isset($income['send_income'])){
            
            $processor=new ComasTransaction();
            $item=$income['item'];
            $quantity=$income['quantity'];
            $selling=$income['selling'];
            $receipt=$income['receipt'];
            $realsell=$income['selling_real'];
            $loans=$income['loan'];
            
            $i=0;
            foreach($item as $sales){
              
           $processor->comasSales("1", $sales, $quantity[$i], $selling[$i],$realsell[$i], $receipt[$i],$loans[$i]);
           $i++;
            }
        }
    }
    
    /**
     * This method is used to receive expenses request
     * @param type $expenses
     */
    
    private function expensesProcess($expenses){
        $processor=new ComasTransaction();
        if(isset($expenses['send_expenses'])){
         $item=$expenses['item'];
         $cost=$expenses['cost'];
         $descript=$expenses['description'];
         $exp_start=$expenses['exp_start'];
         $exp_end=$expenses['exp_end'];
         $status=$expenses['pay_status'];
         $i=0;
        foreach($item as $expense){
           $processor->comasExpenses($expense, $cost[$i], $descript[$i], $exp_start[$i],$exp_end[$i],$status[$i]);
        $i++;    
        }
        }
    }
    
    /**
     * this method is used to receive stock request
     * @param type $stock
     */
   private function stockProcess($stock){
       if(isset($stock['send_stock'])){
           $processor=new ComasTransaction();
           $item=$stock['item'];
           $unit=$stock['unit'];
           $quantity=$stock['quantity'];
           $cost=$stock['buyingprice'];
           $sellprice=$stock['selling'];
           $stockdate=$stock['boughtdate'];
           $i=0;
           foreach($item as $stockitem){
         $processor->comasStock($stockitem, $unit[$i], $quantity[$i], $cost[$i], $sellprice[$i],$stockdate[$i]);
         $i++;
           }
           
         
       }
   }
   
   /**
    * This method is used to get drawing request;
    * @param type $drawing
    */
  private function drawingProcessor($drawing){
      if(isset($drawing['send_drawing'])){
          $processor=new ComasTransaction();
          $amount=$drawing['amount'];
          $description=$drawing['description'];
          $dates=$drawing['data'];
          $receipt=$drawing['receipt'];
          $i=0;
          foreach($amount as $drawn){
              $processor->comasDrawings($drawn, $description[$i], $dates[$i], $receipt[$i]);
              $i++;
          }
      }
  }
  
 private function assetProcessor($asset){
     if(isset($asset['send_asset'])){
         $processor=new ComasTransaction();
         $name=$asset['assetname'];
         $assettype=$asset['assettype'];
         $assetcost=$asset['assetcost'];
         $receipt=$asset['receipt'];
         $boughtdate=$asset['boughtdate'];
         $life=$asset['life_time'];
         $i=0;
         foreach ($name as $myasset){
           $processor->comasAsset($myasset, $assettype[$i], $assetcost[$i], $receipt[$i],$boughtdate[$i],$life[$i]);
           $i++;  
         }
     }
 }
 private function sellOnCreditProcess($credit){
      if(isset($credit['comas_send_debt'])){
            
            $processor=new ComasTransaction();
            $item=$credit['item'];
            $quantity=$credit['quantity'];
            $selling=$credit['debt_value'];
            $returndate=$credit['return_date'];
            $realsell=$credit['selling_real'];
            $debtor=$credit['debt_selector'];
            
            $i=0;
            foreach($item as $sales){
              
           $processor->comasSaleOnCredit($debtor,"1",$sales, $quantity[$i], $selling[$i],$realsell[$i],$returndate[$i]);
           $i++;
            }
        } 
 }
 
 private function cashDebtProcess($credit){
    if(isset($credit['save_other_debt'])){
            
            $processor=new ComasTransaction();
            $amount=$credit['debt_amount'];
            $returnamount=$credit['return_amount'];
            $returndate=$credit['return_date'];
            $debtor=$credit['debt_selector'];
          $processor->comasCashDebtor($debtor,$amount,$returnamount,$returndate,"dr");
           
        }   
 }
 private function debtorRuturnProcess($debtor){
       if(isset($debtor['save_repay'])){
     $amount=$debtor['amount_received'];
      $debt_id=$debtor['debt_selector'];
      $debt_type=$debtor['select_debt'];
       $processor=new ComasTransaction();
       $processor->comasDebtRepay($debt_id,$amount,$debt_type,"dr");
       }
 }
 
  private function creditsRuturnProcess($debtor){
       if(isset($debtor['send_loan_returns'])){
     $amount=$debtor['amount_received'];
      $debt_id=$debtor['debt_selector'];
      $debt_type=$debtor['select_debt'];
       $processor=new ComasTransaction();
       $processor->comasDebtRepay($debt_id,$amount,$debt_type,"cr");
       }
 }
 
 private function newDebtorProcessor($debtor){
     if(isset($debtor['send_debtor'])){
         $processor=new ComasTransaction();
         $name=$debtor['debtorname'];
         $phone=$debtor['debtorphone'];
         $email=$debtor['debtoremail'];
         $i=0;
         foreach($name as $mydebtor){
           $processor->comasDebtor($mydebtor, $phone[$i], $email[$i],"dr");  
           $i++;
         }
     }
 }
 
 private function newCreditorProcessor($creditor){
     if(isset($creditor['send_creditor'])){
         $processor=new ComasTransaction();
         $name=$creditor['debtorname'];
         $phone=$creditor['debtorphone'];
         $email=$creditor['debtoremail'];
         $i=0;
         foreach($name as $mydebtor){
           $processor->comasDebtor($mydebtor, $phone[$i], $email[$i],"cr");  
           $i++;
         }
     }   
 }
   
  private  function purchaseOnCreditProcess($purchase){
        if(isset($purchase['send_creditor_pur'])){
             $processor=new ComasTransaction();
           //receive all required data and send it to database 
            $item=$purchase['item'];
             $unit=$purchase['unit'];
            $quantity=$purchase['quantity'];
            $buying=$purchase['buyingprice'];
            $selling=$purchase['selling'];
            $receipt=$purchase['receipt'];
            $creditor=$purchase['select_debt'];
            
           $i=0;
           if(isset($item)){
        foreach($item as $purchased){
           $processor->comasPurchase($purchased, $quantity[$i], $buying[$i], $selling[$i], $receipt[$i],$unit[$i],$creditor); 
            $i++;
        }
           }
          
        }
    }
    
private function LoanProcess($credit){
    if(isset($credit['send_loan'])){
            
            $processor=new ComasTransaction();
            $amount=$credit['debt_amount'];
            $returnamount=$credit['return_amount'];
            $returndate=$credit['return_date'];
            $debtor=$credit['debt_selector'];
          $processor->comasCashDebtor($debtor,$amount,$returnamount,$returndate,"cr");
           
        }   
 }
 
  }
?>

<?php
$base_paths= dirname(dirname(realpath(__FILE__)));
require_once($base_paths."/comas_config/ComasDefined.php");
require_once(COMASPATH_ROOT."/comas_apps_class/class.cmsforms.php");
require_once (COMASPATH_ROOT."/comas_apps_class/class.pagecreator_helper.php");;

class AdminForms{
    private $helper_obj="";
    function AdminForms(){
       $this->helper_obj=new ComasPageCreatorHelper(); 
    }
    /**
     * This method is used to generate new page form used to create the new page
     * @param type $submit_url
     * @return string
     */
    function newPageForm($submit_url){
       $save_form=new  AdminFormProcess();
       $save_form->savePage();
     $forms="
            <p>Create new Page</p>
            <table class='comasadmin_table'><form action='".$submit_url."' method='post'>
            <tr><td><label for='page_name'>Page name</label><br />
            <input type='text' name='page_name' /></td><td>
             <label for='page_title'>Page Title</label><br />
            <input type='text' name='page_title' /></td><td><label for='page_owner'>Page Owner</label><br />
            <select name='page_owner'>
            <option>public</option>
            <option>private</option>
            </select></td></tr>
            <tr><td>
             <label for='page_type'>Page Type</label><br >
            <select name='page_type' >
            <option>normal</option>
            <option>quickpages</option>
            <option>footer</option>
            </select></td><td>
             <label for='page_parent'>Page Parent</label><br>
            <select name='page_parent'>
            <option value='0'>none</option>";
          $forms.=  $save_form->selectPage('');
          $forms.="</select></td><td><label>page template</label><br />
            <select name='template'>
            <option>basic</option></select></td></tr>
            <tr><td>
            <label for=''>Page Description</label><br />
            <input type='text' name='page_decription' />
            </td><td><label for='' >Page System</label><select name='pagesystem' >
            <option value='0' >All System</option>";
          $forms.=$this->selectSystem();
          $forms.="</select></td><td></td></tr>
            <tr><td><input type='submit' value='Update Pages' name='create_newpage' /></td>
            <td></td><td></td></tr>
            </form>
            </table>";
         
     return $forms;
    }
    
    /**
     * This method is used to create a form used to generate the page block
     * @param type $submit_url
     * @param type $pageid
     * @return string
     */
    function newBlockForm($submit_url,$pageid){
         $save_form=new  AdminFormProcess();
       // $parent=$this->helper_obj->pageId();
        $save_form->saveBlocks();
      $forms="<br>
            <h6>Create new Block</h6>
            <table class='comasadmin_table'><form action='".$submit_url."' method='post'>
            <tr><td><label for='block_name'>Block name</label><br />
            <input type='text' name='block_name' /></td><td>
             <label for='block_title'>Block Title</label><br />
            <input type='text' name='block_title' /></td><td><label for='block_owner'>Page name</label><br />
            <select name='block_owner'>";
        $forms.=$save_form->selectPage($pageid);
                    
            $forms.="</select></td><td><label>Extra Atrr</label><br><input type='text' name='extra_attr' /></td>
            <td><label>Block Order</label><br/><select name='blockorder' ><option>0</option>
            <option>1</option><option>2</option>
            <option>3</option> <option>4</option>
             <option>5</option> <option>6</option>
             <option>7</option> <option>8</option>
              <option>9</option> <option>10</option>
               <option>11</option> <option>12</option>
            </select></td></tr><tr><td>
             <label for='block_parent'>Block Parent</label><br >
            <select name='block_parent' >
            <option value='0'>none</option>";
            $forms.=$save_form->selectBlock($pageid);
            $forms.="</select></td><td>
             <label for='block_location'>Block Location</label><br>
            <select name='block_location'>
             <option value='middle'>middle column</option>
            <option value='leftside'>left column</option>
            <option value='rightside'>right column</option>
            </select></td><td><label for=''>Block Class</label><br />
            <input type='text' name='block_class' /></td>
            <td><label>Block Id attr</label><br />
            <input type='text' name='block_id' /></td></tr>
            <tr><td><input type='submit' value='Update Pages' name='create_newblock' /></td>
            <td></td><td></td></tr>
            </form>
            </table><hr/><br>";
     return $forms;   
    }
    
    /**
     * This method is used to create the content form of the given block
     * @param type $submit_url
     * @return string
     */
    function blockContentForm($submit_url){
        $parent=$this->helper_obj->blockId();
       $forms="
            <h6>Create new Page</h6>
            <table class='comasadmin_table'><form action='".$submit_url."' method='post'>
            <tr><td><label for='page_name'>Page name</label><br />
            <input type='text' name='page_name' /></td><td>
             <label for='page_title'>Page Title</label><br />
            <input type='text' name='page_title' /></td><td><label for='block_name'>Block name</label><br />
            <select name='block_name'>";
         foreach($parent as $key=>$value){
             $forms.="<option value='".$key."'>".$value."</option>";  
          }
            $forms.="</select></td></tr>
            <tr><td>
             <label for='page_type'>Page Type</label><br >
            <select name='page_type' >
            <option>normal</option>
            </select></td><td>
             <label for='page_parent'>Page Parent</label><br>
            <select name='page_parent'>
            <option value='0'>none</option>
            </select></td><td><label>page template</label><br />
            <select name='template'>
            <option>basic</option></select></td></tr>
            <tr><td><input type='submit' value='Update Pages' name='create_newpage' /></td>
            <td></td><td></td></tr>
            </form>
            </table><hr/>";
     return $forms;  
    }
   
    /**
     * This method is used to translate the content of the system
     * @param type $submit_url
     * @return string
     */
    function comasTranslatorForm($submit_url){
        $trans=new  AdminFormProcess();
        $trans->saveTranslated();
       $forms="
            <h6>Translate</h6>
            <table class='comasadmin_table comas_translator'><form action='".$submit_url."' method='post'>
            <tr><td><label for='page_name'>select Content Table</label><br />
           <select name='mypages' class='pager_loader' style='max-width:300px !important; overflow:hidden'>
            <option value='none'>Select Item</option>
           <option value='comas_pages@page_name@page_id'>Menu Title</option>
           <option value='comas_form@form_title@form_id'>Form Title</option>
           <option value='comas_form_elements@element_title@element_id'>Form Element Name</option>
           <option value='comas_pagecontent@content_title@content_id'>Page Title</option>
           <option value='comas_pagecontent@content_body@content_id'>Page Content</option>
           <option value='comas_informer@info@info_id'>Informer</option>
            </select>
             </td><td><label for='page_title'>Select Content</label><br />
            <select name='mycontent' class='transcontent'>
            <option>select Content</option>
            </select></td><td>
            <label for='block_name'>Translate To</label><br />
            <select name='mylang'>
            <option value='swahili'>Kiswahili</option>
            <option value='eng'>English</option>
            <option value='ger'>German</option>
            </select></td><td><label >Content</label><br><input type='radio' name='rtype' value='1' /></td>
            <td><label>Title</label><br><input type='radio' name='rtype' value='2' /></td></tr></table>
            <table class='comasadmin_table'><tr><td>
             <label for='page_type'>Translate</label><br >
            <p><textarea name='mytrans' id='trans_content'></textarea>
            <script> CKEDITOR.replace( 'trans_content',
	{
		extraPlugins : 'devtools'
	,filebrowserBrowseUrl :'../comas_plugin/filemanager/browser/default/browser.html?Connector=../comas_plugin/filemanager/connectors/php/connector.php',
                    filebrowserImageBrowseUrl : '../comas_plugin/filemanager/browser/default/browser.html?Type=Image&Connector=../comas_plugin/filemanager/connectors/php/connector.php',
                    filebrowserFlashBrowseUrl :'../comas_plugin/filemanager/browser/default/browser.html?Type=Flash&Connector=../comas_plugin/filemanager/connectors/php/connector.php',
					filebrowserUploadUrl  :'../comas_plugin/filemanager/connectors/php/upload.php?Type=File',
					filebrowserImageUploadUrl : '../comas_plugin/filemanager/connectors/php/upload.php?Type=Image',
					filebrowserFlashUploadUrl : '../comas_plugin/filemanager/connectors/php/upload.php?Type=Flash'});</script></p>
            </tr>
           </table><table class='comasadmin_table'> <tr><td><input type='submit' value='Save Translated' name='create_translate' /></td>
            <td></td><td></td></tr>
            </form>
            </table><hr/>";
     return $forms;  
    }
    /**
     * This method is used to manage page blocks
     * @param type $pageid
     * @param type $page_url
     * @return string
     */
    function manageBlocks($page_array,$pageid,$page_url){
     $form_url=$page_url.'&content=addform';
     $form_content=$page_url.'&content=addcontent';
     $form_report=$page_url.'&content=addreport';
     $external_file=$page_url.'&content=fileinclude';
        $forms="";
       $cleanId=trim(ComasDatabase::escapeString($pageid));
      //page information
        $forms.=$this->addBlockContents($page_array,$form_url,$form_content,$form_report,$external_file);  
        $forms.=$this->blockpage($cleanId);
      //block editing pannel
       $forms.=$this->newBlockForm($page_url,$cleanId);
       
       $forms.=$this->listOfBlocks($cleanId,$page_url);
      return $forms;
    }
    
    /**
     * This method is used to display page information and edit them when required
     * @param type $page_id
     */
    function blockpage($pageId){
        
        $forms="";
        $database=new ComasDatabase();
       $database->selectField("comas_pages",array("*"),"=","page_id", $pageId, "","","", "");
      while($mypage=$database->getResultSet()){
      $forms.="<input type='text' name='page_name' value='".$mypage['page_name']."'>";   
      }
      return $forms;  
    }
    
    /**
     * This method is used to display blocks with their properties or contented in a table
     * @param type $pageId
     * @return string
     */
    function listOfBlocks($pageId,$page_url){
        $postdata=$_POST;
        $contviewer=new  AdminFormProcess();
        $contviewer->updateBlock();
        $tocontent=$page_url."&content=addcontent";
        $forms="";
        $status=false;
        $database1=new ComasDatabase();
        $database2=new ComasDataBase();
        $database2->selectField("comas_pages",array("*"),"=","page_id", $pageId, "","","", "");
        $page=$database2->getResultSet();
        if(isset($postdata['block_child'])){
            $parent=  ComasDatabase::escapeString($postdata['block_id']);
            if($parent!=0 && $parent!=""){
       $status=$database1->selectField("comas_blocks",array("*"),"=","page_id", $pageId."' and block_parent='".$parent, "","","", "");
            }else{
        $status=$database1->selectField("comas_blocks",array("*"),"=","page_id", $pageId."' and block_parent='0", "","","", "");        
            }
        }else{
       $status=$database1->selectField("comas_blocks",array("*"),"=","page_id", $pageId."' and  block_parent='0", "","","", "");     
        }
      if($status){
          //table representing all blocks for this page
          $forms.="<h6>".$page['page_name']." page Blocks</h6>";
        $forms.="<table class='comasadmin_table'><tr><td></td><td>Block Name</td><td>Block class</td><td>Id Attr</td><td>Extra Attr</td><td>BlockOrder</td><td>Visible</td><td>Action</td></tr>";
      while($myblock=$database1->getResultSet()){
          //$_SESSION['block_id']=$myblock['block_id'];
      $forms.="<tr><td><form action='".$page_url."' method='post' ><input type='checkbox' /></td>
          <td><input type='text' name='block_name' value='".$myblock['block_name']."'></td>";
      $forms.="<td><input type='text' name='b_classat' value='".$myblock['block_class_attr']."' /></td><td>";
      $forms.="<input type='text' name='b_idat' value='".$myblock['block_id_attr']."'/></td>
          <td><input type='text' name='b_extra' value='".$myblock['b_extra']."'/></td>
          <td><input type='text' name='blockorder' value='".$myblock['block_order']."'/></td><td><input type='checkbox'/></td>";
      $forms.="<td> <input type='hidden' value='".$myblock['block_id']."' name='block_id' /><input type='submit' name='update_block' value='Update'/><input type='submit' name='delete_block' value='Delete' /></form>
          <form action='".$tocontent."_".$myblock['block_id']."' method='post'>
              <input type='hidden' value='".$myblock['block_id']."' name='block_id' />
                  <input type='submit' value='Add Content' name='block_content' />
                  <input type='submit' value='Block Child'name='block_child' />
                  </form>
                  <form action='".$page_url."' method='post'>
              <input type='hidden' value='".$myblock['block_id']."' name='block_id' />
                  <input type='submit' value='View Content' name='view_content' />
                  </form></td></tr>";
      }
      $forms.="</table>";
      } 
      $forms.="<hr/>".$contviewer->viewBlockContent($page_url);
     
      return $forms;
    }
    
    
    
    /**
     * This method is used to create new form to the database
     * @param type $submit_url
     * @return string
     */
    function formcreator($submit_url){
        $parent=$this->helper_obj->blockId();
         
         $forms="
            <h6>Create new Page</h6>
            <table class='comasadmin_table' ><form action='".$submit_url."' method='post'>
            <tr><td><label for='page_name'>Page name</label><br />
            <input type='text' name='page_name' /></td><td>
             <label for='page_title'>Page Title</label><br />
            <input type='text' name='page_title' /></td><td><label for='block_name'>Block name</label><br />
            <select name='block_name'>";
         foreach($parent as $key=>$value){
             $forms.="<option value='".$key."'>".$value."</option>";  
          }
                    
            $forms.="</select></td></tr>
            <tr><td>
             <label for='page_type'>Page Type</label><br >
            <select name='page_type' >
            <option>normal</option>
            </select></td><td>
             <label for='page_parent'>Page Parent</label><br>
            <select name='page_parent'>
            <option value='0'>none</option>
            </select></td><td><label>page template</label><br />
            <select name='template'>
            <option>basic</option></select></td></tr>
            <tr><td><input type='submit' value='Update Pages' name='create_newpage' /></td>
            <td></td><td></td></tr>
            </form>
            </table><hr/><br/>";
     return $forms;
    }
    
 
    /**
     * This field is used to set a block content 
     * @param type $pages
     * @param type $form_url
     * @param type $form_content
     * @return string
     */
    function addBlockContents($pages,$form_url,$form_content,$form_report,$external_files){
        $save_form=new  AdminFormProcess();
     
        $forms="";
      if(isset($pages['content'])){
     $geturl=@explode('_',$pages['content']);
     if(isset($geturl[1])){
        $_SESSION['block_id']=$geturl[1];  
     }
     $forms.="<p class='admin_tab'><a href='".$form_url."' >Add Form</a>&nbsp;&nbsp;&nbsp;<a href='".$form_content."'>Add Normal Content</a>&nbsp;&nbsp;&nbsp;<a href='".$form_report."'>Create Report</a>&nbsp;&nbsp;&nbsp;<a href='".$external_files."'>Include External Files</a></p>";
     if($pages['content']=='addform'){
        $block_id=isset($pages['block_id'])?$pages['block_id']:'0';
         
         $toforms=$form_url."&actions=newform";
         $makefield=$form_url."&actions=formelem";
     $forms.="<p><a href='".$toforms."'>New Forms</a>&nbsp;&nbsp;&nbsp;<a href='".$makefield."'>Form Attribute</a></p><br>"; 
     if(isset($pages['actions'])){
         
     switch($pages['actions']){
         case 'newform':
             $save_form->saveForm();
           $elementform=$save_form->selectForm($_SESSION['block_id']);
             $forms.="<h6>Create New Form</h6>
                 <form action='".$toforms."' method='post'>
                 <table class='comasadmin_table' ><tr>
                 <td><label for=''>Form Title</label><br><input type='text' name='form_title' />
                 <br><label for=''>Form Parent</label><br><select name='form_parent' >
                 ";
                 $forms.=$elementform;
                 $forms.="<option value='0'>none</option></select>
                 <input type='hidden' name='block_id' value='".$block_id."' /></td>
                 <td><label for=''>Form Name</label><br><input type='text' name='form_name' />
                 <br><label for=''>Form Alignment</label><br><select name='form_align'><option>vertical</option>
                 <option>horizontal</option></select></td>
                 <td><label for=''>Form Class Attr</label><br><input type='text' name='form_class' /></td>
                 <td><label for=''>Form Id Attr</label><br><input type='text' name='form_id' /></td>
                 <td><label for=''>Form Method Attr</label><br><input type='text' name='form_method' /></td>
                 <td><label for=''>Form Action Atrr</label><br><input type='text' name='form_action'></td></tr><tr>
                 <td><input type='button' name='add_row' value='add row' /></td><td><input type='submit' name='create_newform' value='Create Form' /></form></td><td></td></tr></table><hr/><br>";
             break;
         case 'formelem':
             $save_form->saveFormElement();
             $elementform=$save_form->selectForm($_SESSION['block_id']);
             $forms.="<h6>Form Elements</h6>
                 <form action='".$makefield."' method='post'>
                     <label for='' style='font-size:0.8em;'>Form Name</label><br><select name='form_name' >
                 ";
             $forms.=$elementform;
               $forms.= " <option value='0'>NONE</option></select>
                 <table class='comasadmin_table' ><tr>
              
                 <td><label for=''>Element Title</label><br><input type='text' name='element_title' /></td>
                 <td><label for=''>Element Tag Name</label><br><select name='element_tag'>
                 <option>input</option>
                 <option>select</option>
                 <option>textarea</option></select></td>
                 <td><label for=''>Type Attr</label><br><input type='text' name='element_type' /></td>
                 <td><label for=''> Name Attr</label><br><input type='text' name='element_nameattr' /><br>
                 <label for=''> Element Order</label><br><select name='element_order'>
                 <option>0</option><option>1</option><option>2</option><option>3</option><option>4</option>
                 <option>5</option><option>6</option><option>7</option><option>8</option><option>9</option>
                 <option>10</option><option>11</option><option>12</option><option>13</option><option>14</option>
                 <option>16</option><option>17</option><option>18</option><option>19</option><option>20</option>
                 <option>21</option><option>22</option><option>23</option><option>24</option><option>25</option></td>
                 <td><label for=''>Class Attr</label><br><input type='text' name='element_classattr' />
                 <br><label for=''> Id Attr</label><br><input type='text' name='element_idattr' /></td>
                 <td><label for=''>Element Value Attr</label><br><input type='text' name='element_value'>
                 <br><label for=''>Element Status</label><br><input type='text' name='element_status' /></td></tr><tr>
                 <td><input type='button' name='add_row' value='add row' /></td><td><input type='submit' name='create_newelement' value='Save Form Element' /></form></td><td></td></tr></table><hr/><br>";
             break;
     }
     }
     }
     
     //add content to the page
     if($pages['content']=='addcontent'){
        $save_form->saveBlockContent(); 
      $forms.="<br><h6>Add Content</h6><div>
          <form action='".$form_content."' method='post'>
          <input text='text' name='content_title' /><br> 
          <p><textarea name='content_body' id='comas_content'></textarea>
          <script> CKEDITOR.replace( 'comas_content',
	{
		extraPlugins : 'devtools'
	,filebrowserBrowseUrl :'../comas_plugin/filemanager/browser/default/browser.html?Connector=../comas_plugin/filemanager/connectors/php/connector.php',
                    filebrowserImageBrowseUrl : '../comas_plugin/filemanager/browser/default/browser.html?Type=Image&Connector=../comas_plugin/filemanager/connectors/php/connector.php',
                    filebrowserFlashBrowseUrl :'../comas_plugin/filemanager/browser/default/browser.html?Type=Flash&Connector=../comas_plugin/filemanager/connectors/php/connector.php',
					filebrowserUploadUrl  :'../comas_plugin/filemanager/connectors/php/upload.php?Type=File',
					filebrowserImageUploadUrl : '../comas_plugin/filemanager/connectors/php/upload.php?Type=Image',
					filebrowserFlashUploadUrl : '../comas_plugin/filemanager/connectors/php/upload.php?Type=Flash'});</script></p><br>
          <input type='submit' name='create_newcontent' value='Save Content' />
          </form><br></div><hr/><br>";   
     }
     
     //add files to the system
     if($pages['content']=='fileinclude'){
         $save_form->saveExternalFileInfo();
         $forms.="<form action='".$external_files."' method='post'>
             <table class='comasadmin_table'><tr>
             <td>
             <input type='hidden' name='block_id' value='".$_SESSION['block_id']."' />
             <label for=''>File Name</label><br>
             <input type='text' name='file_name' /></td>
             <td><label for=''>File Directory</label><br>
             <input type='text' name='file_dir' /></td>
              <td><label for=''>File Path</label><br>
             <input type='text' name='file_path' /></td>
             <td><label for=''>File Type</label><br>
             <select name='file_type'><option>php</option>
             <option>html</option><option>js</option><option>css</option>
             <option>inc</option></select></td></tr>
             <tr><td></td><td><input type='submit' name='save_file' value='Add File'/></td><td></td></tr></table></form><hr/>";
     }
     //create various reports for the system
     if($pages['content']=='addreport'){
         $toreports=$form_report."&actions=newreport";
         $makereport=$form_report."&actions=reportitems";
         
     $forms.="<p><a href='".$toreports."'>New Report</a>&nbsp;&nbsp;&nbsp;<a href='".$makereport."'>Reports columns</a></p><br>"; 
         if(isset($pages['actions'])){
     switch($pages['actions']){
             case 'newreport':
                 $save_form->saveNewReport();
                 $reportlist=$save_form->selectReport($_SESSION['block_id']);
          $forms.="<h6>Create New Report</h6>
                 <form action='".$toreports."' method='post'>
                 <table class='comasadmin_table' ><tr>
                 <td><label for=''>Report Title</label><br><input type='text' name='report_title' />
                 <br><label for=''>Report Parent</label><br><select name='report_parent' >
                 ";
                 $forms.=$reportlist;
                 $forms.="<option value='0'>none</option></select>
                 <input type='hidden' name='block_id' value='".$_SESSION['block_id']."' /></td>
                 <td><label for=''>Report Name</label><br><input type='text' name='report_name' />
                </td>
                 <td><label for=''>Report Table</label><br><input type='text' name='report_table' /></td>
                 <tr>
                 <td><input type='button' name='add_row' value='add row' /></td><td><input type='submit' name='create_newreport' value='Create Form' /></form></td><td></td></tr></table><hr/><br>";
             
             break;
             case 'reportitems':
         $save_form->saveReportItems();
                 $reportlist=$save_form->selectReport($_SESSION['block_id']);
         $forms.="<br><h6>Create Report</h6><div>
             <form action='".$makereport."' method='post' >
                 <label for='' style='font-size:0.8em;' >Report Title</label><br>
                 <select name='report_id' >";
         $forms.=$reportlist;
               $forms.= "<option value='0'>NONE</option></select>
                  <table class='comasadmin_table' id='report_rows' ><tr>
               
                <td><label for=''>Table Column</label><br><input type='text' name='tablecol[0]' /></td>
                <td><label for=''>Report Column Header</label><br><input type='text' name='headercol[0]' /></td>
                <td><label for=''>Column special Function</label><br><input type='text' name='special[0]' /></td>
                </tr>
               </table>
               <table>
                <tr>
                <td><input type='submit' name='create_report' value='Create Report' /></td>
                <td><input type='button' name='add_reportrows' value='Add Row' class='add_reportrows' /></td></tr></table></form></div><hr/><br>";
         break;
         }
         
         }
     }
      }
     return $forms;
    }
  
    
 function comasMails($submit_url){
  $forms="";
$database=new ComasDatabase();
$forms.=$this->deleteMails();
$forms.=$this->updateMails($submit_url);
$forms.=$this->addNewMail($submit_url);
$status=$database->selectField("comas_emails", array("email_id,email_subject,etype"),"","","","","","","");
if($status){
    $i=1;
    $forms.="<hr/><table class='comasadmin_table'><caption>COMASI MAILS</caption><tr><td>Sno.</td><td>Subject</td><td>Email Category</td><td>Action</td></tr>";
   while( $mail=$database->getResultSet()){
    $forms.="<tr><td>".$i."</td><td>".$mail['email_subject']."</td><td>".$mail['etype']."</td>";
    $forms.="<td><form action='".$submit_url."' method='post' ><input type='hidden' name='id_email' value='".$mail['email_id']."' /><input type='submit' name='edit_mails' value='Edit'/>
        <input type='submit' name='del_mails' value='Remove' /></form></td></tr>";
   
    $i++;
   } 
   $forms.="</table>";
   $forms.="<form action='".$submit_url."' method='post' ><input type='submit' name='add_mails' value='Add Mails' /></form><hr/>";
}else{
 //show create new button 
    $forms.="<form action='".$submit_url."' method='post' ><input type='submit' name='add_mails' value='Add Mails' /></form>";
}

return $forms;
  
 }
 function deleteMails(){
   $save_form=new  AdminFormProcess();
   $database=new ComasDatabase();
   $delete=$save_form->getHttpRequest();
   if(isset($delete['del_mails'])){
       $idz=  ComasDatabase::escapeString($delete['id_email']);
       if($idz>0){
       $status=$database->deleteField("comas_emails", "email_id", $idz);  
       if($status){
           //return success
          
       }
       }
   }
 }
 function updateMails($submit_url){
    $forms="";
   $save_form=new  AdminFormProcess();
  $updates=$save_form->getHttpRequest();
   $save_form->updateMails();
  if(isset($updates['edit_mails'])){
      $ids=  ComasDatabase::escapeString($updates['id_email']);
  
    $database=new ComasDatabase();
    $status=$database->selectField("comas_emails", array("*"),"=","email_id",$ids,"","","","");
    if($status){
        $mail=$database->getResultSet();
    $forms.='<form action="'.$submit_url.'" method="post" >
        
        <input type="hidden" name="idz" value="'.$mail['email_id'].'" /><table class="comasadmin_table"><caption>Update Mail Sender</caption>';
    $forms.='<tr><td>Subject</td><td><input type="text" name="emails" value="'.$mail['email_subject'].'" style="width:400px;"/></td></tr>';
    $forms.='<tr><td>Email Header</td><td><p><textarea name="eheader" id="eheader" >'.$mail['email_head'].'</textarea>'.$this->addEditor("eheader").'</td></tr>';
    $forms.='<tr><td>Email Body</td><td><p><textarea name="ebody" id="ebody">'.$mail['email_body'].'</textarea>'.$this->addEditor("ebody").'</td></tr>';
    $forms.='<tr><td>Email Footer</td><td><p><textarea name="efooter" id="efooter">'.$mail['email_footer'].'</textarea>'.$this->addEditor("efooter").'</td></tr>';
    $forms.='<tr><td>Email Greating</td><td><p><textarea name="egreating" id="egreating">'.$mail['email_greating'].'</textarea>'.$this->addEditor("egreating").'</td></tr>';
    $forms.='<tr> <td>Email Sign</td><td><p><textarea name="esign" id="esign">'.$mail['email_sign'].'</textarea>'.$this->addEditor("esign").'</td></tr>';
    $forms.='<tr><td></td><td><input type="submit" name="update_emails" value="Update" /></td></tr>';
    $forms.='</table></form>';
    
    }
  }
   return $forms;   
 }
 
 function addNewMail($submit_url){
      $forms="";
   $save_form=new  AdminFormProcess();
  $updates=$save_form->getHttpRequest();
   $save_form->saveNewMails();
  if(isset($updates['add_mails'])){
    
    $forms.='<form action="'.$submit_url.'" method="post" >
        
        <table class="comasadmin_table"><caption>Update Mail Sender</caption>';
    $forms.='<tr><td>Subject</td><td><input type="text" name="emails"  style="width:400px;"/></td></tr>';
    $forms.='<tr><td>Category</td><td><select name="ecate"  style="width:400px;"><option>verify</option><option>resetpass</option></select></td></tr>';
    $forms.='<tr><td>Email Header</td><td><p><textarea name="eheader" id="eheader" ></textarea>'.$this->addEditor("eheader").'</td></tr>';
    $forms.='<tr><td>Email Body</td><td><p><textarea name="ebody" id="ebody"></textarea>'.$this->addEditor("ebody").'</td></tr>';
    $forms.='<tr><td>Email Footer</td><td><p><textarea name="efooter" id="efooter"></textarea>'.$this->addEditor("efooter").'</td></tr>';
    $forms.='<tr><td>Email Greating</td><td><p><textarea name="egreating" id="egreating"></textarea>'.$this->addEditor("egreating").'</td></tr>';
    $forms.='<tr> <td>Email Sign</td><td><p><textarea name="esign" id="esign"></textarea>'.$this->addEditor("esign").'</td></tr>';
    $forms.='<tr><td></td><td><input type="submit" name="create_emails" value="Save" /></td></tr>';
    $forms.='</table></form>';
    
   
  }
   return $forms;   
 }
/**
 * This method is used to update mail sender configuration
 * @param type $submit_url
 * @return string
 */
function configEmail($submit_url){
    $forms="";
   $save_form=new  AdminFormProcess();
  $updates=$save_form->getHttpRequest();
   $save_form->saveMailUpdate();
  if(isset($updates['edit_e'])){
      $ids=  ComasDatabase::escapeString($updates['id_mail']);
  
    $database=new ComasDatabase();
    $status=$database->selectField("mailConfig", array("*"),"=","indexed",$ids,"","","","");
    if($status){
        $mail=$database->getResultSet();
    $forms.='<form action="'.$submit_url.'" method="post" >
        
        <input type="hidden" name="ids" value="'.$mail['indexed'].'" /><table class="comasadmin_table"><caption>Update Mail Sender</caption>';
    $forms.='<tr><td>User Email</td><td><input type="text" name="emails" value="'.$mail['m_email'].'" /></td></tr>';
    $forms.='<tr><td>Email Password</td><td><input type="password"  name="pass" value="'.$mail['m_password'].'" /></td></tr>';
    $forms.='<tr><td>From Email</td><td><input type="text" name="efrom" value="'.$mail['m_fromemail'].'" /></td></tr>';
    $forms.='<tr><td>From Name</td><td><input type="text" name="efromname" value="'.$mail['m_fromname'].'" /></td></tr>';
    $forms.='<tr><td>Reply Email</td><td><input type="text" name="replymail" value="'.$mail['m_replyemail'].'" /></td></tr>';
    $forms.='<tr> <td>Reply Name</td><td><input type="text" name="replyname" value="'.$mail['m_replyname'].'" /></td></tr>';
    $forms.='<tr> <td>Hostname</td><td><input type="text" name="hostname" value="'.$mail['m_hostname'].'" /></td></tr>';
    $forms.='<tr><td>Port</td><td><input type="text" name="mport" value="'.$mail['m_port'].'" /></td></tr>';
    $forms.='<tr><td>Ssl</td><td><input type="text" name="essl" value="'.$mail['m_ssl'].'" /></td></tr>';
    $forms.='<tr><td></td><td><input type="submit" name="update_esender" value="Update" /></td></tr>';
    $forms.='</table></form>';
    
    }
  }
   return $forms; 
}
/**
 * This method is used to add new mailer to system
 * @param type $submit_url
 * @return string
 */
function addNewMailer($submit_url){
   $forms="";
   $save_form=new  AdminFormProcess();
  $updates=$save_form->getHttpRequest();
  $save_form->saveNewMailer();
  if(isset($updates['addnew_mail'])){
  
    $forms.='<form action="'.$submit_url.'" method="post" >
       
       <table class="comasadmin_table"> <caption>Create Mail Sender</caption>';
     $forms.='<tr><td>Category</td><td><select name="ecate" ><option>service</option><option>news</option></select></td></tr>';
    $forms.='<tr><td>User Email</td><td><input type="text" name="emails"  /></td></tr>';
    $forms.='<tr><td>Email Password</td><td><input type="password"  name="pass"  /></td></tr>';
    $forms.='<tr><td>From Email</td><td><input type="text" name="efrom" /></td></tr>';
    $forms.='<tr><td>From Name</td><td><input type="text" name="efromname" /></td></tr>';
    $forms.='<tr><td>Reply Email</td><td><input type="text" name="replymail"  /></td></tr>';
    $forms.='<tr> <td>Reply Name</td><td><input type="text" name="replyname"  /></td></tr>';
    $forms.='<tr> <td>Hostname</td><td><input type="text" name="hostname"  /></td></tr>';
    $forms.='<tr><td>Port</td><td><input type="text" name="mport" /></td></tr>';
    $forms.='<tr><td>Ssl</td><td><input type="text" name="essl"  /></td></tr>';
    $forms.='<tr><td></td><td><input type="submit" name="create_esender" value="Create" /></td></tr>';
    $forms.='</table></form>';
    
    }
  
   return $forms;  
}
/**
 * This system is used to delete the given mailer from the system
 */
function deleteMailer(){
     //$forms="";
   $save_form=new  AdminFormProcess();
   $database=new ComasDatabase();
   $delete=$save_form->getHttpRequest();
   if(isset($delete['del_mailer'])){
   $ids=ComasDatabase::escapeString($delete['id_mail']);
   if($ids>0){
    $database->deleteField("mailConfig","indexed", $ids);   
   }
   }
}

/**
 * This method is used to setup mail sender
 * @param type $submit_url
 * @return string
 */
function mailSender($submit_url){
     $forms="";
$database=new ComasDatabase();
$forms.=$this->deleteMailer();
$forms.=$this->configEmail($submit_url);
$forms.=$this->addNewMailer($submit_url);
$status=$database->selectField("mailConfig", array("indexed,m_email,m_hostname,m_port,m_ssl"),"","","","","","","");
if($status){
    $i=1;
    $forms.="<hr/><table class='comasadmin_table'><caption>Mailer</caption><tr><td>Sno.</td><td>User Email</td><td>Hostname</td><td>Port</td><td>SSL</td><td>Action</td></tr>";
   while( $mail=$database->getResultSet()){
    $forms.="<tr><td>".$i."</td><td>".$mail['m_email']."</td><td>".$mail['m_hostname']."</td><td>".$mail['m_port']."</td><td>".$mail['m_ssl']."</td>";
    $forms.="<td><form action='".$submit_url."' method='post' ><input type='hidden' name='id_mail' value='".$mail['indexed']."' /><input type='submit' name='edit_e' value='Edit'/>
        <input type='submit' name='del_mailer' value='Remove' /></form></td></tr>";
   
    $i++;
   } 
   $forms.="</table>";
   $forms.="<form action='".$submit_url."' method='post' ><input type='submit' name='addnew_mail' value='Add Mailer' /></form><hr/>";
}else{
 //show create new button 
    $forms.="<form action='".$submit_url."' method='post' ><input type='submit' name='addnew_mail' value='Add Mailer' /></form>";
}

return $forms;
}
    /**
     * This is used to add new system to database
     * @param type $submit_url
     * @return string
     */
function addSystem($submit_url){
    $save_form=new  AdminFormProcess();
    $save_form->saveNewSystem();
  $forms="";
  $forms.="<table class='comasadmin_table' ><tr>
      <form action='".$submit_url."' method='post'>
      <td><label for='' >System Name</label>
      <select name='system_name' ><option>shop</option>
      <option>Company</option>
      <option>Distributor</option>
      <option>Service Provider</option></select></td><td>
      <label for=''>System Category</label><select name='system_category'><option>service</option>
      <option>sales</option>
      <option>production</option></select></td></tr>
      <tr><td><input type='submit' name='newcomas_biz' value='save' /></td></tr></table>";
  return $forms;
}  
  
/**
 * This method is used to set the given page to its specific system
 * @param type $submit_url
 * @return string
 */
function comasPageSystem($submit_url){
    $save_form=new  AdminFormProcess();
    $save_form->saveSystemPages();
    $mypage="";
    $mysystem="";
    $forms="";
    $databasePage=new ComasDatabase();
    $databaseSystem=new ComasDatabase();
   $ispage= $databasePage->selectField("comas_pages", array("page_id","page_name"), "=", "page_viewer", "private", "", "", "","");
  if($ispage){
     
    while( $pages=$databasePage->getResultSet()){
      $mypage.="<option value='".$pages['page_id']."' >".$pages['page_name']."</option>";  
    }
  } 
  
  $issystem=$databaseSystem->selectField("comas_businesslist", array("biz_name","biz_id"), "", "", "", "", "", "","");
  if($issystem){
      while($system=$databaseSystem->getResultSet()){
         $mysystem.="<option value='".$system['biz_id']."' >".$system['biz_name']."</option>" ;
      }
  }
 $forms.="<form action='".$submit_url."' method='post' ><table class='comasadmin_table'><tr>
     <td>
     <label for='' >Page Name</label><select name='mypage' >".$mypage."</select></td>
         <td><label for=''>System Name</label><select name='mysystem'><option value='0' >All System</option>".$mysystem."</select></td>
             <td><input type='submit' name='comas_setsystem' /></td></tr></table></form>"; 
 return $forms;
}

/**
 * This method is used to select content from the database
 * @return string
 */
function comasSelectContents(){
   $comastrans=isset($_REQUEST['comastrans'])?$_REQUEST['comastrans']:"";
   $database=new ComasDatabase();
   $data="";
   if($comastrans!=""){
       
       $parts=@explode("@", $comastrans);
       if(isset($parts[0])){
          
     $status=$database->selectField($parts[0],array($parts[1],$parts[2]),"!=",$parts[1],"","","","","");
     if($status){
      
      while($result=$database->getResultSet()){
         
        $data.="<option value='".$result[$parts[2]]."' >".$result[$parts[1]]."</option>";
      }
     }
       }
   }
   return $data;
}

/**
 * This method is used to return list of system
 * @return string
 */
function selectSystem(){
    $databaseSystem=new ComasDatabase();
    $mysystem="";
    $issystem=$databaseSystem->selectField("comas_businesslist", array("biz_name","biz_id"), "", "", "", "", "", "","");
  if($issystem){
      while($system=$databaseSystem->getResultSet()){
         $mysystem.="<option value='".$system['biz_id']."' >".$system['biz_name']."</option>" ;
      }
  } 
  return $mysystem;
}

function addEditor($id){
 return "  <script> CKEDITOR.replace( '".$id."',
	{
		extraPlugins : 'devtools'
	,filebrowserBrowseUrl :'../comas_plugin/filemanager/browser/default/browser.html?Connector=../comas_plugin/filemanager/connectors/php/connector.php',
                    filebrowserImageBrowseUrl : '../comas_plugin/filemanager/browser/default/browser.html?Type=Image&Connector=../comas_plugin/filemanager/connectors/php/connector.php',
                    filebrowserFlashBrowseUrl :'../comas_plugin/filemanager/browser/default/browser.html?Type=Flash&Connector=../comas_plugin/filemanager/connectors/php/connector.php',
					filebrowserUploadUrl  :'../comas_plugin/filemanager/connectors/php/upload.php?Type=File',
					filebrowserImageUploadUrl :'../comas_plugin/filemanager/connectors/php/upload.php?Type=Image',
					filebrowserFlashUploadUrl :'../comas_plugin/filemanager/connectors/php/upload.php?Type=Flash'});</script></p>" ;  
}

}
?>

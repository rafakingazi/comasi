<?php
session_start();
define("COMAS_EXEC",1);
define('DS', DIRECTORY_SEPARATOR);

 if (!defined('_JDEFINES')) {
	define('COMASPATH_BASE', dirname(dirname(realpath(__FILE__))));
	 require_once COMASPATH_BASE."/comas_config/ComasDefined.php";
          require_once COMASPATH_BASE."/comas_apps/page_creator.php";
          include COMASPATH_BASE.'/comas_apps_class/class.biz_reports.php';
          include COMASPATH_BASE.'/comas_apps_class/class.biz_calculator.php';
          require_once COMASPATH_BASE."/comas_apps_class/class.comas_jsons.php";
          require_once COMASPATH_BASE."/comas_apps/comas_ajax.php";
}

ComasUserManager::comasIsLoggedIn("../index.php");
ComasUserManager::userPageAccess();
ComasUserManager::isExpired();
$reports=new ComasReports();
$pageid=isset($_REQUEST['pageid'])?$_REQUEST['pageid']:0;
$lastid=isset($_REQUEST['lastid'])?$_REQUEST['lastid']:0;

if($lastid!=0){
switch($pageid){
  case 2:
      $cost=isset($_REQUEST['cost'])?$_REQUEST['cost']:0;
     $sell=  isset($_REQUEST['sell'])?$_REQUEST['sell']:0;
      echo $reports->purchaseHistory($lastid,3,$cost,$sell,true,false);
          ;
    break;
}
}


?>

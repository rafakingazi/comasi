<?php
$expired=  ComasUserManager::isExpired();
$filter=new AdminFormProcess();
$infos=new  ComasInformer();
if(!$expired){
$reports=new ComasReports();
$expes=$reports->expensesHistory();
$_SESSION['report']=$expes;
$fileInclude.="<div class='content_box' >".$filter->comasDateFilter(false);
if($expes!=""){
$fileInclude.="<span style='float:right;'> <a href='../reports/reports.php?report=5' data-ajax='false'>PDF</a></span>";

$fileInclude.=$expes."</div></div>";
}else{
  $fileInclude.="".$infos->noRecordsFoundText("eng")."</div></div>";    
}
}else{
 $fileInclude.="<div>".$infos->accountExpireText("eng")."</div></div>";   
}
?>

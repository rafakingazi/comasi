<?php

class ComasMenu{
    private $path="";
    private $menuOwner="";
    function ComasMenu($path){
        $this->path=$path;
    }
    
  
    function adminPageMenuTree($viewer,$page_type){
        $pages=  isset($_GET['page'])?$_GET['page']:"";
       $database=new ComasDatabase();
       $trans=new AdminFormProcess();
       
         $usersystem='0';
         $visited="";
         $title="";
         
       //we need to select page only belong to user business
        if(isset($_SESSION['biz_type'])){
        $usersystem= $_SESSION['biz_type'];
        }
       $menu=array();
       $menuonwer=array();
       if($viewer=='comas'){ 
        $database->selectField("comas_pages", array('page_id,page_name,page_parent,page_order,page_viewer'), "=","page_parent", "0", "page_id", "asc", "", "");       
    
       }else{
       $database->selectField("comas_pages", array('page_id,page_name,page_parent,page_order,page_viewer'), "=","page_parent", "0' and page_viewer='".$viewer."' and (pagesystem='".$usersystem."' or pagesystem='0') and page_type='".$page_type, "page_id", "asc", "", "");    
       }
       $pageTree1="";
       $pageTree2="";
       $pageTree3="";
       while($pageParent=$database->getResultSet()){
       $title=$trans->comasTranslator("comas_pages", $pageParent['page_id'], "eng");
       if($title==""){
        $title=$pageParent['page_name'];
       }
           if($pages==$pageParent['page_id']){
            $visited="class='activepage'";  
           }else if($pages=="" && ($pageParent['page_name']=="home" || $pageParent['page_name']=="dashboard")){
             $visited="class='activepage'";    
           }else{
            $visited="";   
           }
           $pagePath=  $this->path."page=".$pageParent['page_id'];
         
        $pageTree1="<li ".$visited." ><a href='".$pagePath."' data-ajax='false' title='".$title."' >".$title."</a>";
        if($pageParent['page_id']!=0){
            
        $pageTree2=$this->getMenuByParent($pageParent['page_id'], "page_parent", "comas_pages", $pagePath."&sub=",$pageTree1);
       
        }
         $pageTree3="</li>";
         
         $menu[]=$pageTree1."".$pageTree2."".$pageTree3;
         $menuonwer[]=$pageParent['page_viewer'];
       }
       $this->setMenuOwner($menuonwer);
       return $menu;
    }
    
    function getMenuByParent($parentid,$parentcolname,$tablename,$path,$parentlink){
         $database1=new ComasDatabase();
       $trans=new AdminFormProcess();
       $title="";
          
       $status=$database1->selectField($tablename, array('page_id,page_name,page_parent,page_order'), "=",$parentcolname, $parentid, "", "", "", "");
          
       $pageTree="";
       if($status){
          $pageTree.="<ul data-role='listview'>".$parentlink."</li>";
         
       while($pageParent=$database1->getResultSet()){
           $title=$trans->comasTranslator("comas_pages", $pageParent['page_id'], "eng");
       if($title==""){
        $title=$pageParent['page_name'];
       }
           $pagePath=  $path."".$pageParent['page_id'];
        $pageTree.="<li><a href='".$pagePath."' data-ajax='false' title='".$title."' >".$title."</a>";
        //for page with child to child
        
        $pageTree.=$this->getMenuByParent($pageParent['page_id'], "page_parent","comas_pages", $pagePath."&node".$pageParent['page_id']."=","");
         $pageTree.="</li>";   
           
       }
       $pageTree.="</ul>";
     
       }else{
           if($parentlink!=""){
         $pageTree.="<ul data-role='listview'>".$parentlink."</li></ul>";
           }
       }
       return $pageTree;
    }
    
    
    function setMenuOwner($menus){
        $this->menuOwner=$menus;
    }
    function getMenuOwner(){
        return $this->menuOwner;
    }
}
?>

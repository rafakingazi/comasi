<?php
$bizselector=new AdminFormProcess();
$fileInclude.="<div class='content_box' >".$bizselector->selectDebtor()."</div><br/></div>";
?>

<?php

require_once(COMASPATH_ROOT."/comas_apps_class/class.menutree.php");
require_once(COMASPATH_ROOT."/comas_apps_class/class.biz_form_processor.php");
require_once(COMASPATH_ROOT."/comas_apps_class/class.comas_usermanager.php");
class PageCreator{
    
static function head(){
   
	$header='<a href="#">COMASI</a>';
	return $header;
}

static function styles($dir_init){
	$styles='
	<!-- 1140px Grid styles for IE -->
         <link rel="shortcut icon" href="'.$dir_init.'comas_ui/comas_img/favicon.ico" />
	<!--[if lte IE 9]><link rel="stylesheet" href="'.$dir_init.'comas_ui/templates/css/ie.css" type="text/css" media="screen" /><![endif]-->
	<link rel="stylesheet" href="'.$dir_init.'comas_plugin/jqui/themes/jquery.ui.all.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="'.$dir_init.'comas_ui/templates/css/1140.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="'.$dir_init.'comas_ui/templates/css/styles.css" type="text/css" media="screen" />
        <link rel="stylesheet" href="'.$dir_init.'comas_ui/templates/js/jstree/!style.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="'.$dir_init.'comas_ui/comas_megamenu/css/dcmegamenu.css" type="text/css"  />
        <link rel="stylesheet" href="'.$dir_init.'comas_plugin/slider/script/flexslider.css" type="text/css"  />
        <link rel="stylesheet" href="'.$dir_init.'comas_plugin/datepicker/jsDatePick_ltr.min.css" />
   
          ';
	return $styles;
}

static function scripts($dir_init){
	$scripts='
            <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jquery-1.8.3.js"></script>
         <script type="text/javascript" src="'.$dir_init.'comas_plugin/jqui/ui/jquery.ui.core.min.js"></script>
        <script type="text/javascript" src="'.$dir_init.'comas_plugin/jqui/ui/jquery.ui.widget.min.js"></script>
        <script type="text/javascript" src="'.$dir_init.'comas_plugin/jqui/ui/jquery.ui.datepicker.min.js"></script>
	<script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/css3-mediaqueries.js"></script>
        <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/addnum.js"></script>
        <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jstree/jquery.cookie.js"></script>
            <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jstree/jquery.hotkeys.js"></script>
            <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/dropmenu/liveMenu.min.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jstree/jquery.jstree.js"></script>
          <script type="text/javascript" src="'.$dir_init.'comas_plugin/datepicker/jsDatePick.jquery.min.1.3.js"></script>
            <script type="text/javascript" src="'.$dir_init.'comas_ui/comas_js/comas_ajax.js"></script>
             <script type="text/javascript" src="'.$dir_init.'comas_ui/comas_js/ajaxpagination.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_ui/comas_js/ajaxtranslate.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_plugin/slider/script/jquery.flexslider.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_plugin/ckeditor/ckeditor.js"></script>
           <script type="text/javascript" src="'.$dir_init.'comas_plugin/ckeditor/ckeditor.js"></script>
            <script type="text/javascript" src="'.$dir_init.'comas_ui/templates/js/jstree_builder.js"></script>
            <script type="text/javascript" src="'.$dir_init.'comas_ui/comas_js/googleanalytic.js"></script>
        ';
            
	return $scripts; 
}

static function login(){
    $username="";
    $password="";
    if(isset($infoz['20'],$infoz['21'])){
        $username=$infoz['20']."20";
        $password=$infoz['21']."21";
    }else{
        $username="Username1";
        $password="Password2";
    }
	$login='<div style="float:left;" title="comasi login"><form action="'.$_SERVER['PHP_SELF'].'" method="post" data-ajax="false" > <span>'.$username.'</span>
          <input type="text" name="username" data-role="none" placeholder="email"/>
          <br />
          <span>'.$password.'</span>
          <input type="password" name="password" data-role="none" placeholder="password"/><br/>
          <span><input type="checkbox"  name="remember" value="1" data-role="none" />
          keep me logged in!</span>
          <input type="submit" name="submit_login" value="Login" data-role="none" /><br/>

          <span class="small_p" data-role="none" >&nbsp; <a href="#">Forget Your Password ?</a></span></form></div><div style="float:left;"><form action="index.php?page=58" method="post" >
          <input type="submit" value="Register" data-role="none" /></form></div>';
		  return $login;
}

static function menu(){
	$menu='
            <li><a href="#">Setting</a></li>';
			  return $menu;
}

static function leftsidebar(){
    $menupages=new ComasMenu("index.php?");
    $pagelist=$menupages->adminPageMenuTree('comas','');
    $privatepage="";
    $publicpage="";
    $menuowner=$menupages->getMenuOwner();
	$register='<li><a href="#">DashBoard</a></li><li><a href="index.php?page=newpage">Page</a></li>';
        $i=0;
    foreach($pagelist as $value) {
          if($menuowner[$i]=='private'){
            $privatepage.=$value;  
          }else{
           $publicpage.=$value;   
          }  
         
         $i++;
  }
       
       if($privatepage!=''){
           
       $register.="<li><a href='#'>Private Page</a><ul>";
          $register.=$privatepage."</ul></li>";
       }
       if($publicpage!=''){
          $register.="<li><a href='#'>Public page</a><ul>";
          $register.=$publicpage."</ul></li>";
       }
          $register.=' <li><a href="#">Theme</a></li>
           <li><a href="#">Plugins</a></li>
		   <li><a href="index.php?page=syusers">Bill Users</a></li>
                  <li><a href="index.php?page=newsystem" title="system like business in this sense">Add System</a></li>
                <li><a href="index.php?page=setsystem" title="system like business in this sense">Set System</a></li>
                <li><a href="index.php?page=translate" title="system like business in this sense">Translator</a></li>
                <li><a href="index.php?page=mails" title="system like business in this sense">auto Mail</a></li>
                <li><a href="index.php?page=mailsetup" title="system like business in this sense">Setup Email</a></li>
           ';
		  
		  return $register;

}

static function pagecontents($page_obj){
    $forms="";
    $adminform=new AdminForms();
    $fromuser=new ComasUserManager();
     global $userpage;
   $userpage=$page_obj;
  
   $page_content=isset($userpage['page'])?$userpage['page']:'index';
   if(preg_match("/[a-zA-Z]/",   $page_content)){
    switch(strtolower($page_content)){
        
    case 'newpage':
        $forms=$adminform->newPageForm('index.php?page='.$page_content);
        break;
    case 'addblock':
        $forms=$adminform->newBlockForm('index.php?page='.$page_content);
        break;
    case 'blockcontent':
        $forms=$adminform->blockContentForm('index.php?page='.$page_content);
        break;
    case 'createform':
        $forms=$adminform->formcreator('index.php?page='.$page_content);
        break;
    case 'newsystem':
        $forms=$adminform->addSystem('index.php?page='.$page_content);
        break;
     case 'setsystem':
        $forms=$adminform->comasPageSystem('index.php?page='.$page_content);
        break;
    case 'translate':
        $forms=$adminform->comasTranslatorForm('index.php?page='.$page_content);
        break;
    case 'mails':
        $forms=$adminform->comasMails('index.php?page='.$page_content);
        break;
     case 'mailsetup':
        $forms=$adminform->mailSender('index.php?page='.$page_content);
        break;
    case 'syusers':
        $forms=$fromuser->showRegistedUser();
        break;
    }
   }else{
       $subpage=isset($userpage['sub'])?$userpage['sub']:'0';
       $nodepage=isset($userpage['node'.$subpage])?$userpage['node'.$subpage]:'0';
       $nodes=isset($userpage['node'.$nodepage])?$userpage['node'.$nodepage]:'0';
     
         
       $forms="";
       if($subpage=='0'){
           
    $pages='index.php?page='.$page_content;
    $forms.=$adminform->manageBlocks( $userpage,$page_content, $pages);
       }
      
       if($nodepage=='0'&& $subpage!='0'){
           //comes sub pages
             $pages='index.php?page='.$page_content."&sub=".$subpage;
      $forms=$adminform->manageBlocks( $userpage,$subpage, $pages);
       }
       
       if($nodes=='0' && $nodepage!='0'){
           //comes nodes pages
            $pages='index.php?page='.$page_content."&sub=".$subpage."&node".$subpage."=".$nodepage;
         $forms=$adminform->manageBlocks( $userpage,$nodepage, $pages);   
      
      
       }
       if($nodes>0){
           $pages='index.php?page='.$page_content."&sub=".$subpage."&node".$subpage."=".$nodepage."&node".$nodepage."=".$nodes; 
           //comes end nodes
         $forms=$adminform->manageBlocks( $userpage,$nodes, $pages);
       }
       
       
      
   }
    
    return $forms;

}

/**
 * default main menu for public page
 */
static function publicMenu(){
    
   return   self::mainMenu('public','normal'); 
}

/**
 * default main menu for private page
 * //this menu for private is left on user choice
 */

static function privateMenu(){
   $menupages=new ComasMenu("index.php?");
   $lang=new ComasUserManager();
    $pagelist=$menupages->adminPageMenuTree('private','quickpages');
	$register='';
    foreach($pagelist as $value) {
            
         $register.=$value;
  }
  $register.="<li>".$lang->changeLanguage()."</li>";
       
      return $register;
}

static function privateUsername(){
    $username="";
    if(isset($_SESSION['comas_user'])){
        $username.=" Hi,".$_SESSION['comas_user'];
    }
    return $username;
}

/**
 * Main page 
 */

static function mainMenu($viewer){
     $menupages=new ComasMenu("index.php?");
    $pagelist=$menupages->adminPageMenuTree($viewer,'normal');
	$register='';
    foreach($pagelist as $value) {
            
         $register.=$value;
  }
       
      return $register;
}

/**
 * This method is used to print content to main part of the website
 * @param type $page_obj
 * @return type
 */
static function publicMainContent($page_obj,$hasmenu){
  
 return self::publicPageBuilder($page_obj, 'middle','public',$hasmenu);
}
/**
 * This method is used to print content to the leftside bar of the website
 * @param type $page_obj
 * @return type
 */
static function publicLeftSideBar($page_obj,$hasmenu){
    
    return self::publicPageBuilder($page_obj, 'leftside','public',$hasmenu); 
}

/**
 * This method is used to print content to reghtside bar of the website
 * @param type $page_obj
 * @return type
 */
static function publicRightSideBar($page_obj,$hasmenu){
    return self::publicPageBuilder($page_obj, 'rightside','public',$hasmenu);  
}


/**
 * This method is used to print content to main part of the website
 * @param type $page_obj
 * @return type
 */
static function privateMainContent($page_obj,$hasmenu){

 return self::publicPageBuilder($page_obj, 'middle','private',$hasmenu);
}


/**
 * This method is used to print content to the leftside bar of the website
 * @param type $page_obj
 * @return type
 */
static function privateLeftSideBar($page_obj,$hasmenu){
    $content="";
   
         if($hasmenu){
       $content.=self::mainMenu("private");    
       }
       $content.=self::publicPageBuilder($page_obj, 'leftside','private',$hasmenu);
    return $content;
}

/**
 * This method is used to print content to reghtside bar of the website
 * @param type $page_obj
 * @return type
 */
static function privateRightSideBar($page_obj,$hasmenu){
    return self::publicPageBuilder($page_obj, 'rightside','private',$hasmenu);  
}

static function privateBusinessName(){
    $busname=new ComasUserManager();
   return  $busname->displayBusinessName();
}
/**
 * This method is used to prepare content for either public pages or private pages
 * @param type $page_obj
 * @param type $pageside
 * @return type
 */
static function publicPageBuilder($page_obj,$pageside,$viewer,$hasmenu){
     $pager=new ComasGeneratePage();
  $userpage=$page_obj;
  
   $page_content=isset($userpage['page'])?$userpage['page']:'index';
    $subpage=isset($userpage['sub'])?$userpage['sub']:'0';
       $nodepage=isset($userpage['node'.$subpage])?$userpage['node'.$subpage]:'0';
       $nodes=isset($userpage['node'.$nodepage])?$userpage['node'.$nodepage]:'0';
   
   $forms="";
    if($page_content=='index'){
        $database=new ComasDatabase();
       $mydefault=$database->selectField("comas_pages", array("page_id"), "=", "page_name", "Home' or page_name='DashBoard' and page_viewer='".$viewer, "", "","", "");
       if($mydefault){
           $defaultpage=$database->getResultSet();
           $page_content=$defaultpage['page_id'];
       }
    }
       if( $subpage==0){
         
    $pages='index.php?page='.$page_content;
    $forms.= $pager->MyPageContent($pages,$page_content,$pageside,$viewer,false);
       }
      
       if($nodepage=='0'&& $subpage!='0'){
           //comes sub pages
      
             $pages='index.php?page='.$page_content."&sub=".$subpage;
      $forms=$pager->MyPageContent($pages,$subpage,$pageside,$viewer,false);
       }
       
       if($nodes=='0' && $nodepage!='0'){
           //comes nodes pages
            $pages='index.php?page='.$page_content."&sub=".$subpage."&node".$subpage."=".$nodepage;
         
         $forms=$pager->MyPageContent($pages,$nodepage,$pageside,$viewer,false);  
      
      
       }
       if($nodes>0){
           
        
           $pages='index.php?page='.$page_content."&sub=".$subpage."&node".$subpage."=".$nodepage."&node".$nodepage."=".$nodes; 
           //comes end nodes
         $forms=$pager->MyPageContent($pages,$nodes,$pageside,$viewer,false);
       }
       
       
      

    
    return $forms; 
}



static function footer_leftsidebar($dir_init){
	$menu=' <p>COMASI</p>
        <ul >
        <li><a href="'.$dir_init.'index.php?page=11" title="comasi features">Features</a></li>
        <li><a href="'.$dir_init.'index.php?page=12" title="comasi training" >Training</a></li>
        <li><a href="'.$dir_init.'index.php?page=48" title="comasi FAQ">FAQ</a></li>
			</ul>';
			return $menu;
}

static function footer_maincontent($dir_init){
	$menu='<p>Who are We?</p>
			 <ul >
        <li><a href="'.$dir_init.'index.php?page=41" title="comasi learn more about us">About Us</a></li>
        <li><a href="'.$dir_init.'index.php?page=42" title="comasi contact us">Our Contact</a></li>
        
			</ul>';
			return $menu;
}

static function footer_middlesidebar($dir_init){
	$menu='<p> Security & Privacy Policy</p>
			 <ul >
        <li><a href="'.$dir_init.'index.php?page=43" title="comasi user privacy">Data Security</a></li>
        <li><a href="'.$dir_init.'index.php?page=44" title="comasi privacy policy">Privacy Policy</a></li>
        <li><a href="'.$dir_init.'index.php?page=49" title="comasi terms of use">Terms Of Use</a></li>

			</ul>';
			return $menu;
}
static function maincontent($page){
	$forms=pagecontents($page);
   return $forms;
}
static function footer_rightsidebar($dir_init){
	$menu='<p> Follow us On </p>
			 <ul >
        <li><a href="http://www.facebook.com/comasitz" target="_blank"><img src="'.$dir_init.'comas_ui/comas_img/facebook3.png" /></a></li>
        <!--<li>Twitter</li>
        <li>Google</li>-->
        
       </ul>';
        $menu.='<iframe src="https://www.facebook.com/plugins/like.php?href=http://facebook.com/comasitz"
        scrolling="no" frameborder="0"
        style="border:none; width:200px; height:80px"></iframe>';
		return $menu;
}

static function footer_endnote($dir_init){
	$menu='<span>COMASI&copy;2013&nbsp;&nbsp;<a href="'.$dir_init.'index.php?page=49">Terms Of Use Apply</a>.&nbsp;All Right Reserved</span>
            ';
	return $menu;
}


}
?>


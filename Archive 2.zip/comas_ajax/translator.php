<?php
session_start();
define("COMAS_EXEC",1);
define('DS', DIRECTORY_SEPARATOR);

 if (!defined('_JDEFINES')) {
	define('COMASPATH_BASE', dirname(dirname(realpath(__FILE__))));
	 require_once COMASPATH_BASE."/comas_config/ComasDefined.php";
          require_once COMASPATH_BASE."/comas_apps/page_creator.php";
          include COMASPATH_BASE.'/comas_apps_class/class.biz_reports.php';
          include COMASPATH_BASE.'/comas_apps_class/class.biz_calculator.php';
          require_once COMASPATH_BASE."/comas_apps_class/class.comas_jsons.php";
           require_once COMASPATH_BASE."/comas_apps/admin_form_creator.php";
          require_once COMASPATH_BASE."/comas_apps/comas_ajax.php";
}
$trans=new AdminForms();

$pageid=isset($_REQUEST['pageid'])?$_REQUEST['pageid']:0;
switch($pageid){
    case 4:
  echo $trans->comasSelectContents();      
     break;
}

?>

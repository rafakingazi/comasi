<?php

class ServerValidator{
	private static $error="Invalid Input";
	
	/**
	* This method is used to check if the word present character only no numeric or special character.
	*/
static function wordsOnly(array $words){
	$length=count($words);
	$word=array();
	 for($i=0; $i<$length; $i++){
         if(!preg_match("/[^a-z A-Z\'\-\_\.]/", $words[$i])){
             
             $word[]=addslashes(trim($words[$i]));
         }else{
            return self::$error;
			break;
         }
          }
		  return $word;
}

/**
*This method is used to validate an email address.
*/
static function emailCheck(array $emails){
	$length=count($emails);
	$email=array();
	for($i=0; $i<$length; $i++){
		 if(preg_match("/[a-z0-9_]+@+[a-z0-9_\-]+\.+[a-zA-Z0-9_\-\.]+$/", $emails[$i])){
           $email[]=  addslashes(trim($emails[$i]));
         
         }else{
             return self::$error;
			 break;
         }
	}
	return $email;
}

/**
*This method is used to check a numerical word only no other characters are allowed.
*/
static function numbersCheck(array $numbers){
	$length=count($numbers);
	$number=array();
	
	for($i=0; $i<$length; $i++){
		 if(!preg_match("/[^0-9\/\.\-\_ ]/", $numbers[$i])){
             $number[]=addslashes(trim($numbers[$i]));
         }else{
             return self::$error;
			 break;
         }
	}
	return $number;
}
/**
*This is used to validate a word with mixer of characters numerical and other special characters.
*/

static function varcharCheck(array $varchars){
	$length=count($varchars);
	$varchar=array();
	for($i=0; $i<$length; $i++){
		if(!preg_match("/[^A-Za-z0-9\-\.\_\'\/ ]/", $varchars[$i])){
               $varchar[]=addslashes(trim($varchars[$i]));
               
         }else{
            return self::$error;
			break;
         }
	}
	return $varchar;
}
static function passwordCheck($password){
	
}

/**
* It is used to return the current time for with mysql time format
*/
 static function  setDates(){
      return @date('Y-m-d H:i:s');     
   }
   
   static function setDateOnly(){
	    return @date('Y-m-d');
   }
   /**
   * It si used to convert the mysql time format to string time format.
   */
  static function changeDateFormat($mysqlDate,$Bool_withtime){
	  $newDate='';
	  $newtime='';

	  $datetime=array();
	  $dates=array();
	  $date=0;
	  $mon=0;
	  $month='';
	  $length=strlen(trim($mysqlDate));
	 
	  if($length>11){
		  
	  $datetime=@preg_split("/\s/",$mysqlDate);
	  $dates=preg_split("/-/",$datetime[0]);
	 $newtime=$datetime[1];
	  }else{
		  $dates=preg_split("/-/",$mysqlDate);
	  }
	  
	  switch($dates[1]){
		  case '01':
		  if(!$Bool_withtime){
		   $month='January';
		  }else{
			  $month='Jan';
		  }
		   break;
		case '02':
		   if(!$Bool_withtime){
		   $month='February';
		   }else{
			   $month='Feb';
		   }
		   break;
	   case '03':
	       if(!$Bool_withtime){
		   $month='March';
		   }else{
			   $month='Mar';
		   }
		   break;
	  case '04':
	       if(!$Bool_withtime){
		   $month='April';
		   }else{
			  $month='Apr';
		   }
		   break;
	 case '05':
	        
		   $month='May';
			
		   break;
	 case '06':
	      if(!$Bool_withtime){
		   $month='June';
		  }else{
			$month='Jun';
		  }
		   break;
     case '07':
	       if(!$Bool_withtime){
		   $month='July';
		   }else{
			 $month='Jul';
		   }
		   break;
	 case '08':
	  if(!$Bool_withtime){
	       $month='August';
	  }else{
		  $month='Aug';
	  }
		   break;
     case '09':
	     if(!$Bool_withtime){
	       $month='September';
		 }else{
			 $month='Sep';
		 }
		   break;
	case '10':
	 if(!$Bool_withtime){
	       $month='October';
	 }else{
		 $month='Oct';
	 }
		   break;
    case '11':
	    if(!$Bool_withtime){
	       $month='November';
		}else{
			$month='Nov';
		}
		   break;
    case '12':
	     if(!$Bool_withtime){
	       $month='December';
		 }else{
			 $month='Dec';
		 }
		   break;
	 
		       
	  }
	
	  
	  //remove zero to days.
	  if($dates[2]<10){
		  $date=substr($dates[2],1);
	  }else{
		  $date=$dates[2];
	  }
	  
	  //remove zero to months.
	  if($dates[1]<10){
		  $mon=substr($dates[1],1);
	  }else{
		  $mon=$dates[1];
	  }
	  //geting a day of the given date in monday-sunday format
	    $timestamp=@mktime(5,0,0,$mon,$date,$dates[0]);
	  $calendar=@getdate($timestamp);
	  $wday=$calendar['weekday'];
	  
	    if(!$Bool_withtime){
	$newDate=$wday." ".$month." ".$date.", ".$dates[0];
		}else{
			$newDate=$date." ".$month.",".$dates[0]." ".$newtime;
		}
	return $newDate;
  }
  
  /**
  *This is used to convert time to mysql format. from
  * date picker format of day-month-year.
  */
  
  static function mysqlDate($dateindaymonyear){
	  $months=array('JAN'=>'01','FEB'=>'02','MAR'=>'03'
	  ,'APR'=>'04','MAY'=>'05','JUN'=>'06','JUL'=>'07',
	  'AUG'=>'08','SEP'=>'09','OCT'=>'10','NOV'=>'11','DEC'=>'12');
	  $dates=preg_split("/-/",$dateindaymonyear);
	  
	  $mysqldate=$dates[2]."-".$months[strtoupper($dates[1])]."-".$dates[0];
	  return $mysqldate;
	  
  }
  
  /**
   * This is used to find difference between days, months and years
   * @param type $date1
   * @param type $date2
   * @return array(months,days,year)
   */
  static function getDateDiffence($date1,$date2){
      $dateone=  self::splitDates($date1);
      $datetwo=  self::splitDates($date2);
      $months=0;
      $datez=0;
      $years=$datetwo[3]-$dateone[3];
      $month=$datetwo[2]-$dateone[2];
      $date=$datetwo[1]-$dateone[1];
      $dates=$datetwo[0]-$dateone[0];
      
      if($years>0){
          $months=($years*12)+$month;
      }else if($years==0 && $month>0){
        $months=$month;  
      }
      if($month==0 && $date>0){
          $datez=$date;
      }
     return array($months,$datez,$years); 
      
  }
  
  /**
   * This method is used to split date into days months and years
   * @param type $mysqlDate
   * @return type
   */
  
static function splitDates($mysqlDate){
   
	  $newtime='';
     $datetime=array();
	  $dates=array();
	  $date=0;
	  $mon=0;
	
	  $length=strlen(trim($mysqlDate));
	 
	  if($length>11){
		  
	  $datetime=@preg_split("/\s/",$mysqlDate);
	  $dates=preg_split("/-/",$datetime[0]);
	 $newtime=$datetime[1];
	  }else{
		  $dates=preg_split("/-/",$mysqlDate);
	  }
      if($dates[2]<10){
		  $date=substr($dates[2],1);
	  }else if($dates[2]>=30){
		  $date=30;
	  }else{
               $date=$dates[2];
          }
	  
	  //remove zero to months.
	  if($dates[1]<10){
		  $mon=substr($dates[1],1);
	  }else{
		  $mon=$dates[1];
	  }
          
          
          $todays=$date+($mon*30)+($dates[0]*12*30);
          $newDate=array($todays,$date,$mon,$dates[0]);
      return $newDate;
}

}
?>
<?php
echo "hellowz";
session_start();
define("COMAS_EXEC",1);
define('DS', DIRECTORY_SEPARATOR);
echo "hellowz";
 if (!defined('_JDEFINES')) {
	define('COMASPATH_BASE', dirname(dirname(realpath(__FILE__))));
	 require_once COMASPATH_BASE."/comas_config/ComasDefined.php";
          require_once COMASPATH_BASE."/comas_apps/page_creator.php";
          require_once COMASPATH_BASE."/comas_apps_class/class.comas_jsons.php";
          require_once COMASPATH_BASE."/comas_apps/comas_ajax.php";
}

ComasUserManager::comasIsLoggedIn("../index.php");
ComasUserManager::userPageAccess();
ComasUserManager::isExpired();

echo ComasAjax::stockList();

?>

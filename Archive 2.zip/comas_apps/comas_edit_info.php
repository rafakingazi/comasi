<?php
 $users=new ComasUserManager();
 $fileInclude.="<div class='content_box' >".$users->comasUserEditProfile()."</div>";
 $fileInclude.="<div class='content_box editinfo' >".$users->comasChangePassword()."</div></div>";
?>

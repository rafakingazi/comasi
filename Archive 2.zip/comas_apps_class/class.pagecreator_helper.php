<?php
/**
 * This class is used to help page creator and form creator to fetch and set some data from the database
 * or cache array
 */
class ComasPageCreatorHelper{
    private $database_obj="";
    function PageCreatorHelper(){
      $this->database_obj=new ComasDatabase();  
    }
    
    /**
     * fetching the page id and page name;
     */
    function pageId(){
        $page_array=array();
        
       $this->database_obj->selectField("comas_pages",array('*'),"","","","","","","","");
      while($pages=$this->database_obj->getResultSet()){
      $page_array[$pages['page_id']]=$pages['page_name']."_".$pages['page_viewer'];
      }
      return $page_array;
    }
    
    /**
     * fetching the block id and block name
     */
   function blockId(){
       $block_array=array();
        
       $this->database_obj->selectField("comas_blocks",array('*'),"","","","","","","","");
      while($block=$this->database_obj->getResultSet()){
      $block_array[$block['block_id']]=$block['block_name'];
      }
      return $block_array;
   }
   
   /**
    * fetching the form id and form name
    */
   function formId(){
       $form_array=array();
        
       $this->database_obj->selectField("comas_form",array('*'),"","","","","","","","");
      while($form=$this->database_obj->getResultSet()){
      $form_array[$form['form_id']]=$form['form_title']."_".$form['form_name_attr'];
      }
      return $form_array;
   }
}

/*
 *  <input data-theme="c" name="dtFrom" id="dtFrom" type="date" data-role="datebox"  data-options='{"mode": "calbox", "afterToday": true, "hideInput": true }' style="width: 30px" />
    <input name="dtTo" id="dtTo" type="date" data-role="datebox" data-options='{"mode": "calbox", "afterToday": true, "hideInput": true }' />                     

<div data-role="controlgroup" data-type="horizontal" id="btnCalendar">
    <a href="#" id="From" data-role="button">From</a>
    <a href="#" id="To" data-role="button">To</a>
</div>
 * 
 * 
 * $('#btnCalendar').on("click", "a", function() {
    $thisCalendar = $(this).attr("id");
    $('#dt' + $thisCalendar).datebox('open');
});
 * 
 * //solution
 * $('#linkmodelink').live('click', function() {
    $('#linkmode').datebox('open');
});
 * 
 * 
 * <div data-role="fieldcontain">
    <label for="linkmode">Some Date</label>
    <input name="linkmode" type="date" data-role="datebox" id="linkmode" data-options='{"noButton": true}' />
</div>
<br />
<a href="#" id="linkmodelink" data-role="button">Click Here</a>
 */
?>

<?php

include 'ComasServerUtility.php';



class ComasDataResponder{
	

/**
 * This method is used by various apps to consume given http resources
 * It hold the http request data as its return type
 * @return type http_request_type
 */

function comasRequestProcessor(){
	
	$datas=ComasServerUtility::processRequest();
	return $datas->getData();
}

/**
*This method is used to return feedback from given http request consumed by server 
 * result obtained from using comasRequestProcessor method or ohter user method
*/

function comasRequestFeedback($processor_result,$context_type){
	 return ComasServerUtility::sendResponse(200,$processor_result,$context_type.';charset=UTF-8 ');
}

}

?>

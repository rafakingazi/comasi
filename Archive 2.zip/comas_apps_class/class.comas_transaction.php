<?php

/**
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class ComasTransaction{
   private $cash;
    function billProcessor($phone,$codes,$package){
        $checkcode=new ComasDatabase();
        $codeusage=new ComasDatabase();
       
        $userbiz=$_SESSION['biz_id'];
        $cal=new ComasCalculator($userbiz);
        $this->cash=$cal->getAvailableCash();
       $userid=$_SESSION['comas_knownas'];
       $phone=  ComasDatabase::escapeString(trim($phone));
    $codes= ComasDatabase::escapeString(trim($codes));
    $package= ComasDatabase::escapeString(trim($package));
    $status=$checkcode->selectField("comas_mobile_billed",array("mobi_id,currency,amount,billed_date"),"=","phone", $phone."' and receipt='".$codes, "", "", "", "");
    if($status){
        $billed=$checkcode->getResultSet();
       $codeused=$codeusage->selectField("comas_feepayment",array("bill_id,bill_expire_date"),"=","bill_source_id",$billed['mobi_id'], "", "", "", "");
       if($codeused){
           //code already used
            echo "<script> alert('Code Already Used'); </script>";
       }else{
           
           //make user we have correct onwer
           if($userbiz!=0){
           $bizowner=new ComasDatabase();
          $biz=$bizowner->selectField("comas_user_business",array("biz_owner_id"),"=","user_bizid",$userbiz, "", "", "", "1");
          if($biz){
              $ids=$bizowner->getResultSet();
              $userid=$ids['biz_owner_id'];
          }
           }
           //preparing bill updates
        
           $this->billProcessorHelper($package, $billed['amount'], $userid, $billed['mobi_id'], $billed['billed_date']);
           //code never used we can consider it
       }
    }else{
        //new 
        echo "<script> alert('Hellow there is an error'); </script>";
    }
    }
    
    function billProcessorHelper($package,$amount,$userid,$sourceid,$paydate){
         $expires=new ComasDatabase();
         $checkdemo=new ComasDatabase();
         $update=new ComasDatabase();
           $date=0;
          $mydate=0;
          
         $status=$expires->selectField("comas_feepayment",array("bill_id,bill_expire_date"),"=","user_id", $userid."' and bill_expire_date>'".$date, "bill_id", "desc", "", "");
         if($status){
           
           $bills=$expires->getResultSet();  
             $date=$bills['bill_expire_date'];
          $mydate=$this->billExpire($amount, $package, $date); 
           
         }else{
           $date=@date("Y-m-d");
          $mydate=$this->billExpire($amount, $package, $date);    
         }
          $data_to_insert=array("",$userid,$amount,$sourceid,$package,$paydate,$date,$mydate);
          $state=$update->insertField("comas_feepayment", $data_to_insert);
          if($state){
              $today=@date("Y-m-d");
              $dates=@strtotime("-1 day", @strtotime($today));
	            $demoexp=@date("Y-m-d",$dates);
            
            $status=$checkdemo->selectField("comas_demo",array("user_id"),"=","user_id",$userid."' and expire_date>='".$today,"", "","","");
            if($status){
             $demo=array("expire_date"=>$demoexp); 
             $checkdemo->updateField("comas_demo", $demo,"user_id", $userid);
            }
          }
    }
    
    function billExpire($amount,$package,$startdate){
         $months=0;
           $days=0;
           $mydates=0;
       switch($package){
               case 2:
                   
                  $months=($amount/5000);
                    $days=($months*30);
                    $dates=@strtotime("+".$days." day", @strtotime($startdate));
	            $mydates=@date("Y-m-d",$dates); 
                   break;
               case 3:
                   $months=($amount/10000);
                    $days=($months*30);
                    $dates=@strtotime("+".$days." day", @strtotime($startdate));
	            $mydates=@date("Y-m-d",$dates); 
                   break;
               case 4:
                   $months=($amount/30000);
                    $days=($months*30);
                    $dates=@strtotime("+".$days." day", @strtotime($startdate));
	            $mydates=@date("Y-m-d",$dates); 
                   break;
           } 
           
           return $mydates;
    }
  /**
   * 0 credit, 1 debit
   * This method is used to add stock to the database
   * @param type $item
   * @param type $unit
   * @param type $quantity
   * @param type $cost
   * @param type $sellprice
   */
  function comasStock($item,$unit,$quantity,$cost,$sellprice,$boughtdate){
    $dateformat=new ServerValidator();
    $item=  ComasDatabase::escapeString(trim($item));
    $unit= ComasDatabase::escapeString(trim($unit));
    $cost= ComasDatabase::escapeString(trim($cost));
    $quantity= ComasDatabase::escapeString(trim($quantity));
    $sellprice= ComasDatabase::escapeString(trim($sellprice));
    $bought=  ComasDatabase::escapeString($boughtdate);
    
    $dates=$dateformat->mysqlDate(trim($bought));

    if(!(self::isEmpty($item)|| self::isEmpty($cost) || self::isEmpty($quantity) || self::isEmpty($sellprice))){
     //process the form
     $updates=$this->comasPurchase($item,$quantity,$cost,$sellprice,"none",$unit,"falses",$dates." 12:12:12");
      if($updates){
          echo "<script> alert('successfully'); </script>";
      }
    
    }
 }
  
/**
 * This method is is used to process Expenses request
 * @param type $expense
 * @param type $cost
 * @param type $description
 * @param type $receiptno
 */
 function comasExpenses($expense,$cost,$description,$exp_start,$exp_end,$status){
     $expenses_table=new ComasDatabase();
     $dateformat=new ServerValidator();
     $expense=ComasDatabase::escapeString($expense);
     $cost=  ComasDatabase::escapeString($cost);
     $descr=  ComasDatabase::escapeString($description);
     $start_date= $dateformat->mysqlDate( ComasDatabase::escapeString($exp_start));
     $end_date= $dateformat->mysqlDate( ComasDatabase::escapeString($exp_end));
     $dates=@date("Y-m-d H:i:s");
     $receipt="none";
     $userid=$_SESSION['comas_knownas'];
    $bizid=$_SESSION['biz_id'];
    if($cost!='' && $expense!=''){
       if($this->cash>=$cost){
     $id=self::getLastId("comas_biz_expenses","expenses_id","expenses_id");
     if($id!=0){
      $newid=$id+1;
      $expenses=array($newid,$expense,$cost,$receipt,$descr,$start_date,$end_date,$dates,"1",$userid,$bizid);
      $states=$expenses_table->insertField("comas_biz_expenses", $expenses);
      if($states){
          if($status==1){
          self::comasAffectCash($newid,"comas_biz_expenses", $cost,"0", $userid,$bizid,$dates); 
          }else if($status==2){
           $discount=self::comasAffectDiscount($newid,"comas_biz_exppayable", "comas_biz_expenses", $cost, "0", $userid,$bizid,$dates);
               if($discount){
                   
               }    
          }
      }
     }else{
         $id=1;
         $newid=1;
      $expenses=array($newid,$expense,$cost,$receipt,$descr,$start_date,$end_date,$dates,"1",$userid,$bizid);
      $states=$expenses_table->insertField("comas_biz_expenses", $expenses);
      if($states){
         if($status==1){
          self::comasAffectCash($newid,"comas_biz_expenses", $cost,"0", $userid,$bizid,$dates); 
          }else if($status==2){
             $discount=self::comasAffectDiscount($newid,"comas_biz_exppayable", "comas_biz_expenses", $cost, "0", $userid,$bizid,$dates);
               if($discount){
                   
               }   
          }
      }  
     }
       
       }else{
           //we dont have enough amount
       }
    }
 }
 
 /**
  * This method is used to process purchase 
  * @param type $item
  * @param type $quantity
  * @param type $buyingprice
  * @param type $sellingprice
  * @param type $receiptno
  */
 
   function comasPurchase($item,$quantity,$buyingprice,$sellingprice,$receiptno,$unit,$notpaid,$dates){
       $purchase_table=new ComasDatabase();
       $item= ComasDatabase::escapeString(trim($item));
       $quantity=ComasDatabase::escapeString(trim($quantity));
       $unit= ComasDatabase::escapeString(trim($unit));
       $buyingprice=ComasDatabase::escapeString(trim($buyingprice));
       $sellingprice=ComasDatabase::escapeString(trim($sellingprice));
       $receiptno=  ComasDatabase::escapeString($receiptno);
       $notpaid=  ComasDatabase::escapeString($notpaid);
       $userid=$_SESSION['comas_knownas'];
       $bizid=$_SESSION['biz_id'];
       $cashed=false;
      
       if(!(self::isEmpty($item) || self::isEmpty($quantity) || self::isEmpty($buyingprice) || self::isEmpty($sellingprice))){
           $totalcost=$quantity*$buyingprice;
           $totalprice=$quantity*$sellingprice;
           //check if we have enough cash
           if($this->cash>=$totalcost){
            $newid=0;
            $item_id=self::getItemId($item, $sellingprice);
    $lastid=self::getLastId("comas_biz_purchase", "purchase_id", "purchase_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
    
 
           $add_purchase=array($newid,$item_id,$buyingprice,$sellingprice,$quantity,$totalcost,$totalprice,$dates,"1","0.0","0",$receiptno,$userid,$bizid);
           $states=$purchase_table->insertField("comas_biz_purchase", $add_purchase);
           
           if($states){
               if($notpaid=="falses"){
               $cashed=self::comasAffectCash($newid, "comas_biz_purchase", $totalcost, "0", $userid,$bizid,$dates);
               }else{
               $cashed=self::comasAffectPayable($newid,$notpaid, "comas_biz_purchase", $totalcost, "0", $userid,$bizid,$dates);    
               }
               if($cashed){
                   $updates=self::comasAffectStock($item_id, $item,$unit, $quantity, $buyingprice, $sellingprice, $userid,$bizid, "0",$dates);
                   if($updates){
                       
                   }
               }
              // echo "<script> alert('successfully'); </script>";
           }
           
           } else{
               //we dont have enough cash in our bank
           }
           
       }
   }
   
   function comasCapital($amount,$desc){
        $capital=new ComasDatabase();
       $amount=ComasDatabase::escapeString(trim($amount));
       $desc=ComasDatabase::escapeString(trim($desc));
       $userid=$_SESSION['comas_knownas'];
       $bizid=$_SESSION['biz_id'];
        $dates=@date("Y-m-d H:i:s");
       $newid=0;
        $lastid=self::getLastId("comas_biz_capital", "capital_id", "capital_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
    
       $add_capital=array($newid,$amount,$desc,"0",$userid,$bizid,$dates);
       $states=$capital->insertField("comas_biz_capital", $add_capital);
       if($states){
     $cashed=self::comasAffectCash($newid, "comas_biz_capital", $amount, "1", $userid,$bizid,$dates);
     if($cashed){
      echo "<meta http-equiv=Refresh content=0;url=index.php?page=15>";   
     }
       }
   }
   
   /**
    * This method is used to record business sales
    * @param type $item_id
    * @param type $item
    * @param type $quantity
    * @param type $amount
    * @param type $receipt
    */
   function comasSales($item_id,$item,$quantity,$amount,$realsell,$receipt,$loan){
       $sales_table=new ComasDatabase();
    $item_id=  ComasDatabase::escapeString($item_id);
    $item=  ComasDatabase::escapeString($item);
    $quantity=  ComasDatabase::escapeString($quantity);
    $amount=  ComasDatabase::escapeString($amount);
    $realsel=ComasDatabase::escapeString($realsell);
    $receipt=  ComasDatabase::escapeString($receipt);
    $loans=  ComasDatabase::escapeString($loan);
    $userid=$_SESSION['comas_knownas'];
    $bizid=$_SESSION['biz_id'];
    $dates=@date("Y-m-d H:i:s");
    $newid=0;
    
    $lastid=self::getLastId("comas_biz_sales", "sales_id", "sales_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
    if(self::checkPrice($quantity, $amount, $realsel)){
        $extra=self::finddiscount_loan($quantity,$amount,$realsel);
         $updates=self::comasAffectStock($item_id, $item,"", $quantity, $amount, $realsel, $userid,$bizid, "1",$dates);
        if($updates){
    $data_to_insert=array($newid,  self::getItemId($item, $realsel),$quantity,$amount,"cash","0",$extra,$loans,$dates,$receipt,$userid,$bizid);
    $status=$sales_table->insertField("comas_biz_sales", $data_to_insert);
    if($status){
        
     $cashed=self::comasAffectCash($newid, "comas_biz_sales", $amount, "1", $userid,$bizid,$dates);
               if($cashed){
                     
                   }
       switch($loan){
           case 1:
       $discount=self::comasAffectDiscount($newid,"comas_biz_disallowed", "comas_biz_sales", $extra, "1", $userid,$bizid,$dates);
               if($discount){
                   
               }
               break;
           case 2:
               break;
                }
       
       }
      }
    }
    
   }
   
   
     /**
    * This method is used to record business sales
    * @param type $item_id
    * @param type $item
    * @param type $quantity
    * @param type $amount
    * @param type $receipt
    */
   function comasSaleOnCredit($debt_id,$item_id,$item,$quantity,$loan,$realsell,$loandate){
       $sales_table=new ComasDatabase();
      $dateformat=new ServerValidator();
    $item_id=  ComasDatabase::escapeString($item_id);
    $debt_id=  ComasDatabase::escapeString($debt_id);
    $item=  ComasDatabase::escapeString($item);
    $quantity=  ComasDatabase::escapeString($quantity);
    $amount= 0;
   $realsel=ComasDatabase::escapeString($realsell);
    $receipt=0;
    $loans=  ComasDatabase::escapeString($loan);
    $loandate=  $dateformat->mysqlDate(ComasDatabase::escapeString($loandate));
    $userid=$_SESSION['comas_knownas'];
    $bizid=$_SESSION['biz_id'];
    $dates=@date("Y-m-d H:i:s");
    $newid=0;
    
    $lastid=self::getLastId("comas_biz_sales", "sales_id", "sales_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
    if(self::checkPrice($quantity, $loans, $realsel)){
        
         $updates=self::comasAffectStock($item_id, $item,"", $quantity, $loans, $realsel, $userid,$bizid, "1",$dates);
        if($updates){
    $data_to_insert=array($newid,  self::getItemId($item, $realsel),$quantity,$amount,"credit","0",$loans,"2",$dates,$receipt,$userid,$bizid);
    $status=$sales_table->insertField("comas_biz_sales", $data_to_insert);
    if($status){
     $cashed=self::comasAffectReceivable($newid, $debt_id,"comas_biz_sales", $loans, "1", $userid,$bizid,$dates);
               if($cashed){
                     
                   }
               }
    }
    }
   }
   
   function comasCashDebtor($debtor,$amount,$returnamount,$returndate,$type){
       $debtor=ComasDatabase::escapeString($debtor);
       $amount=ComasDatabase::escapeString($amount);
       $returnamount=ComasDatabase::escapeString($returnamount);
       $returndate=ComasDatabase::escapeString($returndate);
       $dateformat=new ServerValidator();
       $userid=$_SESSION['comas_knownas'];
       $bizid=$_SESSION['biz_id'];
       $dates=@date("Y-m-d H:i:s");
       $newid=0;
      if($this->cash>=$amount){
     $interest=$returnamount-$amount;
        switch($type){
            case "dr":
       $lastid=self::getLastId("comas_biz_debtors_acc", "debtor_acc_id", "debtor_acc_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
    
       $status=self::affectDebtorAcc($debtor,$amount,$returnamount,$dateformat->mysqlDate($returndate),"1","cash",$dates,"dr"); 
       if($status){
     $cashed=self::comasAffectCash($newid, "comas_biz_debtors_acc", $amount, "0", $userid,$bizid,$dates);
               if($cashed){
              if($interest>0){
                  self::comasAffectInterest($newid, $debtor, "comas_biz_ireceivable", "comas_biz_debtors_acc", $interest,"1", $userid, $bizid,$dates); 
              }       
                   }
               }
                break;
            case "cr":
                   $lastid=self::getLastId("comas_biz_creditors_acc", "creditor_acc_id", "creditor_acc_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
    
       $status=self::affectDebtorAcc($debtor,$amount,$returnamount,$dateformat->mysqlDate($returndate),"0","cash",$dates,"cr",$dates); 
       if($status){
     $cashed=self::comasAffectCash($newid, "comas_biz_creditors_acc", $amount, "1", $userid,$bizid,$dates);
               if($cashed){
                 if($interest>0){
                  self::comasAffectInterest($newid, $debtor, "comas_biz_ipayable", "comas_biz_creditors_acc", $interest,"0", $userid, $bizid,$dates); 
              }    
                   }
               }
                break;
        } 
      }else{
          //we dont have enough amount
      }
              
   }
   
   function comasDebtRepay($debt_id,$amount,$debt_type,$type){
       $debt_id=ComasDatabase::escapeString($debt_id);
       $amount=ComasDatabase::escapeString($amount);
     $userid=$_SESSION['comas_knownas'];
       $bizid=$_SESSION['biz_id'];
       $dates=@date("Y-m-d H:i:s");
      if($type=="dr"):
       switch($debt_type){
         case "1":
                $newid=0;
        $lastid=self::getLastId("comas_biz_receivable", "payable_acc_id", "payable_acc_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
       $status=self::comasAffectReceivable($newid, $debt_id,"comas_biz_cash", $amount, "0", $userid,$bizid,$dates);
       if($status){
     $cashed=self::comasAffectCash($newid, "comas_biz_receivable", $amount, "1", $userid,$bizid,$dates);
               if($cashed){
                     
                   }
               } 
             break;
         case "2":
                $newid=0;
        $lastid=self::getLastId("comas_biz_debtors_acc", "debtor_acc_id", "debtor_acc_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
       $status=self::affectDebtorAcc($debt_id,"0.0",$amount,$dates,"0","return",$dates,"dr",$dates); 
       if($status){
     $cashed=self::comasAffectCash($newid, "comas_biz_debtors_acc", $amount, "1", $userid,$bizid,$dates);
               if($cashed){
                     
                   }
               } 
             break;
       }
       
       endif;
       if($type=="cr"):
           
            switch($debt_type){
         case "1":
                $newid=0;
        $lastid=self::getLastId("comas_biz_payable", "receivable_acc_id", "receivable_acc_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
       $status=self::comasAffectPayable($newid, $debt_id,"comas_biz_cash", $amount, "1", $userid,$bizid,$dates);
       if($status){
     $cashed=self::comasAffectCash($newid, "comas_biz_payable", $amount, "0", $userid,$bizid,$dates);
               if($cashed){
                     
                   }
               } 
             break;
         case "2":
                $newid=0;
        $lastid=self::getLastId("comas_biz_creditors_acc", "creditor_acc_id", "creditor_acc_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
       $status=self::affectDebtorAcc($debt_id,"0.0",$amount,$dates,"1","return",$dates,"cr",$dates); 
       if($status){
     $cashed=self::comasAffectCash($newid, "comas_biz_creditors_acc", $amount, "0", $userid,$bizid,$dates);
               if($cashed){
                     
                   }
               } 
             break;
       }
      endif;
     
   }
   
   function loaneeInterest($debtor_id,$debt_type,$receivedamount){
       $datesCal=new ServerValidator();
      $duration=0;
       $remaintime=0;
       $total=0;
       $month_interest=0;
       $month_return=0;
       $debt_id=0;
       $withinterest=false;
       $hasinterest=false;
       $hasdebt=false;
       $dueinterest=0;
       $interests=0;
      $loans=new ComasDatabase(); 
     $status= $loans->selectField("comas_biz_debtors_acc",array("*"),"=","debtor_id",$debtor_id."' and debt_type='".$debt_type."' and account_type='1","debtor_acc_id","desc","","");
      if($status){
          $result=$loans->getResultSet();
          $duration=$datesCal->getDateDiffence($result['debtor_acc_date'],$result['repayment_date']);
          $remaintime=$datesCal->getDateDiffence(@date("Y-m-d"),$result['repayment_date']);
          $givenamount=$result['given_amount'];
          $return_amount=$result['return_amount'];
          $debt_id=$result['debtor_acc_id'];
          $interest=$return_amount-$givenamount;
          if($interest>0){
             $month_interest=$interest/$duration;
             $month_return=$givenamount/$duration;
             $total=$month_interest+$month_return;
             $hasinterest=true;
            if($receivedamount<$givenamount || $receivedamount<$return_amount){
                if($receivedamount>$month_return){
                        $withinterest=true;
                  $interests=$receivedamount-$month_return;
                  if($interests>=$month_interest){
                      //monthly interest returned
                  
                  }else{
                      $hasdebt=true;
                      $dueinterest=$month_interest-$interest;
                  }
                }else{
                  $hasinterest=true;
                 $hasdebt=true;   
                }
            }
          }else{
            $month_interest=0;
           $total=$givenamount/$duration;
            $month_return=$total;
          }
          
      }
      return array($total,$month_interest,$month_return,$dueinterest,$hasdebt,$hasinterest,$withinterest);
   }
   
    function loanInterest($debtor_id,$receivedamount){
       $datesCal=new ServerValidator();
       $duration=0;
       $remaintime=0;
       $total=0;
       $month_interest=0;
       $month_return=0;
       $debt_id=0;
       $withinterest=false;
       $hasinterest=false;
       $hasdebt=false;
       $dueinterest=0;
       $interests=0;
      $loans=new ComasDatabase(); 
     $status= $loans->selectField("comas_biz_creditors_acc",array("*"),"=","creditor_id",$debtor_id."' and  account_side='0","creditor_acc_id","desc","","");
      if($status){
          $result=$loans->getResultSet();
          $duration=$datesCal->getDateDiffence($result['creditor_acc_date'],$result['return_date']);
          $remaintime=$datesCal->getDateDiffence(@date("Y-m-d"),$result['return_date']);
          $givenamount=$result['received_amount'];
          $return_amount=$result['return_amount'];
          $debt_id=$result['creditor_acc_id'];
          $interest=$return_amount-$givenamount;
          if($interest>0){
             $month_interest=$interest/$duration;
             $month_return=$givenamount/$duration;
             $total=$month_interest+$month_return;
             $hasinterest=true;
            if($receivedamount<$givenamount || $receivedamount<$return_amount){
                if($receivedamount>$month_return){
                        $withinterest=true;
                  $interests=$receivedamount-$month_return;
                  if($interests>=$month_interest){
                      //monthly interest returned
                  
                  }else{
                      $hasdebt=true;
                      $dueinterest=$month_interest-$interest;
                  }
                }else{
                  $hasinterest=true;
                 $hasdebt=true;   
                }
            }
          }else{
            $month_interest=0;
           $total=$givenamount/$duration;
            $month_return=$total;
          }
          
      }
      return array($total,$month_interest,$month_return,$dueinterest,$hasdebt,$hasinterest,$withinterest);
   }
   
  function affectDebtorAcc($debt_id,$amount,$returnamount,$return_date,$account_side,$debt_type,$dates,$type){
      $debtor=new ComasDatabase();
      $userid=$_SESSION['comas_knownas'];
      $bizid=$_SESSION['biz_id'];
       $newid=0;
       switch($type){
         case "dr":
                  $lastid=self::getLastId("comas_biz_debtors_acc", "debtor_acc_id", "debtor_acc_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
     $data_to_insert=array($newid,$debt_id,$amount,$returnamount,$return_date,$account_side,$debt_type,$dates,$userid,$bizid);
    $status=$debtor->insertField("comas_biz_debtors_acc", $data_to_insert);
    if($status){
      return true;  
    }else{
        return false;
    }
             break;
         case "cr":
        $lastid=self::getLastId("comas_biz_creditors_acc", "creditor_acc_id", "creditor_acc_id");
    if($lastid!=0){
        $newid=$lastid+1;
    }else{
        $newid=1;
    }
     $data_to_insert=array($newid,$debt_id,$amount,$returnamount,$return_date,$account_side,$dates,$userid,$bizid);
    $status=$debtor->insertField("comas_biz_creditors_acc", $data_to_insert);
    if($status){
      return true;  
    }else{
        return false;
    }
             break;
       }
   
  }
   /**
    * This emthod is used process the drawing actions
    * @param type $amount
    * @param type $description
    * @param type $dates
    * @param type $receiptno
    */
   
   function comasDrawings($amount,$description,$dates,$receiptno){
     $drawing_table=new ComasDatabase();
     $amount=  ComasDatabase::escapeString(trim($amount));
     $descript=  ComasDatabase::escapeString(trim($description));
     $datesdrawn=  ComasDatabase::escapeString(trim($dates));
     $receiptno=  ComasDatabase::escapeString($receiptno);
     $dateformat=new ServerValidator();
     $userid=$_SESSION['comas_knownas'];
    $bizid=$_SESSION['biz_id'];
     $newid=0;
     if($this->cash>=$amount){
     $dates=@date("Y-m-s H:i:s");
     $id=self::getLastId("comas_biz_draw_account", "draw_id","draw_id");
     if($id!=0){
         $newid=$id+1;
     }else{
         $newid=1;
     }
     $data_to_insert=array($newid,$descript,$amount,"1",$dateformat->mysqlDate($datesdrawn),$userid,$bizid);
     $status=$drawing_table->insertField("comas_biz_draw_account", $data_to_insert);
     if($status){
         self::comasAffectCash($newid, "comas_biz_draw_account", $amount,"0",$userid,$bizid,$dates);
     }
     }else{
         //we have enough money
     }
   }
   
   /**
    * This method is used to process the comas Asset actions
    * @param type $asset
    * @param type $assettype
    * @param type $assetcost
    * @param type $receipt
    */
   function comasAsset($asset,$assettype,$assetcost,$receipt,$boughtdate,$life){
       $asset_table=new ComasDatabase();
       $asset=  ComasDatabase::escapeString(trim($asset));
       $assettype= ComasDatabase::escapeString(trim($assettype));
       $assetcost=  ComasDatabase::escapeString(trim($assetcost));
       $receipt=  ComasDatabase::escapeString($receipt);
       $boughtdate=  ComasDatabase::escapeString($boughtdate);
       $life=  ComasDatabase::escapeString($life);
       $dateformat=new ServerValidator();
       $userid=$_SESSION['comas_knownas'];
       $bizid=$_SESSION['biz_id'];
       $dates=@date("Y-m-d H:i:s");
       $newid=0;
     if($this->cash>=$assetcost){
     $id=self::getLastId("comas_biz_asset", "asset_id","asset_id");
     if($id!=0){
         $newid=$id+1;
     }else{
         $newid=1;
     }
       $data_to_insert=array($newid,$asset,$assettype,$assetcost,$receipt,"1",$dateformat->mysqlDate($boughtdate),$life,$dates,$userid,$bizid);
      $status= $asset_table->insertField("comas_biz_asset", $data_to_insert);
      if($status){
       self::comasAffectCash($newid, "comas_biz_asset", $assetcost,"0",$userid,$bizid,$dates);   
      }
       //no table designed
     }else{
         //we dont have enough money
     } 
   }
  
   /**
    *This method is used to register new debtor into the system 
    * @param type $name
    * @param type $phone
    * @param type $email
    */
function comasDebtor($name,$phone,$email,$type){
  $debtor_table=new ComasDatabase();
  $name=  ComasDatabase::escapeString(trim($name));
  $phone=  ComasDatabase::escapeString(trim($phone));
  $email= ComasDatabase::escapeString(trim($email));
  $userid=$_SESSION['comas_knownas'];
  $bizid=$_SESSION['biz_id'];
  $dates=@date("Y-m-d H:i:s");
  switch($type){
      case "dr":
  $data_to_insert=array("",$name,$email,$phone,"0",$dates,$userid,$bizid);
  $debtor_table->insertField("comas_biz_debtors", $data_to_insert);
    break;
   case "cr":
  $data_to_insert=array("",$name,$email,$phone,"0",$dates,$userid,$bizid);
  $debtor_table->insertField("comas_biz_creditors", $data_to_insert);
      break;
  }
}


   /**
    * This method is used to controll activity of cash account
    */
  static function comasAffectCash($item_id,$table_name,$amount,$account_type,$user_id,$biz_id,$dates){
      $feedback=false;
       $cash_table=new ComasDatabase();
       
       $affect_cash=array("",$item_id,$table_name,$amount,$account_type,$dates,$user_id,$biz_id);
       $states=$cash_table->insertField("comas_biz_cash", $affect_cash);
       if($states){
           //we don check for this
          $feedback=true;
       }
       return $feedback;
   }
   
   
   static function comasAffectReceivable($item_id,$debtor_id,$table_name,$amount,$account_type,$user_id,$biz_id,$dates){
      $feedback=false;
       $cash_table=new ComasDatabase();
      
       $affect_cash=array("",$debtor_id,$item_id,$table_name,$amount,$account_type,$dates,$user_id,$biz_id);
       $states=$cash_table->insertField("comas_biz_receivable", $affect_cash);
       if($states){
           //we don check for this
          $feedback=true;
       }
       return $feedback;
   }
   
    static function comasAffectDiscount($item_id,$discount_table,$table_name,$amount,$account_type,$user_id,$biz_id,$dates){
      $feedback=false;
       $cash_table=new ComasDatabase();
      
       $affect_cash=array("",$item_id,$table_name,$amount,$account_type,$dates,$user_id,$biz_id);
       $states=$cash_table->insertField($discount_table, $affect_cash);
       if($states){
           //we don check for this
          $feedback=true;
       }
       return $feedback;
   }
 
    static function comasAffectPayable($item_id,$debtor_id,$table_name,$amount,$account_type,$user_id,$biz_id,$dates){
      $feedback=false;
       $cash_table=new ComasDatabase();
     
       $affect_cash=array("",$debtor_id,$item_id,$table_name,$amount,$account_type,$dates,$user_id,$biz_id);
       $states=$cash_table->insertField("comas_biz_payable", $affect_cash);
       if($states){
           //we don check for this
          $feedback=true;
       }
       return $feedback;
   }
   
   static function comasAffectInterest($item_id,$debtor_id,$interest_table,$table_name,$amount,$account_type,$user_id,$biz_id,$dates){
      $feedback=false;
       $cash_table=new ComasDatabase();
       
       $affect_cash=array("",$debtor_id,$item_id,$table_name,$amount,$account_type,$dates,$user_id,$biz_id);
       $states=$cash_table->insertField($interest_table, $affect_cash);
       if($states){
           //we don check for this
          $feedback=true;
       }
       return $feedback;
   }
/**
 * This method is used to handle stock operations
 * action 0 means adding to stock or updating stock
 * action 1 means reducing stock
 * @param type $quantity
 */
   static function comasAffectStock($item_id,$itemname,$itemunit,$quantity,$unitcost,$sellingprice,$user_id,$biz_id,$action,$dates){
     $stock_table=new ComasDatabase();
     $check_stock=new ComasDatabase();
     $check_price=new ComasDatabase();
     $check_stocks=new ComasDatabase();
     $sold_stock=new ComasDatabase();
     
     $feedback=false;
     $isstocked=$check_stock->selectField("comas_biz_stock",array("*"),"=","item_name",$itemname."' and user_bizid='".$biz_id,"","","","");
    
     if($action==0){
         //from purchase  //or add the stock //we update existing stock
         if($isstocked){
         //item is instock.. 
             $stock_item=$check_stock->getResultSet();
             $quant=$stock_item['quantity'];
             $itemid=$stock_item['item_id'];
             $newquant=$quant+$quantity;
              $update="";
            $updated= $stock_table->updateField('comas_biz_stock',array("quantity"=>$newquant,"last_modified_date"=>$dates) ,"item_id", $itemid);
            
           $ispriced=$check_stocks->selectField("comas_biz_stockprice",array("*"),"=","item_id",$itemid."'  and unitcost='".$unitcost."' and sellingprice='".$sellingprice,"","","","","");
             if($ispriced){
                 $prices=$check_stocks->getResultSet();
                 $quants=$prices['quantity'];
                 $myquantity=$quants+$quantity;
                 $insert_data=array("",$itemid,$unitcost,$sellingprice,$quantity,"0.0",$dates,$dates); 
               $update = $stock_table->insertField("comas_biz_stockprice", $insert_data);
             }
             
            if($update){
            $feedback=true;
            }else{
               $insert_data=array("",$itemid,$unitcost,$sellingprice,$quantity,"0.0",$dates,$dates); 
              $states=$stock_table->insertField("comas_biz_stockprice", $insert_data);
        if($states){
            $feedback=true;
            }   
            }
            
            if($updated){
            $feedback=TRUE;    
            }
            
         }else{
          //item is new to stock
        $insert_data=array($item_id,$itemname,$itemunit,$quantity,$dates,$dates,$user_id,$biz_id);
        
        $states=$stock_table->insertField("comas_biz_stock", $insert_data);
        if($states){
            $ispriced=$check_stocks->selectField("comas_biz_stock",array("item_id"),"=","item_name",$itemname."' and user_bizid='".$biz_id,"","","","","");
            if($ispriced){
             $itemid=$check_stocks->getResultSet();
            $insert_datas=array("",$itemid['item_id'],$unitcost,$sellingprice,$quantity,"0.0",$dates,$dates); 
            $stock_table->insertField("comas_biz_stockprice", $insert_datas);
            }
            $feedback=true;
        }
         }
     }else if($action==1){
           //from sales  //we reduce the stock from the database
         
        if($isstocked){
           $stock_item=$check_stock->getResultSet();
          
           $quant=$stock_item['quantity'];
           $itemid=$stock_item['item_id'];
           $newquant=$quant-$quantity;
           if($newquant>=0){
               
            $updated= $stock_table->updateField('comas_biz_stock',array("quantity"=>$newquant,"last_modified_date"=>$dates) ,"item_name", $itemname);
            if($updated){
                $stockprice=self::soldItems($itemid, $quantity, 0);
               $updated= $stock_table->updateField('comas_biz_stockprice',array("sold_quantity"=>$stockprice[0],"modified_date"=>$dates) ,"item_id", $itemid."' and created_date='".$stockprice[1]); 
               $feedback=true; 
            }
           }else{
            $feedback=false;    
           }
        } 
       
     }
    return $feedback;
   }
   
 static function soldItems($itemid,$quantity,$createddate){
     $sold_stock=new ComasDatabase();
     $stock_table=new ComasDatabase();
     $quants="";
     $sold=0;
     $feedback="";
     $date=@date("Y-m-d H:i:s");
     $state=false;
     if($createddate!=0){
      $state=$sold_stock->selectField("comas_biz_stockprice",array("quantity,sold_quantity,created_date"), "=", "item_id",$itemid."' and created_date>'".$createddate,"created_date","asc","", "1");   
     }else{
      $state=$sold_stock->selectField("comas_biz_stockprice",array("quantity,sold_quantity,created_date"), "=", "item_id",$itemid,"created_date","asc","", "1");
     }
           if($state){
               $quants=$sold_stock->getResultSet();
               $differs=$quants['quantity']-$quants['sold_quantity'];
               $dates=$quants['created_date'];
               if($differs==0){
                   $feedback=self::soldItems($itemid, $quantity, $dates);  
               }else if($differs<0){
                 //do other job here 
                  
               }else{
                  $sold=$quantity+$quants['sold_quantity'];
                  $checks=$quants['quantity']-$sold;
                  if($checks>=0){
                    $feedback=array($sold,$dates);  
                  }else{
                    $updated= $stock_table->updateField('comas_biz_stockprice',array("sold_quantity"=>$quants['quantity'],"modified_date"=>$date) ,"item_id", $itemid."' and created_date='".$dates);   
                    if($updated){
                      $feedback=self::soldItems($itemid, $checks*-1, $dates);    
                    }
                  }
                  
               }
           }
      return $feedback;     
 }
   /**
    * This method is used to return the item of given item from the stock
    * @param type $itemname
    * @param type $price
    * @return type
    */
 static function getItemId($itemname,$price){
       $stock_item=new ComasDatabase();
       $bizid=$_SESSION['biz_id'];
       $item_id="0";
       $states=$stock_item->selectField("comas_biz_stock",array("*"), "=", "item_name",$itemname."' and user_bizid='".$bizid, "", "", "", "");
       if($states){
           $items=$stock_item->getResultSet();
       $item_id= $items['item_id'];   
       }else{
           $item_id=self::getLastId("comas_biz_stock", "item_id", "item_id")+1;
       }
     return $item_id;  
   }
   /**
    * This method is used to retrieve last registered id in given table
    * @param type $tablename
    * @param type $id_field
    * @param type $index_field
    * @return type
    */
   static function getLastId($tablename,$id_field,$index_field){
     $findId=new ComasDatabase();
     $lastId=0;
     $islast=$findId->selectField($tablename, array($id_field), "", "", "", $index_field, "desc","", "1");
     if($islast){
       $lastId=$findId->getResultSet(); 
       return $lastId[$id_field];
     }else{
        return $lastId;  
     }
    
   }
  
  /**
   * This method is used to check if the product has been sold at collect price
   * @param type $quantity
   * @param type $totalamount
   * @param type $selling
   * @return boolean
   */
static function checkPrice($quantity,$totalamount,$selling){
    $thissell=$selling*$quantity;
    $debtors=0;
    $feedback=false;
    if($thissell>=$totalamount){
        
       $feedback=true; 
    }else{
       $debtors=$totalamount-$thissell;
     $feedback=true;   
    }
    return $feedback;
}

/**
 * This method is used to calculate extra amount from the given sale
 * @param type $quantity
 * @param type $totalamount
 * @param type $selling
 * @return type
 */
static function finddiscount_loan($quantity,$totalamount,$selling){
  
   $newprice=$selling*$quantity;
    $extra=0;
    $feedback=0;
    if($totalamount==$newprice){
        
       $extra=0; 
    }else if($totalamount<$newprice){
        //sold in discount or loan
       $extra=$newprice-$totalamount;
     $feedback=false;   
    }else if($totalamount>$newprice){
        //sold in raise of price
       $extra=$totalamount-$newprice; 
    }
    return $extra;
}
  /**
   * check if field is empty
   */
 static function isEmpty($field){
     if($field==''){
         return true;
     }else{
         return false;
     }
 }
}
?>

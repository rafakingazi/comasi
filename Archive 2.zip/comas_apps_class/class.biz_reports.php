<?php

class ComasReports{
    private $calculator;
    private $datesFormat;
    private $currency;
    function ComasReports(){
        $this->datesFormat=new ServerValidator();
        $this->calculator=new ComasCalculator($_SESSION['biz_id']);
        if(isset($_SESSION['currency'])){
            $this->currency="".$_SESSION['currency'];
        }else{
            $this->currency="";
        }
    }
    
    function bizSummary(){
      $filter=new AdminFormProcess();
      $myfilter=new ComasFormProcessor();
    $account=$this->calculator;
    $fildata=$myfilter->filterByDate();
    if(isset($fildata[0])){
    $schedule=$fildata[0];
    }else{
     $schedule='Monthly';   
    }
    $dates=@date("Y-m-d");
    $bizid=$_SESSION['biz_id'];
    $purchase=$account->calPurchase( $fildata,false);
     $sales=$account->calSales(  $fildata,false);
      $expenses=$account->calExpenses($fildata,false);
      $drawing=$account->calDrawing($fildata);
      $cash=$account->calCashBalances($fildata);
      $stockcost=self::calStockValue(true,"");
      $fildates="";
      $profdata=array("yearly","","","");
      $dateformat=new ServerValidator();
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);
    $blocks="";
    $blocks.="<div>".$filter->comasDateFilter(false);
    if(is_array($purchase) || is_array($sales) || is_array($expenses) || is_array($drawing)):
      if($hasfilter[1] && $schedule=="all"){
        $fildates=" From ".$dateformat->changeDateFormat($fildata[1],true)." To ".$dateformat->changeDateFormat($fildata[2],true)."";  
      }else{
        $fildates="As On ".$dateformat->changeDateFormat($dates,true);
      } 
    $blocks.="<p style='text-align:center'>".$schedule." Shop Summary :<br/>".$fildates."</p>";
    endif;
    if(is_array($purchase)):
    $blocks.="<div class='content_box inner_box'>";
    $blocks.="<div> <p>Total Purchase<br>".number_format($purchase[1],2,'.',',')."/-".$this->currency."</p></div></div>";
    $blocks.="<div class='content_box inner_box'>";
    $blocks.="<div> <p>Stock Value<br/>".number_format($stockcost[1],2,'.',',')."/-".$this->currency."</p></div></div>";
    endif;
    if(is_array($sales) && is_array($cash)):
     $blocks.="<div class='content_box inner_box'>";
     $blocks.="<div> <p>Total Sales<br/>".number_format($sales[1],2,'.',',')."/-".$this->currency."</p></div></div>";
     $blocks.="<div class='content_box inner_box'>";
     $blocks.="<div> <p>Available Cash<br/>".number_format($cash[1][0],2,'.',',')."/-".$this->currency."</p></div></div>";
    endif;
    if(is_array($expenses)):
    //$blocks.="<div class='content_box inner_box'>";
    //$blocks.="<div> <p>Total Expenses<br/>".number_format($expenses[1],2,'.',',')."/-".$this->currency."</p></div></div>";
    endif;
    if(is_array($drawing)):
    //$blocks.="<div class='content_box inner_box'>";
    //$blocks.="<div> <p>Total Drawing<br/>".number_format($drawing[1],2,'.',',')."/-".$this->currency."</p></div></div>";
    endif;
    if(is_array($expenses)):
    $blocks.="<div class='content_box inner_box'>";
    $blocks.="<div><br/>".$this->busiAtGrance()."</div></div>";
    endif;
    $blocks.="</div>";
    
    return $blocks;
    }
    
    function trialBalance($dates){
        $infor=new ComasInformer();
        $myfilter=new ComasFormProcessor();
    $account=$this->calculator;
    $fildata=$myfilter->filterByDate();
    if(isset($fildata[0])){
    $schedule=$fildata[0];
    }else{
     $schedule='Monthly';   
    }
   
    $purchase=$account->calPurchase($fildata,false);
     $sales=$account->calSales($fildata,false);
      $expenses=$account->calExpenses($fildata,false);
      $drawing=$account->calDrawing($fildata);
      $cash=$account->calCashBalances($fildata);
      $capital=$account->investedCapital();
      $debtors=$account->calCashDebtors($fildata);
      $creditor=$account->calCashCredits($fildata);
      $receivable=$account->calReceivable($fildata);
      $payable=$account->calPayable($fildata);
      $ipayable=$account->caliPayable($fildata);
      $asset=$account->calAssets($fildata);
      $disallowed=$account->calDisAllowed($fildata);
    $blocks="";
   
     if(!(empty($purchase) || empty($sales) || empty($expenses) || empty($drawing))):
   
    endif;
    //make debit/credit side of trialbalance;
    if(!(empty($purchase) || empty($sales) || empty($expenses) || empty($drawing))):
        $capitals=0;
        $mycash=0;
    if(is_array($cash)){
        $mycash=$cash[1][0];
    if($cash[0]){
        $capitals=$cash[2][0];
    } else{
        $capitals=$capital[0];
    }
    }else{
     $capitals=$capital[0];   
    }
        $debit=$mycash+$purchase[1]+$expenses[1]+$drawing[1]+$debtors[1]+$receivable[1]+$asset[0]+$disallowed[1];
        $credit=$capitals+$sales[1]+$payable[1]+$creditor[1];
        $diffes=$debit-$credit;
        $i=1;
    $blocks.="<div style='clear:both;'></div><div class='content_box inner_box'>";
    $blocks.="<div><span style='float:right;'><a href='#' style='text-decoration:none'>PDF</a></span> <p style='text-align:center;'>".$schedule." Trial Balance: <br/>".$dates."</p>";
    $blocks.="<table><tr class='even_row'><td>Sno</td><td>Account Name</td><td></td><td>Debit in ".$this->currency."</td><td>Credit in ".$this->currency."</td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td>Cash</td><td></td><td style='text-align:right;'>".number_format($mycash,2,'.',',')."</td><td style='text-align:right;'></td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td>Office Asset</td><td></td><td style='text-align:right;'>".number_format($asset[0],2,'.',',')."</td><td style='text-align:right;'></td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td>Purchase</td><td></td><td style='text-align:right;'>".number_format($purchase[1],2,'.',',')."</td><td style='text-align:right;'></td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td>Expenses</td><td></td><td style='text-align:right;'>".number_format($expenses[1],2,'.',',')."</td><td style='text-align:right;'></td></tr>";
   // $blocks.="<tr class='odd_row'><td>".($i++)."</td><td>Account Receivable</td><td style='text-align:right;'></td><td style='text-align:right;'><t/d>".number_format($receivable[1],2,'.',',')."<td></td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td>Discount Allowed</td><td style='text-align:right;'></td><td style='text-align:right;'><t/d>".number_format($disallowed[1],2,'.',',')."<td></td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td>Debtors</td><td></td><td style='text-align:right;'>".number_format($debtors[1],2,'.',',')."</td><td style='text-align:right;'></td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td>Drawing</td><td></td><td style='text-align:right;'>".number_format($drawing[1],2,'.',',')."</td><td style='text-align:right;'></td></tr>";
    $blocks.="<tr class='even_row'><td>".($i++)."</td><td>Capital</td><td></td><td style='text-align:right;'></td><td style='text-align:right;'>".number_format($capitals,2,'.',',')."</td></tr>";
    $blocks.="<tr class='even_row'><td>".($i++)."</td><td>Sales</td><td></td><td style='text-align:right;'></td><td style='text-align:right;'>".number_format($sales[1],2,'.',',')."</td></tr>";
    $blocks.="<tr class='even_row'><td>".($i++)."</td><td>Creditors</td><td></td><td style='text-align:right;'></td><td style='text-align:right;'>".number_format($creditor[1],2,'.',',')."</td></tr>";
  //  $blocks.="<tr class='even_row'><td>".($i++)."</td><td>Account Payable</td><td ></td><td style='text-align:right;'></td><td style='text-align:right;'>".number_format($payable[1],2,'.',',')."</td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td></td><td></td><td style='text-align:right;'><hr>".number_format($debit,2,'.',',')."</td><td style='text-align:right;'><hr>".number_format($credit,2,'.',',')."</td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td></td><td>Different btn Dr-Cr</td><td style='text-align:right;'></td><td style='text-align:right;'>".number_format($diffes,2,'.',',')."</td></tr>";
    $blocks.="<tr class='odd_row'><td>".($i++)."</td><td></td><td>Total</td><td style='text-align:right;'><hr>".number_format($debit,2,'.',',')."<hr><hr></td><td style='text-align:right;'><hr>".number_format($debit,2,'.',',')."<hr><hr></td></tr></table>";
    $blocks.="</div></div>";
    endif;
    return $blocks;
    
    }
    
    
   function bizDetails(){
      $account=$this->calculator;
      $schedule='Monthly';
       $purchase=$account->calPurchase( $schedule,true);
     $sales=$account->calSales( $schedule,true);
      $expenses=$account->calExpenses( $schedule,true);
      $drawing=$account->calDrawing($schedule);
    $blocks="";
    $blocks.="<div>";
    if(!(empty($purchase) || empty($sales) || empty($expenses) || empty($drawing))):
    //$blocks.="<p>".$schedule." Shop Activity Details</p>";
    endif;
     $count=count($purchase);
    if(is_array($purchase) && $count>0):
       
    $blocks.="<div class='content_box inner_box'>";
    $blocks.="<div> <p>Purchase Detail<br></p>";
    $blocks.="<table><tr class='even_row'><td>Sno</td><td>Cost/item</td><td>Quantity</td><td>Item Name</td><td>Date</td></tr>";
    $j=1;
    foreach($purchase as $value){
        $count=count($value);
        if($j%2==0){
        $blocks.="<tr class='even_row'>";
        }else{
           $blocks.="<tr class='odd_row'>";   
        }
        for($i=0; $i<$count; $i++){
            if($i==1){
        $blocks.="<td>".number_format($value[$i],2,'.',',')."</td>";
            }else{
         $blocks.="<td>".$value[$i]."</td>";    
            }
        }
        $blocks.="</tr>";
        $j++;
    }
    $blocks.="</table>";
    $blocks.="</div></div>";
    endif;
    $counts=count($sales);
    if(is_array($sales) && $counts>0):
     $blocks.="<div class='content_box inner_box'>";
    $blocks.="<div> <p>Sales Details</br></p>";
     $blocks.="<table><tr class='even_row'><td>Sno</td><td>Amount Received</td><td>Quantity</td><td>Item</td><td>Date</td></tr>";
     $j=1;
    foreach($sales as $value){
        $count=count($value);
        if($j%2==0){
        $blocks.="<tr class='even_row'>";
        }else{
           $blocks.="<tr class='odd_row'>";   
        }
        for($i=0; $i<$count; $i++){
          if($i==1){
        $blocks.="<td>".number_format($value[$i],2,'.',',')."</td>";
            }else{
         $blocks.="<td>".$value[$i]."</td>";    
            }     
        }
        $blocks.="</tr>";
        $j++;
    }
    $blocks.="</table>";
    $blocks.="</div></div>";
    endif;
    $countz=count($expenses);
    if(is_array($expenses) && $countz>0):
    $blocks.="<div class='content_box inner_box'>";
    $blocks.="<div> <p>Expenses Details</br></p>";
     $blocks.="<table><tr class='even_row'><td>Sno</td><td>Cost</td><td>Quantity</td><td>Expense Name</td><td>Date</td></tr>";
     $j=1;
    foreach($expenses as $value){
        $count=count($value);
       if($j%2==0){
        $blocks.="<tr class='even_row'>";
        }else{
           $blocks.="<tr class='odd_row'>";   
        }
        for($i=0; $i<$count; $i++){
          if($i==1){
        $blocks.="<td>".number_format($value[$i],2,'.',',')."</td>";
            }else{
         $blocks.="<td>".$value[$i]."</td>";    
            }    
        }
        $blocks.="</tr>";
        $j++;
    }
    $blocks.="</table>";
    $blocks.="</div></div>";
    endif;
    
    return $blocks;
    
   }
   
   function purchaseHistory($offset,$limit,$totalcost,$totalsell,$toajax,$toreport){
       $bizid=$_SESSION['biz_id'];
       $purchases=new ComasDatabase();
       $purchz=new ComasDatabase();
       $counts=new ComasDatabase();
       $count=0;
       if($toreport){
         $offset=0;
         $limit="";
       }else{
       $limit=$limit;
       $offset=$offset;  
       }
       if($toajax){
       $totalcost=$totalcost;
       $totalsell=$totalsell;
       }else{
       $totalcost=0;
       $totalsell=0;    
       }
       $dateformat=$this->datesFormat;
       $data="";
       $noajax="";
       $myfilter=new ComasFormProcessor();
       $fildata=$myfilter->filterByDate();
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);
       $status=false;
       $avail=false;
       $paginate="";
       $item_id="end";
       if(!($hasfilter[3])){
             if($hasfilter[1]){
                 $count=$counts->countrows("comas_biz_purchase","=","user_bizid",$bizid."' and purchase_date>='".$fildata[1]."' and purchase_date<='".$fildata[2]);
           $status= $purchases->selectField("comas_biz_purchase", array("*"), ">=","purchase_date", $fildata[1]."' and purchase_date<='".$fildata[2]."' and user_bizid='".$bizid, "", "", $offset, $limit);
           }else{
              $count=$counts->countrows("comas_biz_purchase","=","user_bizid",$bizid."' and purchase_date>='".$hasfilter[4]);
            $status= $purchases->selectField("comas_biz_purchase", array("*"), ">=","purchase_date", $hasfilter[4]."' and user_bizid='".$bizid, "", "", $offset,$limit);
               
            
           }
       }else{
         if($hasfilter[1]){
          $count=$counts->countrows("comas_biz_purchase","=","user_bizid",$bizid."' and purchase_date>='".$fildata[1]."' and purchase_date<='".$fildata[2]."' and item_id='".$fildata[3]);
           $status= $purchases->selectField("comas_biz_purchase", array("*"), ">=","purchase_date", $fildata[1]."' and purchase_date<='".$fildata[2]."' and item_id='".$fildata[3]."' and user_bizid='".$bizid, "", "",$offset,$limit);
           
            }else{
             $count=$counts->countrows("comas_biz_purchase","=","user_bizid",$bizid."' and purchase_date>='".$hasfilter[4]."' and item_id='".$fildata[3]);
            $status= $purchases->selectField("comas_biz_purchase", array("*"), ">=","purchase_date", $hasfilter[4]."' and  item_id='".$fildata[3]."' and user_bizid='".$bizid, "", "",$offset,$limit);
            }
       }
       
       if($status){
           
         $j=0;
         $i=1;
         
           if($offset!=0){
           $j=$offset;
           $i=$offset;
           }
           
        $data.="<table  id='updates' class='ui-responsive table-stroke' data-role='table' id='sample' data-mode='columntoggle' data-top-container='true' data-bottom-container='true' data-inset='true' data-filter='true' ><caption>Purchase Book:";
        if($hasfilter[3]){
         $avail=$purchz->selectField("comas_biz_stock", array("item_name,item_unit"), "=", "item_id", $fildata[3], "", "", "", "");
        if($avail){
          $item=$purchz->getResultSet();
        $data.="<br/>".$item['item_name']."(".$item['item_unit'].")";
        }   
        }
        $data.="</caption><thead><tr class='head_row'><th scope='col' >Sno</th>";
        if(!$hasfilter[3]){
        $data.="<th scope='col'>Product Name</th >";
        }
        $data.="<th scope='col' >Quantity</th><th>Buying Price/unit(".$this->currency.")</th>";
         $data.="<th scope='col' >Total Buying Price(".$this->currency.")</th><th scope='col' >Selling Price/unit(".$this->currency.")</th><th scope='col' >Total selling Price(".$this->currency.")</th><th scope='col'>Date Purchase</th></tr></thead>";

           while($rects=$purchases->getResultSet()){
               if(!$hasfilter[3]){
               $avail=$purchz->selectField("comas_biz_stock", array("*"), "=", "item_id", $rects['item_id'], "", "", "", "");
               }
               if($avail){
                   $item=$purchz->getResultSet();
                   if($i%2==0){
                    $paginate.="<tr class='even_row'>"; 
                   }else{
                    $paginate.="<tr class='odd_row'>";    
                   }
                   $totalcost+=$rects['total_cost'];
                   $totalsell+=$rects['total_price'];
                   $results=$dateformat->getDateDiffence(@date("Y-m-d"),$rects['purchase_date']);
              $paginate.="<td>".$i."</td>";
              
             $item_id=$i;
              
              if(!$hasfilter[3]){
              $paginate.="<td>".$item['item_name']."(".$item['item_unit'].")</td>";
              }
              $paginate.="<td>".$rects['total_unit']."</td><td>".number_format($rects['cost_per_unit'],2,'.',',')."</td>";
              $paginate.="<td>".number_format($rects['total_cost'],2,'.',',')."</td><td>".number_format($rects['price_per_unit'],2,'.',',')."</td><td>".number_format($rects['total_price'],2,'.',',')."</td><td>".$dateformat->changeDateFormat($rects['purchase_date'],true)."</td></tr>";
              
               }
               $i++;
               $j++;
           }
           if($j==$count){
            $j="end";   
           }
        
           $paginate.="<tr class='odd_row canremove ' ><td>".$i."</td><td><div id='".$j."' class='loadsdata' style='display:inline;'></div></td><td>Total</td>";
           $paginate.="<td><div id='cost' class='".$totalcost."'></div><div id='sell' class='".$totalsell."'></div<div id='totalrows' class='".$count."'></div></td>";
           $paginate.="<td><hr/>".number_format($totalcost,2,'.',',')."<hr><hr></td><td></td><td><hr/>".number_format($totalsell,2,'.',',')."<hr/><hr/></td><td></td></tr>";
           $data.=$paginate;
           $data.="</table>";
           
           if(!$toreport){
               
            if($j!="end"){
               $data.='<div class="myloader"><div id="pageid" class="2" ></div><a id="'.$i.'" href="#" class="load_more" style="text-decoration:none">Show More Purchase</a></div>';
            }
           
              }
          
           
            
           
       }
       if(!$toajax){
       return $data;
       }else{
        return $paginate;    
       }
   }
  
function salesHistory(){
    $bizid=$_SESSION['biz_id'];
    $sales=new ComasDatabase();
    $purchz=new ComasDatabase();
    $dateformat=$this->datesFormat;
    $totalcash=0;
    $totaldisc=0;
    $totaldebt=0;
    $expected_revenue=0;
    $net_revenue=0;
       $data="";
       $myfilter=new ComasFormProcessor();
       $fildata=$myfilter->filterByDate();
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);
       $avail=false;
       $status=false;
       if(!($hasfilter[3])){
           if($hasfilter[1]){
           $status=$sales->selectField("comas_biz_sales", array("*"), "=", "user_bizid", $bizid."' and sales_date>='".$fildata[1]."' and sales_date<='".$fildata[2], "", "", "", "");
            }else{
           $status=$sales->selectField("comas_biz_sales", array("*"), "=", "user_bizid", $bizid."' and sales_date>='".$hasfilter[4], "", "", "", "");
            }
       }else{
         if($hasfilter[1]){
           $status=$sales->selectField("comas_biz_sales", array("*"), "=", "user_bizid", $bizid."' and sales_date>='".$fildata[1]."' and sales_date<='".$fildata[2]."' and item_id='".$fildata[3], "", "", "", "");
            }else{
           $status=$sales->selectField("comas_biz_sales", array("*"), "=", "user_bizid", $bizid."' and sales_date>='".$hasfilter[4]."' and item_id='".$fildata[3], "", "", "", "");     
        }
      }
    
    if($status){
        $i=1;
        
    $data.="<table><caption>Sales Book:";
    if($hasfilter[3]){
    $avail=$purchz->selectField("comas_biz_stock", array("*"), "=", "item_id", $fildata[3], "", "", "", "");
    if($avail){
     $item=$purchz->getResultSet();
     $data.="<br/> ".$item['item_name']." (".$item['item_unit'].")";
    }
    }
    $data.="</caption><thead><tr class='head_row'><th>Sno</th>";
    if(!$hasfilter[3]){
    $data.="<th>Product Name</th>";
    }
    $data.="<th>Sold</th><th>Amount Received(".$this->currency.")</th>";
    $data.="<th>Discount</th><th>Debt</td><th>Receipt No</th><th>Date Sold</th></tr></thead>"; 
        while($rects=$sales->getResultSet()){
            $loan=0.0;
           $disc=0.0;
           if(!$hasfilter[3]){
          $avail=$purchz->selectField("comas_biz_stock", array("*"), "=", "item_id", $rects['item_id'], "", "", "", "");
           }
          if($avail){
            $item=$purchz->getResultSet();
                   if($i%2==0){
                    $data.="<tr class='even_row'>"; 
                   }else{
                    $data.="<tr class='odd_row'>";    
                   }
                   switch($rects['loan_discount_flag']){
                       case 1:
                           $disc=$rects['loan_discount_amount'];
                           $totaldisc+=$disc;
                           break;
                       case 2:
                           $loan=$rects['loan_discount_amount'];
                           $totaldebt+=$loan;
                           break;
                       
                   }
                   $totalcash+=$rects['total_amount_received'];
                   
         $data.="<td>".$i."</td>";
         if(!$hasfilter[3]){
         $data.="<td>".$item['item_name']."(".$item['item_unit'].")</td>";
         }
         $data.="<td>".$rects['total_unit_sold']."</td><td>".number_format($rects['total_amount_received'],2,'.',',')."</td>";
              $data.="<td>".number_format($disc,2,'.',',')."</td><td>".number_format($loan,2,'.',',')."</td><td>".$rects['receiptno']."</td><td>".$dateformat->changeDateFormat($rects['sales_date'],true)."</td></tr>";
             
          }
          $i++;
        }
        $expected_revenue=$totalcash+$totaldisc+$totaldebt;
        $net_revenue=$totalcash+$totaldebt;
          $data.="<tr class='odd_row'><td>".$i."</td><td>Sub Total</td><td></td><td><hr>".number_format($totalcash,2,'.',',')."</td>";
          $data.="<td><hr>".number_format($totaldisc,2,'.',',')."</td><td><hr>".number_format($totaldebt,2,'.',',')."</td><td></td><td></td></tr>";
          $data.="<tr class='odd_row'><td>".($i+1)."</td><td>Expected Revenue</td><td></td><td></td>";
          $data.="<td></td><td></td><td><hr>".number_format($expected_revenue,2,'.',',')."</td><td></td></tr>";
          $data.="<tr class='odd_row'><td>".($i+2)."</td><td>Net Revenue</td><td></td><td></td>";
          $data.="<td></td><td></td><td><hr>".number_format($net_revenue,2,'.',',')."<hr></td><td></td></tr></table>";
             
    }
    return $data;
}

function expensesHistory(){
   $bizid=$_SESSION['biz_id'];
   $expense=new ComasDatabase();
   $total_expenses=0;
   $dateformat=$this->datesFormat;
       $data="";
       $myfilter=new ComasFormProcessor();
       $fildata=$myfilter->filterByDate();
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);
       $status=false;
       if(!($hasfilter[3])){
           if($hasfilter[1]){
          $status=$expense->selectField("comas_biz_expenses", array("*"), "=", "user_bizid", $bizid."' and expenses_date>='".$fildata[1]."' and expenses_date<='".$fildata[2], "", "", "", "");
         
            }else{
         $status=$expense->selectField("comas_biz_expenses", array("*"), "=", "user_bizid", $bizid."' and expenses_date>='".$hasfilter[4], "", "", "", "");
          }
       }
      if($status){
        $i=1;
     $data.="<table><caption>Expense Book:</caption><thead><tr class='head_row'><th>Sno</th><th>Expense Name</th><th>Amount Paid</th><th>Receipt No</th>";
     $data.="<th>Description</th><td>Date</th></tr>";
      while($rects=$expense->getResultSet()){
        if($i%2==0){
                    $data.="<tr class='even_row'>"; 
                   }else{
                    $data.="<tr class='odd_row'>";    
                   } 
              $total_expenses+=$rects['cost_per_unit']; 
              $results=$dateformat->getDateDiffence($rects['expenses_start'],$rects['expenses_end']);
              $resultz=$dateformat->getDateDiffence($rects['expenses_start'],$rects['expenses_end']);
      $data.="<td>".$i."</td><td>".$rects['expenses']."</td><td>".number_format($rects['cost_per_unit'],2,'.',',')."</td><td>".$rects['receipt']."</td>";
      $data.="<td>".$rects['description']."".$results[0]."</td><td>".$dateformat->changeDateFormat($rects['expenses_date'],true)."</td></tr>";
             
       $i++;
      }
      $data.="<tr class='odd_row'><td>".$i."</td><td>Total</td><td><hr>".number_format($total_expenses,2,'.',',')."<hr><hr></td><td></td>";
      $data.="<td></td><td></td></tr></table>";
    }
  return $data;
}

function stockHistory(){
   $bizid=$_SESSION['biz_id'];
   $stock=new ComasDatabase();
   $dateformat=$this->datesFormat;
   $data="";
   $totalvalue=0;
   $item_name="";
    $myfilter=new ComasFormProcessor();
       $fildata=$myfilter->filterByDate();
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);
       $status=false;
       
       
       if(!($hasfilter[3])){
           if($hasfilter[1]){
          $status=$stock->selectField("comas_biz_stock", array("*"), "=", "user_bizid", $bizid."' and date_created>='".$fildata[1]."' and  date_created<='".$fildata[2], "", "", "", "");
            }else{
           $status=$stock->selectField("comas_biz_stock", array("*"), "=", "user_bizid", $bizid."' and date_created>='".$hasfilter[4], "", "", "", "");
              }
       }else{
         if($hasfilter[1]){
          $status=$stock->selectField("comas_biz_stock", array("*"), "=", "user_bizid", $bizid."' and date_created>='".$fildata[1]."' and date_created<='".$fildata[2]."' and item_id='".$fildata[3], "", "", "", "");
            }else{
           $status=$stock->selectField("comas_biz_stock", array("*"), "=", "user_bizid", $bizid."' and date_created>='".$hasfilter[4]."' and item_id='".$fildata[3], "", "", "", "");
              }   
       }
    if($status){
        $i=1;
        $data.="<table>";
         if(!$hasfilter[3]){
        $data.="<caption>Stock Book</caption><thead><tr class='head_row'><th>Sno</th><th>Product Name</th><th>Total Stocked</th>";
        $data.="<th>Total Sold</th><th>Amount InStock</th><th>Remain Stock Sell Value(".$this->currency.")</th><th>Last Updated Date</th></tr></thead>";
         }
    while($rects=$stock->getResultSet()){
        if(!$hasfilter[3]){
        if($i%2==0){
           $data.="<tr class='even_row'>"; 
            }else{
            $data.="<tr class='odd_row'>";    
           } 
           //array($quantity,$sold,$remained,$totalcost,$soldcost,$stockcost);
           $instock=  self::calculateStock($rects['item_id'],$fildata,$hasfilter,"<=",true);
           if(!is_array($instock)){
            $instock=array(0,0,0,0,0,0);   
           }
          $totalvalue+=$instock[6]; 
     $data.="<td>".$i."</td><td>".$rects['item_name']."(".$rects['item_unit'].")</td><td>".$instock[0]."</td><td>".$instock[1]."</td>";
      $data.="<td>".$instock[2]."</td><td>".number_format($instock[6],2,'.',',')."</td><td>".$dateformat->changeDateFormat($rects['last_modified_date'],true)."</td></tr>";
     $i++; 
        }else{
            $item_name=$rects['item_name']."(".$rects['item_unit'].")";
        }
    }
    if(!$hasfilter[3]){
    $data.="<tr class='odd_row'><td>".$i."</td><td></td><td></td><td>Total</td>";
      $data.="<td></td><td><hr>".number_format($totalvalue,2,'.',',')."<hr><hr></td><td></td></tr></table>";
    }else{
        $data.="<caption>Stock Book:<br/>".$item_name."</caption>";
    }
    }
    $data.=$this->stockItemDetails($fildata, $hasfilter);
    
    return $data;
}

function stockItemDetails($fildata,$hasfilter){
  $stock=new ComasDatabase();
  $dateformat=$this->datesFormat;
  $data="";
  $price=0;
  $status=false;
       if(($hasfilter[3])){
           if($hasfilter[1]){
          $status=$stock->selectField("comas_biz_stockprice", array("*"), "=", "item_id", $fildata[3]."' and  modified_date>='".$fildata[1]."' and modified_date<='".$fildata[2], "modified_date", "desc", "", "");
         
         
            }else{
           $status=$stock->selectField("comas_biz_stockprice", array("*"), "=", "item_id", $fildata[3]."' and  modified_date>='".$hasfilter[4], "modified_date", "desc", "", ""); 
  
              }
       }
   
  if($status){
      $price=  self::getSellingPrice($fildata[3]);
      $i=1;
   $data.="<thead><tr class='head_row'><th>Sno</th><th>Bought</th><th>Sold</th><th>In Stock</th><th>Cost Per Unit(".$this->currency.")</th><th>Selling Price(".$this->currency.")</th><th>Total Value(".$this->currency.")</th><th>Date</th></tr><thead>";
   while($rects=$stock->getResultSet()){
       $remain=$rects['quantity']-$rects['sold_quantity'];
       $sellingcost=0;
        if($i%2==0){
           $data.="<tr class='even_row'>"; 
            }else{
            $data.="<tr class='odd_row'>";    
           } 
      if($price!=0){
       $sellingcost=$price*$remain;   
      }
       $data.="<td>".$i."</td><td>".$rects['quantity']."</td><td>".$rects['sold_quantity']."</td><td>".$remain."</td><td>".number_format($rects['unitcost'],2,'.',',')."</td>";
      $data.="<td>".number_format($price,2,'.',',')."</td><td>".number_format($sellingcost,2,'.',',')."</td><td>".$dateformat->changeDateFormat($rects['modified_date'],true)."</td></tr>";
      $i++;    
      } 
      $data.="</table>";
  }
  return $data;
}

function drawingHistory(){
    $bizid=$_SESSION['biz_id'];
   $stock=new ComasDatabase();
   $dateformat=$this->datesFormat;
   $data="";
   $totaldraw=0;
   $myfilter=new ComasFormProcessor();
       $fildata=$myfilter->filterByDate();
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);
       $status=false;
       if(!($hasfilter[3])){
           if($hasfilter[1]){
          $status=$stock->selectField("comas_biz_draw_account", array("*"), "=", "user_bizid", $bizid."' and draw_date>='".$fildata[1]."' and draw_date<='".$fildata[2], "", "", "", "");
         
            }else{
         $status=$stock->selectField("comas_biz_draw_account", array("*"), "=", "user_bizid", $bizid."' and  draw_date>='".$hasfilter[4], "", "", "", "");
         }
       }
   
    if($status){
        $i=1;
      $data.="<table><caption>Drawing Book:</caption><thead><tr class='head_row'><th>Sno</th><th>Amount(".$this->currency.")</th><th>Description</th><th>Date Paid</th></tr></thead>";

    while($rects=$stock->getResultSet()){
        if($i%2==0){
           $data.="<tr class='even_row'>"; 
            }else{
            $data.="<tr class='odd_row'>";    
           }
           $totaldraw+=$rects['amount_drawn'];
      $data.="<td>".$i."</td><td>".$rects['draw_description']."</td><td>".number_format($rects['amount_drawn'],2,'.',',')."</td><td>".$dateformat->changeDateFormat($rects['draw_date'],true)."</td></tr>";
      $i++; 
    }
     $data.="<tr class='odd_row'><td>".$i."</td><td>Total</td><td><hr>".number_format($totaldraw,2,'.',',')."<hr></td><td></td></tr></table>";
    }
    return $data;
}

function assetHistory(){
   $bizid=$_SESSION['biz_id'];
   $stock=new ComasDatabase();
   $dateformat=$this->datesFormat;
   $data="";
   $totalasset=0;
   $myfilter=new ComasFormProcessor();
       $fildata=$myfilter->filterByDate();
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);
       $status=false;
       if(!($hasfilter[3])){
           if($hasfilter[1]){
           $status=$stock->selectField("comas_biz_asset", array("*"), "=", "user_bizid", $bizid."' and asset_addedDate>='".$fildata[1]."' and asset_addedDate<='".$fildata[2], "", "", "", "");
          }else{
         $status=$stock->selectField("comas_biz_asset", array("*"), "=", "user_bizid", $bizid."' and  asset_addedDate>='".$hasfilter[4], "", "", "", "");
         }
       }
   
    if($status){
        $i=1;
  $data.="<table><caption>Asset Book:</caption><thead><tr class='head_row'><th>Sno</th><th>Asset Name</th><th>Asset Type</th><th>Asset Cost(".$this->currency.")</th>";
  $data.="<th>Asset Receipt</th><th>Date Added</th></tr></thead>";
    while($rects=$stock->getResultSet()){
        if($i%2==0){
           $data.="<tr class='even_row'>"; 
            }else{
            $data.="<tr class='odd_row'>";    
           }
           $totalasset+=$rects['asset_cost'];
      $data.="<td>".$i."</td><td>".$rects['asset_name']."</td><td>".$rects['asset_type']."</td><td>".number_format($rects['asset_cost'],2,'.',',')."</td><td>".$rects['asset_receipt']."</td><td>".$dateformat->changeDateFormat($rects['asset_addedDate'],true)."</td></tr>";
      $i++; 
    }
     $data.="<tr class='odd_row' ><td>".$i."</td><td>Total</td><td></td><td><hr>".number_format($totalasset,2,'.',',')."<hr></td><td></td><td></td></tr></table>";
    }
    return $data;   
}

static function getSellingPrice($item_id){
    $stock=new ComasDatabase();
    $price=0;
  $state=$stock->selectField("comas_biz_stockprice", array("sellingprice"), "=", "item_id", $item_id, "modified_date", "desc", "", "1");
  if($state){
     $rects=$stock->getResultSet(); 
    $price=$rects['sellingprice']; 
  }
  return $price;
}

static function calculateStock($item_id,$fildata,$hasfilter,$condi,$isclosestock){
  $stock=new ComasDatabase();
  $quantity=0;
  $sold=0;
  $remained=0;
  $stockcost=0;
  $totalcost=0;
  $soldcost=0;
  $today=@date("Y-m-d");
   $datez=@strtotime("+1 day", @strtotime($today));
   $dates=@date("Y-m-d",$datez);
  $date1="0000-00-00";
  $date2="0000-00-00";
  $stocksell=0;
  $price=0;
  $instock="";
  $status=false;
  if($isclosestock){
           $date1=$dates;
           $date2=$dates;
        $condi="<=" ;
       }else{
           $date1=$fildata[1];
           $date2=$hasfilter[4];
        $condi="<=" ;   
       }
  if($hasfilter[1]){
     $status=$stock->selectField("comas_biz_stockprice", array("*"), "=", "item_id", $item_id."'  and created_date".$condi."'".$date1."' and created_date<='".$fildata[2], "", "", "", "");
       }else{
         $status=$stock->selectField("comas_biz_stockprice", array("*"), "=", "item_id", $item_id."'  and created_date".$condi."'".$date2, "", "", "", "");
      
              } 
  if($status){
      while($rects=$stock->getResultSet()){
          $quantity+=$rects['quantity'];
          $sold+=$rects['sold_quantity'];
          $totalcost+=($rects['quantity']*$rects['unitcost']);
          $soldcost+=($rects['sold_quantity']*$rects['unitcost']);
          $price=  self::getSellingPrice($rects['item_id']);
      }
      $remained=$quantity-$sold;
      $stocksell=$remained*$price;
      $stockcost=$totalcost-$soldcost;
      $instock=array($quantity,$sold,$remained,$totalcost,$soldcost,$stockcost,$stocksell);
  }
  return $instock;
}

static function calStockValue($isclosingstock,$fildatas){
  $bizid=$_SESSION['biz_id'];
   $stock=new ComasDatabase();

   $remainstocksell=0;
   $stockcost=0;
   $totalcost=0;
   $result="";
   $hasfilter="";
   $fildata="";
   $today=@date("Y-m-d");
   $datez=@strtotime("+1 day", @strtotime($today));
   $dates=@date("Y-m-d",$datez);
   $date1="0000-00-00";
   $date2="0000-00-00";
   if($fildatas!=""){
       $fildata=$fildatas;
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);
   }else{
    $myfilter=new ComasFormProcessor();
       $fildata=$myfilter->filterByDate();
       $filters=new ComasCalculator($bizid);
       $hasfilter=$filters->filterHelper("",$fildata);   
   }
       $status=false;
       $condi="";
       if($isclosingstock){
           $date1=$dates;
           $date2=$dates;
        $condi="<=" ;
       }else{
           $date1=$fildata[1];
           $date2=$hasfilter[4];
        $condi="<=" ;   
       }
       
       if(!($hasfilter[3])){
           if($hasfilter[1]){
          $status=$stock->selectField("comas_biz_stock", array("*"), "=", "user_bizid", $bizid."' and date_created".$condi."'".$date1."' and date_created<='".$fildata[2], "", "", "", "");
            }else{
           $status=$stock->selectField("comas_biz_stock", array("*"), "=", "user_bizid", $bizid."' and  date_created".$condi."'".$date2, "", "", "", "");
              }
       }else{
         if($hasfilter[1]){
          $status=$stock->selectField("comas_biz_stock", array("*"), "=", "user_bizid", $bizid."' and  date_created".$condi."'".$date1."' and date_created<='".$fildata[2]."' and item_id='".$fildata[3], "", "", "", "");
            }else{
           $status=$stock->selectField("comas_biz_stock", array("*"), "=", "user_bizid", $bizid."' and  date_created".$condi."'".$date2."' and item_id='".$fildata[3], "", "", "", "");
              }   
       }
   if($status){
        $i=1;
    while($rects=$stock->getResultSet()){
        
           $instock=  self::calculateStock($rects['item_id'],$fildata,$hasfilter,$condi,$isclosingstock);
           $price=  self::getSellingPrice($rects['item_id']);
           if(!is_array($instock)){
            $instock=array("0","0","0");   
           }else{
            
             $remainstocksell+=($price*$instock[2]);
             $stockcost+=$instock[5];
             $totalcost+=$instock[3];
           }
     
     $i++; 
    }
    $result=array($remainstocksell,$stockcost,$totalcost);
    }
    if(!is_array($result)){
      $result=array(0,0,0);  
    }
    return $result;   
}

function calNetProfit($fildata){
 // $myfilter=new ComasFormProcessor();
    $account=$this->calculator;
 //$fildata=$myfilter->filterByDate();
    
   // $dates=@date("Y-m-d");
   // $bizid=$_SESSION['biz_id'];
    $purchase=$account->calPurchase( $fildata,false);
     $sales=$account->calSales(  $fildata,false);
      $expenses=$account->calExpenses($fildata,false);
     // $drawing=$account->calDrawing($fildata);
    // $cash=$account->calCashBalances($fildata);
     $stockcost=self::calStockValue(false,$fildata); 
     $closestock=self::calStockValue(true,$fildata);
     $costofsale=$stockcost[1]+$purchase[1]-$closestock[1];
     $grossprofit=$sales[1]-$costofsale;
     $netprofit=$grossprofit-$expenses[1];
    return $netprofit;
}

function busiAtGrance(){
 $yearly=array("yearly","","","");
 $monthly=array("monthly","","","");
 $weekly=array("weekly","","","");
 $profit="";
 $account=$this->calculator;
 $purch_w=$account->calPurchase( $weekly,false);
 $sales_w=$account->calSales(  $weekly,false);
 $expen_w=$account->calExpenses($weekly,false);
 $stock_w=self::calStockValue(false,$weekly); 
 $stockx_w=self::calStockValue(true,$weekly);
 $net_w=$this->calNetProfit($weekly);
 
 $expen_y=$account->calExpenses($yearly,false);
 $stock_y=self::calStockValue(false,$yearly);
 $purch_y=$account->calPurchase( $yearly,false);
 $sales_y=$account->calSales($yearly,false); 
 $stockx_y=self::calStockValue(true,$yearly);
 $net_y=$this->calNetProfit($yearly);
 
 $purch_m=$account->calPurchase( $monthly,false);
 $sales_m=$account->calSales(  $monthly,false);
 $expen_m=$account->calExpenses($monthly,false);
 $stock_m=self::calStockValue(false,$monthly); 
 $stockx_m=self::calStockValue(true,$monthly);
 $net_m=$this->calNetProfit($monthly);
 
 $profit.="<table><caption>Business StandUp</caption><thead><tr class='even_row'><th></th><th>Last 7 days</th><th>Month-to-date</th><th>Year-to-Date</th</tr></thead>";
 $profit.="<tr class='odd_row'><td>Sales</td><td>".$sales_w[1]."</td><td>".$sales_m[1]."</td><td>".$sales_y[1]."</td></tr>";
 $profit.="<tr class='even_row'><td>Purchases</td><td>".$purch_w[1]."</td><td>".$purch_m[1]."</td><td>".$purch_y[1]."</td></tr>";
 $profit.="<tr  class='odd_row'><td>Opening Stock</td><td>".$stock_w[1]."</td><td>".$stock_m[1]."</td><td>".$stock_y[1]."</td></tr>";
 $profit.="<tr class='even_row'><td>Closing Stock</td><td>".$stockx_w[1]."</td><td>".$stockx_m[1]."</td><td>".$stockx_y[1]."</td></tr>";
 $profit.="<tr  class='odd_row'><td>Expenses</td><td>".$expen_w[1]."</td><td>".$expen_m[1]."</td><td>".$expen_y[1]."</td></tr>";
 $profit.="<tr   class='even_row'><td>Net Profit</td><td>".$net_w."</td><td>".$net_m."</td><td>".$net_y."</td></tr>";
 $profit.="</table>";
 return $profit;
} 

function billHistory(){
    $bizid=$_SESSION['biz_id'];
    $userbiz=new ComasDatabase();
    $demo=new ComasDatabase;
    $bills=new ComasDatabase();
    $dates=@date("Y-m-d");
    $duration=0;
    $amount=0;
    $permonth=0;
    $data="";
    $package="";
    $expired="";
    $status=$userbiz->selectField("comas_user_business",array("biz_owner_id"),"=","user_bizid",$bizid,"","","","");
    if($status){
     $myid=$userbiz->getResultSet();
     $userid=$myid['biz_owner_id'];
    $hasdemo=$demo->selectField("comas_demo",array("*"),"=","user_id",$userid."' and expire_date>='".$dates,"","","","");
    if($hasdemo){
        $remain=$demo->getResultSet();
       
      $remained=(@strtotime($remain['expire_date'])-@strtotime($dates))/(60*60*24);
      $data.="<p style='color:green'> Remained Free Period Is :".$remained." Days</p>";
    }else{
     $state=$bills->selectField("comas_feepayment",array("*"),"=","user_id", $userid,"","","","");  
     if($state){
     $i=1;
    $data.="<table><caption>Bill History</caption><thead>";
    $data.="<tr class='even_row'><th>Sno</th><th>Package</th><th>Bill/Month(TSHS)</th><th>Amount(TSHS)</th><th>Duration(Month)</th><th>Start Date</th>";
    $data.="<th>Expire Date</th><th>Status</th></tr></thead>";
    while($bil=$bills->getResultSet()){
        if($bil['bill_expire_date']>=$dates){
         $expired="<span style='color:green'>Active</span>";
        }else{
          $expired="<span style='color:red'>Expired</span>"; 
        }
        $amount=$bil['amount_paid'];
        switch($bil['bill_package']){
             case 2:
            $package="BRONZE";
           $duration=$amount/5000;
           $permonth=5000;
               break;
            case  3:
             $package="SILVER";
             $duration=$amount/10000; 
             $permonth=10000;
               break;
            case  4:
             $package="GOLD";
             $duration=$amount/30000;
             $permonth=30000;
              break;
        }
       if($i%2==0){
           $data.="<tr class='even_row'>"; 
            }else{
            $data.="<tr class='odd_row'>";    
           }
     $data.="<td>".$i."</td><td>".$package."</td><td>".number_format($permonth,2,".",",")."</td><td>".number_format($amount,2,".",",")."</td><td>".$duration."</td><td>".$bil['bill_startdate']."</td><td>".$bil['bill_expire_date']."</td><td>".$expired."</td></tr>";
    }
    $data.="</table>";
     }
    }
    
    }
 return $data;  
}

}
?>

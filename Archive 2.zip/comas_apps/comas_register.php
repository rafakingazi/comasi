<?php
$regions=new ComasUserManager();
$break="";
$termsurl="mobi.php?page=49";
if(!$is_mobi){
 $break="<br>"; 
 $termsurl="index.php?page=49";
}
$fileInclude.='<div class="content_box register">
    <h1>New User Registration</h1>
    <form action="'.$_SERVER['PHP_SELF'].'" method="post" data-ajax="false">
    <div>
    <label for="fulname">Fullname:</label>'.$break.'
    <input type="text" name="fullname" id="fulname" placeholder="Firstname Lastname" />
    </div>
    <div class="containing-element" data-role="fieldcontain">
    <fieldset data-role="controlgroup" data-type="horizontal" ><legend>Gender:</legend>
	<input type="radio" name="gender" id="female" value="female" />
        <label for="female">Female</label>
        <input type="radio" name="gender" id="male" value="male" />
        <label for="male">Male</label>
	</fieldset>
</div>
 <div>
<label for="phone">Phonenumber:</label>'.$break.'
    <input type="number" name="phone" id="phone" placeholder="Phonenumber" />
    </div>
     <div>
    <label for="email">Email:</label>'.$break.'
    <input type="email" name="email1" id="email" placeholder="Email" />
    </div>
    <div>
    <label for="pass1">Password:</label>'.$break.'
    <input type="password" name="password1" id="pass1" placeholder="Password" />
    </div>
    <div>
    <label for="pass2">Confirm Password:</label>'.$break.'
    <input type="password" name="confirmpass" id="pass2" placeholder="Password" />
    </div>
    <div>
    <label for="country">Country:</label>'.$break.'
    <select name="country" id="country"><option>Tanzania</option></select>
    </div>
    <div>
    <label for="city" >City:</label>'.$break.'
    <select name="city" id="city">'.$regions->userTanzaniaRegions().'</select>
    </div>
    <div>
    
    <input type="checkbox" name="terms" value="yes" id="agree"/>
    <label for="agree">I agree to COMASI <a href="'.$termsurl.'"> Terms Of Use</a></label>
    
    </div>
     <div>
   <input type="submit" name="save_register" value="Sign Up" />
    </div>
    </form>
</div>';
if(!$is_mobi){
//some image and adverstizmente
}
$fileInclude.='</div>';
?>

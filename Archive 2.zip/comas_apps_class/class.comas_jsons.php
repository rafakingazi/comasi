<?php

class ComasJsons{
    
    function stockItemList($userid,$bizid){
        $database=new ComasDatabase();
        $stockprice=new ComasDatabase();
        $itemlist="";
        $status=$database->selectField("comas_biz_stock", array("*"), "=", "user_bizid",$bizid."' and user_id !='0", "item_name", "asc", "","");
        if($status){
            $itemlist='{"stock":[';
            while($items=$database->getResultSet()){
               $states=$stockprice->selectField("comas_biz_stockprice", array("*"), "=", "item_id",$items['item_id'], "created_date", "desc", "","1"); 
             if($states){
                 $item=$stockprice->getResultSet();
               $itemlist.='{"item":"'.$items['item_name'].'","itemid":"'.$items['item_id'].'","itemunit":"'.$items['item_unit'].'","cost":"'.$item['unitcost'].'","selling":"'.$item['sellingprice'].'","qty":"'.$items['quantity'].'"},'; 
             }
            }
            $itemlist.='{"item":"","itemid":"","itemunit":"","cost":"","selling":"","qty":""}';
            $itemlist.=']}';
        }
        return $itemlist;
    }
    
    /**
     * This method is used to return list of units in json format
     * @return string
     */
    function itemUnit(){
        $database=new ComasDatabase();
        $unitlist="";
        $status=$database->selectField("comas_biz_itemunits", array("*"), "","", "","","", "","");
        if($status){
          $unitlist='{"units":[';
          while($myunit=$database->getResultSet()){
              $unitlist.='{ "unit":"'.$myunit['unit_name'].'","initial":"'.$myunit['unit_initial'].'","cost":"none","sell":"none","id":"none"},';
          }
          $unitlist.='{"unit":"","initial":"","cost":"none","sell":"none","id":"none"}]}';
          
          return $unitlist;
        }
    }
    
  function expenseslist($bizid){
     $database=new ComasDatabase();
     $expense="";
     $status=$database->selectField("comas_biz_expenses", array("distinct expenses"), "=","user_bizid", $bizid,"","", "","");
     if($status){
         $expense='{"expense":[';
         while($myexp=$database->getResultSet()){
          $expense.='{"exp":"'.$myexp['expenses'].'","id":"none","cost":"none","selling":"none","unit":"none"},';   
         }
         $expense.='{"exp":"none","id":"none","cost":"none","selling":"none","unit":"none"}]}';
     }
     return $expense;
  }
}
?>

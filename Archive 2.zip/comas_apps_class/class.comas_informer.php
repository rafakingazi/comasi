<?php


/**
 * This class will hold all important static text/informations like tutorials,notice,errors and warning
 *
 * @author raphaelmartin
 */
class ComasInformer {
//put your code here
    
    function accountExpireText($lang){
        $texts="";
        switch($lang){
            case "eng":
                $texts.="<p> Please Pay your Bill To Continue Assessing Your Records.
                    </p><p><b>Note</b> You can continue store your data in the system.</p>";
                break;
            case "swahili":
                $texts.="<p> Please Pay your Bill To Continue Assessing Your Records.
                    </p><p><b>Note</b> You can continue store your data in the system.</p>";
                break;
        }
    return $texts;
        }
        
   function noRecordsFoundText($lang){
     $texts="";
        switch($lang){
            case "eng":
                $texts.="<p>You Don't Have Records On Those Date</p>";
                break;
            case "swahili":
             $texts.="<p>You Don't Have Records On Those Date</p>";
                break;
        }
    return $texts;  
   }     
    
   
   function getInfo($codeid,$altetext){
       global $infoz;
      return isset($infoz[$codeid])?$infoz[$codeid]:$altetext;
   }
}

?>

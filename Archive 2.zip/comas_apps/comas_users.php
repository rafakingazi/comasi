<?php
$forms=new AdminFormProcess();
$forms->saveNewBusinessUser();
if(isset($_SESSION['comas_previlege'])){
    if($_SESSION['comas_previlege']=="all"){
$fileInclude.="<div class='content_box' ><p>Add New User</p
    ><form action='' method='post' data-ajax='false'>
               <label for='userfulname' >User Firstname</label><br><input type='text' name='usernames' id='userfulname' /><br>
               <label for='userlastname'>Lastname</label><br><input type='text' name='lastname' id='userlastname'/ >
               <br>
               <label>User Email</label><br><input type='text' name='user_email' /><br>
               <label for='userphone'>User Phone</label><br><input type='text' name='user_phone' id='userphone' /><br>
               <label for='usertype'>User Type</label><br><select name='user_type' id='usertype' ><option>admin</option><option>client</option>
               </select><br>
              
               <br>
               <label>User Business</label><br>"; 
$fileInclude.=$forms->selectUserBusiness()."<br> <input type='submit' name='comas_newuser' value='Create User' /></form></div>";
$fileInclude.="<div class='content_box'>".$forms->removeUsers("index.php?page=22&sub=26")."</div>";
$fileInclude.="</div>";
    }else{
      $fileInclude.="<div><p>I am sorry You cannot perform that operation</p></div></div>";   
    }
}else{
 $fileInclude.="<div><p>I am sorry You cannot perform that operation</p></div></div>";   
}
?>

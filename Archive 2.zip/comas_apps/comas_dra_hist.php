
<?php
$expired=  ComasUserManager::isExpired();
$filter=new AdminFormProcess();
$infos=new  ComasInformer();
if(!$expired){
$reports=new ComasReports();
$draws=$reports->drawingHistory();
$_SESSION['report']=$draws;
$fileInclude.="<div class='content_box' >".$filter->comasDateFilter(true);
if($draws!=""){
$fileInclude.="<span style='float:right;'> <a href='../reports/reports.php?report=7' data-ajax='false'>PDF</a></span>";

$fileInclude.=$draws."</div></div>";
}else{
  $fileInclude.="".$infos->noRecordsFoundText("eng")."</div></div>";    
}
}else{
 $fileInclude.="<div>".$infos->accountExpireText("eng")."</div></div>";   
}
?>


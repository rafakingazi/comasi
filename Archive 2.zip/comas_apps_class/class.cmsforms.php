<?php
$base_paths= dirname(dirname(realpath(__FILE__)));
require_once($base_paths."/comas_config/ComasDefined.php");


class AdminFormProcess extends ComasDataResponder{
    private $databaseObj="";
    private $httpResource="";
    
    function AdminFormProcess(){
    $this->databaseObj=new ComasDatabase();
    $this->httpResource=$this->comasRequestProcessor();
    }
    /**
     * This method is used to return an array of all http request to the server
     * @return type
     */
    function getHttpRequest(){
        return $this->comasRequestProcessor();
    }
    
   function saveNewBusiness(){
      $newBiz=$this->httpResource;
        $database=new ComasDatabase();
        $changebiz=new ComasDatabase();
       
        if(isset($newBiz['send_newbiz'])){
          $bizname= ComasDatabase::escapeString(trim($newBiz['newbiz']));
          $biztype= ComasDatabase::escapeString(trim($newBiz['biztype']));
          $bizcate= ComasDatabase::escapeString(trim($newBiz['bizcategory']));
          $bizlocation= ComasDatabase::escapeString(trim($newBiz['bizlocation']));
          $currency= ComasDatabase::escapeString(trim($newBiz['currency']));
          $createdate=@date("Y-m-d H:i:s");
          $userid= $_SESSION['comas_knownas'];
          
          $data_toinsert=array("",$bizname,$biztype,$bizlocation,$bizcate,$currency,$userid,$createdate);
          $status=$database->insertField("comas_user_business", $data_toinsert);
         if($status){
             $isbiz= $changebiz->selectField("comas_user_business", array("biz_type_id","biz_name","user_bizid"), "=","biz_name",$bizname."' and biz_owner_id='".$userid, "user_bizid", "asc", "","1");      
        
     if($isbiz){
         $mybiz=$changebiz->getResultSet();
       $_SESSION['biz_id']=$mybiz['user_bizid']; //identity of given business
       $_SESSION['biz_type']=$mybiz['biz_type_id']; //identity of business type
       $_SESSION['biz_name']=$mybiz['biz_name'];
      echo "<meta http-equiv=Refresh content=0;url=index.php?page=50>";
     }else{
         echo "<meta http-equiv=Refresh content=0;url=index.php>";
     }
    
         } 
        }
        
   }
   
   
   
   
   function saveTranslated(){
      $pageData=$this->httpResource;
        
        if(isset($pageData['create_translate'])){
            $database=new ComasDatabase();
            if(isset($pageData['rtype'])){
            $dates=@date("Y-m-d H:i:s");
          $rtype=  ComasDatabase::escapeString($pageData['rtype']);
          $tables=  ComasDatabase::escapeString($pageData['mypages']);
          $cont_id=  ComasDatabase::escapeString($pageData['mycontent']);
          $mytrans=  ComasDatabase::escapeString($pageData['mytrans']);
           $mylang=  ComasDatabase::escapeString($pageData['mylang']);
            $parts=@explode("@", $tables);
       if(isset($parts[0])){
         $data_to_insert=array("0",$mylang,$parts[0],$cont_id,$mytrans,$rtype,$dates);
         $status=$database->insertField("comas_translator", $data_to_insert);
         if($status){
             
         }
       }
       }
            }
        }
   /**
    * This method is used to save page to the database
    */
    function savePage(){
        $pageData=$this->httpResource;
        $database=new ComasDatabase();
        
        if(isset($pageData['create_newpage'])){
            $times=@date("Y-m-d H:i:s");
            $pagename=  ComasDatabase::escapeString($pageData['page_name']);
            $pagetitle=ComasDatabase::escapeString($pageData['page_title']);
            $pageonwer=ComasDatabase::escapeString($pageData['page_owner']);
            $pageparent=ComasDatabase::escapeString($pageData['page_parent']);
           $pagetype=ComasDatabase::escapeString($pageData['page_type']);
            $pagetemplate=ComasDatabase::escapeString($pageData['template']);
            $description=ComasDatabase::escapeString($pageData['page_decription']);
            $pagesystem=  ComasDatabase::escapeString($pageData['pagesystem']);
            $data_to_insert=array("",$pagename,$pageparent,"0",  $times,$pagetitle,$pageonwer,$pagetemplate,$description,$pagetype,$pagesystem);
            $status=$database->insertField("comas_pages", $data_to_insert);
          if($status){
            //display successful sms  
          }else{
             //display failed sms 
          }
        }
        
    }
    
    
    
  function saveBlocks(){
      $pageData=$this->httpResource;
        $database=new ComasDatabase();
        
        if(isset($pageData['create_newblock'])){
            $times=@date("Y-m-d H:i:s");
            $blockname=  ComasDatabase::escapeString($pageData['block_name']);
            //$pagetitle=ComasDatabase::escapeString($pageData['block_title']);
            //$pageonwer=ComasDatabase::escapeString($pageData['block_type']);
            $blockparent=ComasDatabase::escapeString($pageData['block_parent']);
           $blockowner=ComasDatabase::escapeString($pageData['block_owner']);
            $blocklocation=ComasDatabase::escapeString($pageData['block_location']);
            $blockclass=ComasDatabase::escapeString($pageData['block_class']);
            $extra=ComasDatabase::escapeString($pageData['extra_attr']);
             $blockid=ComasDatabase::escapeString($pageData['block_id']);
              $blockorder=ComasDatabase::escapeString($pageData['blockorder']);
             
            $data_to_insert=array("0",  $blockowner,$blockparent,$blockname,$times,$blocklocation,$blockorder,'normal',$blockclass,$blockid,$extra,$times);
            $status=$database->insertField("comas_blocks", $data_to_insert);
          if($status){
            //display successful sms  
          }else{
             //display failed sms 
              echo "<script>
                  alert('error occured');</script>";
          }
        }
         
  }
  
  function saveForm(){
     $pageData=$this->httpResource;
        $database=new ComasDatabase();
        
        if(isset($pageData['create_newform'])){
            $times=@date("Y-m-d H:i:s");
            $formname=  ComasDatabase::escapeString($pageData['form_name']);
            $formtitle=ComasDatabase::escapeString($pageData['form_title']);
           $formalign=ComasDatabase::escapeString($pageData['form_align']);
          $formparent=ComasDatabase::escapeString($pageData['form_parent']);
           $formmethod=ComasDatabase::escapeString($pageData['form_method']);
            $formaction=ComasDatabase::escapeString($pageData['form_action']);
            $formclass=ComasDatabase::escapeString($pageData['form_class']);
             $formid=ComasDatabase::escapeString($pageData['form_id']);
             $blockid=$_SESSION['block_id'];
            $data_to_insert=array("0",  $blockid,$formparent,$formtitle,$formname,$formaction,$formmethod,$formclass,$formid,$formalign,$times,$times);
            $status=$database->insertField("comas_form", $data_to_insert);
          if($status){
            //display successful sms  
          }else{
             //display failed sms 
              echo "<script>
                  alert('error occured');</script>";
          }
        }
          
  }
  
  function saveFormElement(){
      
      $pageData=$this->httpResource;
        $database=new ComasDatabase();
        
        if(isset($pageData['create_newelement'])){
            $times=@date("Y-m-d H:i:s");
            $formname=  ComasDatabase::escapeString($pageData['form_name']);
            $elementtitle=ComasDatabase::escapeString($pageData['element_title']);
            $elementnameattr=ComasDatabase::escapeString($pageData['element_nameattr']);
           $elementtag=ComasDatabase::escapeString($pageData['element_tag']);
            $elementtype=ComasDatabase::escapeString($pageData['element_type']);
            $elementclass=ComasDatabase::escapeString($pageData['element_classattr']);
             $elementid=ComasDatabase::escapeString($pageData['element_idattr']);
              $elementvalue=ComasDatabase::escapeString($pageData['element_value']);
               $elementstatus=ComasDatabase::escapeString($pageData['element_status']);
               $elementorder=ComasDatabase::escapeString($pageData['element_order']);
            
            $data_to_insert=array("0",  $formname,$elementtag,$elementtitle,$elementnameattr,$elementtype,$elementclass,$elementid,$elementvalue,$elementstatus,$times,$times,$elementorder);
            $status=$database->insertField("comas_form_elements", $data_to_insert);
          if($status){
            //display successful sms  
          }else{
             //display failed sms 
              echo "<script>
                  alert('error occured');</script>";
          }
        }
      
  }
  
  
  function updateBlock(){
    $pageData=$this->httpResource;
        $database=new ComasDatabase();
          $times=@date("Y-m-d H:i:s");
        if(isset($pageData['update_block'])){
         $id=  ComasDatabase::escapeString($pageData['block_id']);
         $b_title= ComasDatabase::escapeString($pageData['block_name']);
         $b_clasat= ComasDatabase::escapeString($pageData['b_classat']);
         $b_idat= ComasDatabase::escapeString($pageData['b_idat']);
         $b_extra= ComasDatabase::escapeString($pageData['b_extra']);
         if($id>0){
         $dataupdate=array("block_name"=>$b_title,"block_class_attr"=>$b_clasat,"block_id_attr"=>$b_idat,"b_extra"=>$b_extra,"block_edate"=>$times);
         $status=$database->updateField("comas_blocks", $dataupdate,"block_id",$id);
         if($status){
             //success updated
         }
         }
        }   
  }
  /**
   * 
   */
  function saveBlockContent(){
    
      $pageData=$this->httpResource;
        $database=new ComasDatabase();
        
        if(isset($pageData['create_newcontent'])){
            $times=@date("Y-m-d H:i:s");
           
            $content_title=ComasDatabase::escapeString($pageData['content_title']);
            $content_body=ComasDatabase::escapeString($pageData['content_body']);
           $blockid=ComasDatabase::escapeString($_SESSION['block_id']);
            $data_to_insert=array("0",$content_title,$content_body,$blockid,$times,$times);
            $status=$database->insertField("comas_pagecontent", $data_to_insert);
          if($status){
            //display successful sms  
          }else{
             //display failed sms 
              echo "<script>
                  alert('error occured');</script>";
          }
        }   
  }
  
  function viewBlockContent($page_url){
       $pageData=$this->httpResource;
        $database=new ComasDatabase();
        $view='';
    if(isset($pageData['view_content'])){
        $blockid=  ComasDatabase::escapeString($pageData['block_id']);
        $status=$database->selectField("comas_pagecontent",array("content_id,content_title,content_body,content_cdate,content_edate"),"=","block_id", $blockid,"", "","","");
        if($status){
            $view.='<table class="comasadmin_table"><tr><td></td><td>Content Title</td><td>Content Body</td><td>Date Created</td><td>Date Modified</td><td>Action</td></tr>';
            $i=1;
            while($cont=$database->getResultSet()){
                $content= strip_tags(substr($cont['content_body'], 0, 100));
            $view.='<tr><td>'.$i.'</td><td>'.strip_tags($cont['content_title']).'</td><td>'.$content.'</td><td>'.$cont['content_cdate'].'</td><td>'.$cont['content_edate'].'</td>
                     <td><form action="'.$page_url.'" method="post" >
                     <input type="hidden" name="contentid" value="'.$cont['content_id'].'"/>
                     <input type="hidden" name="content_t" value="'.$cont['content_title'].'"/>
                     <textarea name="content_b" hidden>'.$cont['content_body'].'</textarea>
                     <input type="submit" name="editcontent" value="Edit" />
                     <input type="submit" name="deletecontent" value="Remove" />
                     </form></td>
                       </tr>';
           $i++;
            }
            $view.='</table>';
        }
    }
    $this->deleteContent();
   $view.= $this->editContent($page_url);
    return $view;
  }
  
  function deleteContent(){
    $pageData=$this->httpResource;
        $database=new ComasDatabase();
        $database1=new ComasDatabase();
       
    if(isset($pageData['deletecontent'])){
     $id=  ComasDatabase::escapeString($pageData['contentid']);
     if($id!="" && $id>0){
       $state=$database->deleteField("comas_translator", "content_id",$id."' and source_tablename='comas_pagecontent"); 
       if($state){
        $states=$database1->deleteField("comas_pagecontent", "content_id",$id);
        if($states){
            //echo success
        }
       }else{
        $states=$database1->deleteField("comas_pagecontent", "content_id",$id);
        if($states){
            //echo success
        }   
       }
     }
    }  
  }
  
  function editContent($page_url){
     $pageData=$this->httpResource;
        $database=new ComasDatabase();
      $editor='';  
       
    if(isset($pageData['editcontent'])){ 
      $title=$pageData['content_t'];
      $body= $pageData['content_b'];
     $id=  ComasDatabase::escapeString($pageData['contentid']);
     $editor.='<hr><h2>Update Content</h2>
         <form action="'.$page_url.'" method="post" >
             <input type="hidden" name="c_id" value="'.$id.'" />
         <label> Content Title</label><br><input type="text" name="ctitle" value="'.$title.'"/><br>
             <label>Content Body</label><br/><p><textarea name="cbody" id="econtent" >'.$body.'</textarea>
                  <script> CKEDITOR.replace( "econtent",
	{
		extraPlugins : "devtools"
	,filebrowserBrowseUrl :"../comas_plugin/filemanager/browser/default/browser.html?Connector=../comas_plugin/filemanager/connectors/php/connector.php",
                    filebrowserImageBrowseUrl : "../comas_plugin/filemanager/browser/default/browser.html?Type=Image&Connector=../comas_plugin/filemanager/connectors/php/connector.php",
                    filebrowserFlashBrowseUrl :"../comas_plugin/filemanager/browser/default/browser.html?Type=Flash&Connector=../comas_plugin/filemanager/connectors/php/connector.php",
					filebrowserUploadUrl  :"../comas_plugin/filemanager/connectors/php/upload.php?Type=File",
					filebrowserImageUploadUrl : "../comas_plugin/filemanager/connectors/php/upload.php?Type=Image",
					filebrowserFlashUploadUrl : "../comas_plugin/filemanager/connectors/php/upload.php?Type=Flash"});</script></p>
                 <br>
                 <input type="submit" name="updatecontent" value="save" /></form>';
    } 
    
    if(isset($pageData['updatecontent'])){
        $id=  ComasDatabase::escapeString($pageData['c_id']);
        $title=  ComasDatabase::escapeString($pageData['ctitle']);
        $body=  ComasDatabase::escapeString($pageData['cbody']);
        $dataupdate=array("content_title"=>$title,"content_body"=>$body);
        $status=$database->updateField("comas_pagecontent", $dataupdate, "content_id", $id);
        if($status){
            
        }
    }
    return $editor;
  }
  
 function saveExternalFileInfo(){
     $fileData=$this->httpResource;
     $database=new ComasDatabase(); 
    if(isset($fileData['save_file'])){
     $filename=  ComasDatabase::escapeString($fileData['file_name']);
     $file_dir=ComasDatabase::escapeString($fileData['file_dir']); 
     $file_path=ComasDatabase::escapeString($fileData['file_path']);
     $file_type=ComasDatabase::escapeString($fileData['file_type']);
     $block_id=  ComasDatabase::escapeString($fileData['block_id']);
     $times=@date("Y-m-d H:i:s");
     $data_input=array('',$filename,$file_dir,$file_path,$file_type,$block_id,$times);
     $status=$database->insertField("comas_includes", $data_input);
     if($status){
         
     }else{
         
     }
    }
 }
  /**
   * save the created reports
   */
  function saveNewReport(){
     $reportData=$this->httpResource;
        $database=new ComasDatabase();
        if(isset($reportData['create_newreport'])){
           $reportTitle=ComasDatabase::escapeString($reportData['report_title']) ;
           $reportparent=ComasDatabase::escapeString($reportData['report_parent']);
           $blockid=ComasDatabase::escapeString($reportData['block_id']);
           $reportname=ComasDatabase::escapeString($reportData['report_name']);
           $reportTable=ComasDatabase::escapeString($reportData['report_table']);
            $times=@date("Y-m-d H:i:s");
            $data_to_insert=array("",$blockid,$reportparent,$reportTable,$reportname,$reportTitle,$times);
           $status= $database->insertField("comas_reports", $data_to_insert);
            if($status){
                
            }else{
                
            }
         
        } 
  }
  

  
  function saveReportItems(){
      $reportData=$this->httpResource;
        $database=new ComasDatabase();
        if(isset($reportData['create_report'])){
            $reportid=ComasDatabase::escapeString($reportData['report_id']);
           $special=$reportData['special'] ;
           $tablecol=$reportData['tablecol'];
           $headercol=$reportData['headercol'];
            $times=@date("Y-m-d H:i:s");
           $len=count($special);
          for($i=0; $i<$len; $i++){
              $rsp=ComasDatabase::escapeString($special[$i]);
              $tcol=ComasDatabase::escapeString($tablecol[$i]);
              $hcol=  ComasDatabase::escapeString($headercol[$i]);
          $data_to_insert=array("",$reportid,$tcol,$hcol,$rsp,$times);
          $database->insertField("comas_reportcols", $data_to_insert);
          }
        }
  }
    /**
     * This method is used to return select option for all pages already created in the database none
     *  means 0 or top pages
     * @return string
     */
    
    function selectPage($pageid){
        $pageslist="";
        $database=new ComasDatabase();
        if($pageid!=''||$pageid!=null){
        $database->selectField("comas_pages", array('page_id','page_name'), "=", "page_id",$pageid, "", "", "", "");
        }else{
         $database->selectField("comas_pages", array('page_id','page_name'), "", "","", "", "", "", "");   
        }
        while($pageParent=$database->getResultSet()){
         $pageslist.= "<option value='".$pageParent['page_id']."' >".$pageParent['page_name']."</option>";  
        }
        return $pageslist;
    }
    
    
    /**
     * This method is used to select list of blocks for selective options
     * @return string
     */
   function selectBlock($pageId){
       $blocklist="";
       $database=new ComasDatabase();
       $database->selectField("comas_blocks", array('block_id','block_name'), "=", "page_id",$pageId, "", "", "", "");
       while($blockParent=$database->getResultSet()){
        $blocklist.= "<option value='".$blockParent['block_id']."' >".$blockParent['block_name']."</option>";    
       }
       return $blocklist;
   }
   
   /**
    * This method is used to select list of forms for selective options;
    * @return string
    */
   function selectForm($block_id){
       $formlist="";
       $database=new ComasDatabase();
       $database->selectField("comas_form", array('form_id','form_title'), "=", "block_id",$block_id, "", "", "", "");
       while($form=$database->getResultSet()){
        $formlist.= "<option value='".$form['form_id']."' >".$form['form_title']."</option>";    
       }
       return $formlist;
   }
   
   
   /**
    * This method is used to return the list of reports heading submited
    * @param type $block_id
    * @return string
    */
   function selectReport($block_id){
      $formlist="";
       $database=new ComasDatabase();
       $database->selectField("comas_reports", array('report_id','report_title'), "=", "block_id",$block_id, "", "", "", "");
       while($form=$database->getResultSet()){
        $formlist.= "<option value='".$form['report_id']."' >".$form['report_title']."</option>";    
       }
       return $formlist; 
   }
  
 
   /**
    * This method is used to save new added system name in the database
    * need to be improved is for the start
    */
   
   function saveNewSystem(){
       $newSystem=$this->httpResource;
        $database=new ComasDatabase();
      if(isset($newSystem['newcomas_biz'])){
         $bizname=  ComasDatabase::escapeString(trim($newSystem['system_name']));
         $bizcategory=ComasDatabase::escapeString(trim($newSystem['system_category']));
         $dates=@date("Y-m-d H:i:s");
         $data=array("",$bizname,$bizcategory,$dates);
         $database->insertField("comas_businesslist", $data);
      }
   }
  
 function saveSystemPages(){
   $systempage=$this->httpResource;
        $database=new ComasDatabase();
      if(isset($systempage['comas_setsystem'])){
         $bizname=  ComasDatabase::escapeString(trim($systempage['mypage']));
         $bizsystem=ComasDatabase::escapeString(trim($systempage['mysystem']));
     
         $data=array("",$bizname,$bizsystem);
         $status=$database->insertField("comas_systempage", $data);
         if($status){
            $database->updateField("comas_pages",array("pagesystem"=>$bizsystem),"page_id", $bizname); 
         }
      }  
 }
 
 function selectBusiness(){
    $business=$this->httpResource;
    $database=new ComasDatabase();
  
    if(isset($business['select_biz'])){
      
        $_SESSION['comas_bizid']=$business['selectbiz'];
        
     if(isset($_SESSION['comas_bizid'])){

     $isbiz= $database->selectField("comas_user_business", array("biz_type_id","biz_name","user_bizid"),"=", "user_bizid",$_SESSION['comas_bizid'], "", "", "",""); 
        
     
        }else{
          
       $isbiz= $database->selectField("comas_user_business", array("biz_type_id","biz_name","user_bizid"), "","", "", "user_bizid", "asc", "","1");      
        }
     if($isbiz){
         $mybiz=$database->getResultSet();
       $_SESSION['biz_id']=$mybiz['user_bizid']; //identity of given business
       $_SESSION['biz_type']=$mybiz['biz_type_id']; //identity of business type
       $_SESSION['biz_name']=$mybiz['biz_name'];
      
     }
    
    
    }
    
 }
 
 /**
  * This method is used to add user to the given business
  */
 function saveNewBusinessUser(){
   $newuser=$this->httpResource;
    $database=new ComasDatabase();
$userid=$_SESSION['comas_knownas'];
   if(isset($newuser['comas_newuser']) && $_SESSION['comas_previlege']=='all'){
    $username=  ComasDatabase::escapeString(trim($newuser['usernames']));
    $email=  ComasDatabase::escapeString(trim($newuser['user_email']));
    $phone=ComasDatabase::escapeString(trim($newuser['user_phone']));
    $usertype=ComasDatabase::escapeString(trim($newuser['user_type']));
     $lastname=ComasDatabase::escapeString(trim($newuser['lastname']));
      $statuz="1";
       $tokens=ComasDatabase::escapeString(trim("345600"));
    $password=md5($email);
    $bizname=$newuser['mybiz'];
    $date=@date("Y-m-d H:i:s");
    $count=count($bizname);
    $userbiz="";
    $last=$count-1;
    for($i=0; $i<$count; $i++){
        if(isset($bizname[$i])){
          if($last==$i){
           $userbiz.=$bizname[$i];
          }else{
             $userbiz.=$bizname[$i].",";  
          }  
        }else{
            $count=$count+1;
            $last=$count-1;
        }
    }
    $data_to_insert=array("",$username,$lastname,$email,$phone,$password,$usertype,$userbiz,$tokens,$statuz,$userid,"1",$date);
    $status=$database->insertField("comas_user_main_account", $data_to_insert);
    if($status){
        echo "<script> alert('success') </script>";
    }
   }
 }
 
function removeUsers($urls){
    $userid=$_SESSION['comas_knownas'];
    $database=new ComasDatabase();
    $database1=new ComasDatabase();
    $database3=new ComasDatabase();
    $count=0;
    $usedata="";
    $buttons="";
    $data=$_POST;
    if(isset($data['deactivate'])){
       $id=  ComasDatabase::escapeString($data['myusers']);
       if($id>0){
        $dataupdate=array("status"=>2);
        $states=$database3->updateField("comas_user_main_account", $dataupdate,"user_id",$id);
        if($states){
            //success
        }
       }
    }
    if(isset($data['activate'])){
      $id=  ComasDatabase::escapeString($data['myusers']);
       if($id>0){
        $dataupdate=array("status"=>1);
        $states=$database3->updateField("comas_user_main_account", $dataupdate,"user_id",$id);
        if($states){
            //success
        } 
       }
    }
    if(isset($data['remove_users'])){
  $id=  ComasDatabase::escapeString($data['myusers']);
       if($id>0){
        $dataupdate=array("status"=>2);
        $states=$database3->deleteField("comas_user_main_account","user_id", $id);
        if($states){
            //success
        }  
       }
    }
    if($userid>0){
      $status=$database->selectField("comas_user_main_account",array("user_id,user_fullname,lastname,user_email,user_phone_no,status"),"=","parent_id",$userid,"","","",""); 
      if($status){
          $i=1;
       $usedata.="<table><caption>System Users</caption><tr class='even_row'><td>Sno</td><td>Names</td><td>Email</td><td>Phone Number</td><td>Action</td></tr>";
       while($users=$database->getResultSet()){
           $userstate=$users['status'];
           $iduser=$users['user_id'];
       $count=$database1->countrows("comas_biz_cash","=","user_id", $iduser); 
       if($count==0){
           if($userstate==1){
        $buttons="<input type='submit' name='deactivate' value='Deactivate' /> <input type='submit' name='remove_users' value='Delete' />";
           }else{
         $buttons="<input type='submit' name='activate' value='Activate' /> <input type='submit' name='remove_users' value='Delete' />";      
           }
       }else if($count>0){
       if($userstate==1){
        $buttons="<input type='submit' name='deactivate' value='Deactivate' />";
           }else{
         $buttons="<input type='submit' name='activate' value='Activate' />";      
           }    
       }
       if($i%2==0){
      $usedata.="<tr class='even_row' >";     
       }else{
      $usedata.="<tr class='odd_row' >";     
       }
       $usedata.="<td>".$i."</td><td>".$users['user_fullname']." ".$users['lastname']."</td><td>".$users['user_email']."</td><td>".$users['user_phone_no']."</td>";
       $usedata.="<td><form action='".$urls."' method='post'><input type='hidden' name='myusers' value='".$iduser."' />".$buttons."</form></td></tr>";
       
       $i++;
       }
       $usedata.="</table>";
      }
    }
    
    
    return $usedata;
}
 
 /**
  * This method is used to for adding new user to the given business in the system
  * 
  * @return string
  */
 function selectUserBusiness(){
   $database=new ComasDatabase();
   $mybiz="";
   if(isset( $_SESSION['comas_knownas'])){
       $userid= $_SESSION['comas_knownas'];
   $isbiz=$database->selectField("comas_user_business", array("biz_type_id","biz_name","user_bizid"), "=","biz_owner_id",$userid, "user_bizid", "asc", "","");
   if($isbiz){
       $i=0;
     while($biz=$database->getResultSet()){
         $mybiz.="<input type='checkbox' name='mybiz[".$i."]' value='".$biz['user_bizid']."' id='mybiz".$i."' /><label for='mybiz".$i."' >".$biz['biz_name']."</label><br>";
         
       $i++;
          }  
   }
   }
   return $mybiz;
 }

 
 function selectDebtor(){
   $bizid=$_SESSION['biz_id'];
 $database=new ComasDatabase();
   $mybiz="";
   $isbiz=$database->selectField("comas_biz_debtors", array("debtor_id,debtor_fulname,debtor_email"), "=","user_bizid", $bizid, "", "", "","");
   if($isbiz){
       $mybiz.="<form action='' method='post'><select name='comas_debt' class='debt_list'><option>Select Debtor</option>"; 
   while($rects=$database->getResultSet()){
     $mybiz.="<option value='".$rects['debtor_id']."'>".$rects['debtor_fulname']."::".$rects['debtor_id']."</option>";  
   }
   $mybiz.="</select></form>";
   }else{
       $mybiz.="<select><option>No Debtor Found</option></select>";
   }
   return $mybiz;
 }
 
 function selectCreditor(){
   $bizid=$_SESSION['biz_id'];
 $database=new ComasDatabase();
   $mybiz="";
   $isbiz=$database->selectField("comas_biz_creditors", array("creditors_id,creditors_fulname,creditors_email"), "=","user_bizid", $bizid, "", "", "","");
   if($isbiz){
       $mybiz.="<form action='' method='post'><select name='comas_debt' class='debt_list'><option>Select Creditor</option>"; 
   while($rects=$database->getResultSet()){
     $mybiz.="<option value='".$rects['creditors_id']."'>".$rects['creditors_fulname']."::".$rects['creditors_id']."</option>";  
   }
   $mybiz.="</select></form>";
   }else{
       $mybiz.="<select><option>No Creditor Found</option></select>";
   }
   return $mybiz;
 }
 
 function updateSellingPrice(){
     $produ=$this->httpResource;
   $database=new ComasDatabase();
   if(isset($produ['update_selling'])){
     $new_price=  ComasDatabase::escapeString($produ['sell_price']);
     $create_dt=  ComasDatabase::escapeString($produ['create_dt']);
     $itemid=  ComasDatabase::escapeString($produ['itemid']);
      $state=$database->updateField("comas_biz_stockprice", array("sellingprice"=>$new_price), "item_id", $itemid."' and created_date='".$create_dt);
            if($state){
          
            }
   }
   if(isset($produ['select_prod'])){
  $bizid=$_SESSION['biz_id'];
  $item_id=$produ['comas_prod'];
        $stockprice=new ComasDatabase();
        $itemlist="";
        $status=$database->selectField("comas_biz_stock", array("*"), "=", "user_bizid",$bizid."' and user_id !='0' and item_id='".$item_id, "item_name", "asc", "","");
        if($status){
            $itemlist="<form action='' method='post' >";
            while($items=$database->getResultSet()){
               $states=$stockprice->selectField("comas_biz_stockprice", array("*"), "=", "item_id",$items['item_id'], "created_date", "desc", "","1"); 
             if($states){
                 $item=$stockprice->getResultSet();
               $itemlist.="<div><label>Product Name</label><input type='text' value='".$items['item_name']."' disabled/></div>"; 
               $itemlist.="<div><label>Selling Price</label>&nbsp&nbsp&nbsp<input type='text' name='sell_price' value='".$item['sellingprice']."' /></div>"; 
              $itemlist.="<div><input type='hidden' value='".$item['created_date']."' name='create_dt' /><input type='hidden' name='itemid' value='".$items['item_id']."' /></div>";
             }
            }
            $itemlist.="<div><input type='submit' name='update_selling' value='Update Price' /></div></form>";
       
        }
        return $itemlist;     
   }
     
 }
 
 function selectPrice(){

   $mybiz="";
      $mybiz.="<form action='' method='post' data-ajax='false'><select name='comas_prod' class='prod_list'><option>Select Product</option>"; 
      $mybiz.=$this->itemOptionList();
      $mybiz.="</select><input type='submit' name='select_prod' value='Go' /></form>";
   
   return $mybiz;   
 }
 
 function itemOptionList(){
   $bizid=$_SESSION['biz_id'];
 $database=new ComasDatabase();
   $mybiz="";
   $isbiz=$database->selectField("comas_biz_stock", array("item_id,item_name"), "=","user_bizid", $bizid, "", "", "","");
   if($isbiz){ 
   while($rects=$database->getResultSet()){
     $mybiz.="<option value='".$rects['item_id']."'>".$rects['item_name']."</option>";  
   }
   
   }else{
       $mybiz.="<option>No Debtor Found</option>";
   }
   return $mybiz;  
 }
 function selectProduct(){
     $bizid=$_SESSION['biz_id'];
     $results="";
     $product=new ComasDatabase();
     $status=$product->selectField("comas_biz_stock", array("item_id,item_name"),"=","user_bizid", $bizid,"item_name","asc","","");
     if($status){
       $results.="<option value='none'>Select Item</option>
           <option value='none'>All</option>
           ";
     while($prod=$product->getResultSet()){
       $results.="<option value='".$prod['item_id']."'>".$prod['item_name']."</option>";  
     }
     }else{
      $results.="<option value='none'>No Item Found</option>";   
     }
     return $results;
 }
 function comasDateFilter($hasproduct){
     $forms="";
     $forms.="<div data-role='collapsible'>
         <h3 class='hide'>Data filter</h3><table><tr><td>
         <p>Filter Data</option>
         <form action='' method='post' data-ajax='false' >";
     if($hasproduct){
     $forms.="<label for='itemid' >Item Name</label><select name='itemid' id='itemid' >";
     $forms.=$this->selectProduct();
      $forms.="</select>";
     }
         
    $forms.="<label for='monthfil'>In Terms</label><select name='interms' id='interms'>
         ".(isset($_SESSION['fil_terms'])?"<option value='".$_SESSION['fil_terms']."'>".$_SESSION['fil_terms']."</option>":"")."
         <option value='0'>Select Term</option>
         <option value='all'>All</option>
         <option value='weekly'>Weekly</option>
         <option value='monthly'>Monthly</option>
         <option value='yearly'>Yearly</option></select>
         <label for='date2'>From</label><input type='date' class='datepicker' name='filterfrom' value='".(isset($_SESSION['raw_from'])?$_SESSION['raw_from']:"")."'/>
         <label for='date1' >To</label><input type='date' class='datepicker' name='filterto' value='".(isset($_SESSION['raw_to'])?$_SESSION['raw_to']:"")."' />
         <input type='submit' name='filterdate'  value='Go'/>
         </form></td></tr></table></div>";
     return $forms;
 }
 
 function productFilter(){
     
 }
 
 function updateMails(){
   $mConfig=$this->httpResource; 
    $database=new ComasDatabase();
    if(isset($mConfig['update_emails'])){
      $ids=  ComasDatabase::escapeString($mConfig['idz']); 
      $subject=ComasDatabase::escapeString($mConfig['emails']); 
      $head=ComasDatabase::escapeString($mConfig['eheader']); 
      $body=ComasDatabase::escapeString($mConfig['ebody']); 
      $footer=ComasDatabase::escapeString($mConfig['efooter']); 
      $egreat=ComasDatabase::escapeString($mConfig['egreating']); 
      $esign=ComasDatabase::escapeString($mConfig['esign']); 
      
      if($ids>0){
      $toupdate=array("email_subject"=>$subject,"email_body"=>$body,"email_head"=>$head,"email_footer"=>$footer,"email_greating"=>$egreat,"email_sign"=>$esign);
      $database->updateField("comas_emails", $toupdate,"email_id", $ids);
      }
    }  
 }
 function saveNewMails(){
   $mConfig=$this->httpResource; 
    $database=new ComasDatabase();
    if(isset($mConfig['create_emails'])){
      $type=  ComasDatabase::escapeString($mConfig['ecate']); 
      $subject=ComasDatabase::escapeString($mConfig['emails']); 
      $head=ComasDatabase::escapeString($mConfig['eheader']); 
      $body=ComasDatabase::escapeString($mConfig['ebody']); 
      $footer=ComasDatabase::escapeString($mConfig['efooter']); 
      $egreat=ComasDatabase::escapeString($mConfig['egreating']); 
      $esign=ComasDatabase::escapeString($mConfig['esign']); 
      
      $toupdate=array("",$subject,$body,$head,$footer,$type,$egreat,$esign);
      $database->insertField("comas_emails", $toupdate);
      
    }    
 }
 /**
  * This method is used to config the given mailer sender
  */
 function saveMailUpdate(){
    $mConfig=$this->httpResource; 
    $database=new ComasDatabase();
    if(isset($mConfig['update_esender'])){
      $ids=  ComasDatabase::escapeString($mConfig['ids']); 
      $user=ComasDatabase::escapeString($mConfig['emails']); 
      $pass=ComasDatabase::escapeString($mConfig['pass']); 
      $efrom=ComasDatabase::escapeString($mConfig['efrom']); 
      $ename=ComasDatabase::escapeString($mConfig['efromname']); 
      $ereply=ComasDatabase::escapeString($mConfig['replymail']); 
      $ername=ComasDatabase::escapeString($mConfig['replyname']); 
      $host=ComasDatabase::escapeString($mConfig['hostname']); 
      $port=ComasDatabase::escapeString($mConfig['mport']); 
      $ssl=ComasDatabase::escapeString($mConfig['essl']); 
      if($ids>0){
      $toupdate=array("m_email"=>$user,"m_password"=>$pass,"m_fromemail"=>$efrom,"m_fromname"=>$ename,"m_replyemail"=>$ereply,"m_replyname"=>$ername,"m_hostname"=>$host,"m_port"=>$port,"m_ssl"=>$ssl);
      $database->updateField("mailConfig", $toupdate,"indexed", $ids);
      }
    }
 }
 
 function saveNewMailer(){
   $mConfig=$this->httpResource; 
    $database=new ComasDatabase();
    if(isset($mConfig['create_esender'])){
      
      $cate=  ComasDatabase::escapeString($mConfig['ecate']); 
      $user=ComasDatabase::escapeString($mConfig['emails']); 
      $pass=ComasDatabase::escapeString($mConfig['pass']); 
      $efrom=ComasDatabase::escapeString($mConfig['efrom']); 
      $ename=ComasDatabase::escapeString($mConfig['efromname']); 
      $ereply=ComasDatabase::escapeString($mConfig['replymail']); 
      $ername=ComasDatabase::escapeString($mConfig['replyname']); 
      $host=ComasDatabase::escapeString($mConfig['hostname']); 
      $port=ComasDatabase::escapeString($mConfig['mport']); 
      $ssl=ComasDatabase::escapeString($mConfig['essl']); 
   
      $toupdate=array("",$user,$pass,$efrom,$ename,$ereply,$ername,$host,$port,$ssl,$cate);
      
     $database->insertField("mailConfig", $toupdate);
    }   
 }
 /**
  * This function is used to translate given content to another language
  * @param type $tablename
  * @param type $sourceid
  * @param type $lang
  * @return string
  */
 function comasTranslator($tablename,$sourceid,$lang){
     $langs="";
     if(isset($_SESSION['clang'])){
       $langs=$_SESSION['clang'];
     }else{
      $langs=$lang;  
     }
     $transla=new ComasDatabase();
     $content="";
     $trans=$transla->selectField("comas_translator", array('trans_content'), "=","source_tablename", $tablename."' and content_id='".$sourceid."' and lang='".$langs, "", "", "", "");    
       if($trans){
         $mylang=$transla->getResultSet();
         $content=$mylang['trans_content'];
       }else{
         $content="";  
       }
   return $content;
 }
 
}
?>

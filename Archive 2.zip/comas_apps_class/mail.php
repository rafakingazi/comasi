<?php
require_once (COMASPATH_BASE.'/comas_plugin/PHPMailer/class.phpmailer.php');
 //require_once('../PHPMailer/class.phpmailer.php');
//require_once 'database_common.php';
class MailProcessor{
var $ssl;
var $mailhost;
var $mailport;
var $username;
var $mailpassword;
var $fromemail;
var $fromname;
var $replytoemail;
var $replytoname;
	public function __construct($type){
		$datas=new ComasDatabase();
	
		$result=$datas->selectField("mailConfig",array("*"),"=","stype",$type,"","","","");
if($result){
	$configmail=@mysql_fetch_array($result);
	$this->mailhost=$configmail['m_hostname'];
	$this->username=$configmail['m_email'];
	$this->mailport=$configmail['m_port'];
	$this->ssl=$configmail['m_ssl'];
	$this->mailpassword=$configmail['m_password'];
	$this->fromname=$configmail['m_fromname'];
	$this->fromemail=$configmail['m_fromemail'];
	$this->replytoname=$configmail['m_replyname'];
	$this->replytoemail=$configmail['m_replyemail'];

}

	}
public function autoMail($names,$email,$subject,$message){
 //for html embeding. <<<SMS SMS;
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch

$mail->IsSMTP(); // telling the class to use SMTP

try {
 /// $mail->Host= $this->smt; // SMTP server
 //$mail->SMTPDebug  = 2;                     // enables SMTP debug information (for testing)
  $mail->SMTPAuth   = true;                  // enable SMTP authentication
 $mail->SMTPSecure = $this->ssl;                 // sets the prefix to the servier
  $mail->Host  =$this->mailhost;      // sets GMAIL as the SMTP server
  $mail->Port  = $this->mailport;                   // set the SMTP port for the GMAIL server
  $mail->Username  = $this->username;  // GMAIL username
  $mail->Password  = $this->mailpassword;            // GMAIL password
  $mail->AddAddress($email, $names);
  $mail->SetFrom($this->fromemail, $this->fromname);
  $mail->AddReplyTo($this->replytoemail, $this->replytoname);
  $mail->Subject = $subject;
  $mail->MsgHTML($message);

  if($mail->Send()){

  return true;
  }else{

  return false;
  }
} catch (phpmailerException $e) {
	//return true;
//echo "<script> alert('".$e->errorMessage()."' ) </script>"; //Pretty error messages from PHPMailer
} catch (Exception $e) {
	//return true;
// echo "<script> alert('".$e->getMessage()."' ) </script>"; //Boring error messages from anything else!
}
}


function sendMails($names,$subject,$message,$useremail,$username){
 //for html embeding. <<<SMS SMS;
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch

$mail->IsSMTP(); // telling the class to use SMTP

try {
 /// $mail->Host= $this->smt; // SMTP server
 //$mail->SMTPDebug  = 2;                     // enables SMTP debug information (for testing)
  $mail->SMTPAuth   = true;                  // enable SMTP authentication
 $mail->SMTPSecure = $this->ssl;                 // sets the prefix to the servier
  $mail->Host  =$this->mailhost;      // sets GMAIL as the SMTP server
  $mail->Port  = $this->mailport;                   // set the SMTP port for the GMAIL server
  $mail->Username  = $this->username;  // GMAIL username
  $mail->Password  = $this->mailpassword;            // GMAIL password
  $mail->AddAddress($this->fromemail,$names);
  $mail->SetFrom($useremail, $username);
  $mail->AddReplyTo($useremail, $username);
  $mail->Subject = $subject;
  $mail->MsgHTML($message);

  if($mail->Send()){

  return true;
  }else{

  return false;
  }
} catch (phpmailerException $e) {
	//return true;
//echo "<script> alert('".$e->errorMessage()."' ) </script>"; //Pretty error messages from PHPMailer
} catch (Exception $e) {
	//return true;
 //echo "<script> alert('".$e->getMessage()."' ) </script>"; //Boring error messages from anything else!
}    
}
}

?>
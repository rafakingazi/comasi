<?php
$forms=new AdminFormProcess();
$biz=new AdminForms();
$canadd=  ComasUserManager::canAddBussiness();
$forms->saveNewBusiness();
if(isset($_SESSION['comas_previlege'])){
    if($_SESSION['comas_previlege']=="all"){
        if($canadd){
$fileInclude.="<div class='content_box'><p>Add New Business</p>
    <form action='' method='post' data-ajax='false' >
    <label for=''>Business Name</label><br><input type='text' name='newbiz' id='newbiz'/>
    <br><label for=''>Business Type</label><br><select name='biztype' id='biztype' >";
$fileInclude.=$biz->selectSystem();
$fileInclude.="</select><br><label for='' >Business Category</label><br><select name='bizcategory'>
    <option>Wholesale</option><option>retail</option></select>
    <br><label for=''>Business Location</label><br><input type='text' name='bizlocation' />
    <br><label for=''>Currency</label><br><select name='currency'><option>TSHS</option><option>KSHS</option>
    <option>USHS</option><option>USD</option><option>EURO</option></select>
    <br><input type='submit' name='send_newbiz' value='Add Business'/></form></div></div>";
}else{
       $fileInclude.="<div><p>You cannot add more shops</p></div></div>";     
        }
      }else{
      $fileInclude.="<div><p>I am sorry You cannot perform that operation</p></div></div>";   
    }
}else{
 $fileInclude.="<div><p>I am sorry You cannot perform that operation</p></div></div>";   
}
?>

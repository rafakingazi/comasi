<?php
class fileUploader{
	
	static function fileProcessor($originalfile,$tempfile,$uploaderid,$filename,$cate,$destpath,$error){
		
      $parts=explode(".",$originalfile);
       $extension=strtolower(array_pop($parts));
	   $file=$filename."_".$uploaderid;
       $filetosave=$file.'.'.$extension;
	   if($extension=='csv' || $extension=='txt' || $extension=='xls' || $extension=='xlsx' ){
		   echo "file is so good to handle here";
		   
		  self::readFileContent($tempfile,$extension);
		   /*
       if( move_uploaded_file(trim($tempfile), trim($destpath."/".$filetosave))){
		   return array("",trim($uploaderid),trim($filename),trim($file),trim($extension),trim($cate),self::setDates(),self::setDates());
	   }else{
		   return $error;
	   }
	   */
	   }else{
		   return 1;
	   }
	}
	
	static function readFileContent($file, $extension,$input_number){
		$content="";
		$file_data="";
		$from_user=$input_number;
		if($extension!= 'xls' && $extension!='xlsx'){
		$content=file_get_contents($file);
		if($extension=='csv'){
		$file_data=@explode("\r",$content);
		}else if($extension=='txt'){
			$file_data=@explode("\n",$content);
		}
		if(is_array($file_data)){
			foreach($file_data as $value){
				//echo "value is".$value;
				$number=trim($value);
				$len=strlen($number);
				if($len>=9){
					$pos=$len-9;
					$new_number="255".strpos($number,$pos);
					$from_user[].=$value;
					
					
			}
			}
		}
		}else{
			$content=file($file);
		if(is_array($content)){
			foreach($content as $value){
				echo "value are".$value."<br /><span color='blue'>Mimi</span>";
			}
		}else{
			echo $content;
		}
		}
		return $from_user;
	}
	//file downloader 
	 static function downloads($submit,$keys,$filetype){
      if(isset($_POST[$submit])){
          $file=trim($_POST[$keys]);
		   $type=trim($_POST[$filetype]);
	 
          $fp=  fopen($file,'r');
         header("Location:".$file);
		  
             header("Content-Type:application/pdf");
             header("Content-Length:".filesize($file));
             header("Content-Disposition-attachment;filename=".$filename.".".$type);
             header("Content-Transer-Encoding:binary");
             fpassthru($fp);
      }
	 }
	 static function downloads_nosubmit($key,$filetype){
		  $filename=md5($key);
          $fp=  fopen($key,'r');
         header("Location:".trim($key));
		  
             header("Content-Type:application/pdf");
             header("Content-Length:".filesize($key));
             header("Content-Disposition-attachment;filename=".$filename.".".$filetype);
             header("Content-Transer-Encoding:binary");
             fpassthru($fp);
	 }
	 
	static function  setDates(){
      return @date('Y/m/d/ H:i:s');     
   }
}
?>

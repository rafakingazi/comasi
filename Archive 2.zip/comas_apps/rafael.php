<?php

$business=new ComasUserManager();

if($business->hasBusiness()){
$reports=new ComasReports();
//$summary=$bizselector->changeUserBusiness();
$history1=$reports->bizSummary();
$history2=$reports->bizDetails();

$expired=  ComasUserManager::isExpired();
$infos=new  ComasInformer();
if(!$expired){
if($history1!=""):
$fileInclude.=$history1;
endif;

if($history2!=""):
//$fileInclude.=$history2;
endif;
}else{
 $fileInclude.="<div>".$infos->accountExpireText("eng")."</div></div>";   
}
$fileInclude.="</div>";

}else{
require_once 'comas_newbusiness.php';   
}
?>
